# Streamlit Monitoring Dashboard Specification

## Goal

Create a Streamlit application that downloads monitoring CSV files from Artifactory and provides an interactive dashboard for Linux server monitoring.

The application is read-only.

It must not SSH into servers or modify any data.

---

# Technology

* Python >=3.10
* Streamlit
* pandas
* plotly
* requests

---

# Configuration

At the top of the application expose:

```
ARTIFACTORY_URL
ARTIFACTORY_TOKEN
```

The application downloads every CSV available in the configured Artifactory directory.

---

# CSV Schema

Each CSV contains:

```
timestamp
hostname
process_found
process_name
pids
process_uptime_seconds
cpu_process_percent
memory_rss_mb
memory_vms_mb
memory_percent
thread_count
open_file_descriptors
cpu_system_percent
load_1
load_5
load_15
mem_total_mb
mem_used_mb
mem_available_mb
disk_total_gb
disk_used_gb
disk_free_gb
disk_used_percent
```

Convert timestamp to datetime.

Sort by timestamp.

---

# Sidebar

Provide filters for:

* Hostname
* Process Name
* Date Range

If multiple hosts are selected, overlay the graphs.

---

# Dashboard Layout

## Summary

Display cards showing:

* Latest CPU %
* Latest Memory Used
* Latest Disk %
* Latest Thread Count
* Latest Open File Descriptors
* Process Running (Yes/No)
* Last Updated Timestamp

---

## System

Charts:

* System CPU %
* Memory Used
* Memory Available
* Disk Used %
* Load Average (1,5,15)

---

## Process

Charts:

* Process CPU %
* RSS Memory
* VMS Memory
* Memory %
* Thread Count
* Open File Descriptors

---

## Uptime

Plot:

Process Uptime

Highlight process restarts.

A restart is detected whenever:

* uptime decreases
* OR process_found changes from false to true

Display restart markers on the graph.

---

## Statistics

For every numeric metric display:

* Minimum
* Maximum
* Average
* Median
* P90
* P95
* P99
* Standard Deviation

---

## Trends

Display:

* Highest CPU observed
* Highest RSS observed
* Highest FD count
* Highest Thread count
* Maximum Disk %
* Maximum Memory %

---

## Data Table

Display the filtered dataframe.

Allow:

* Sorting
* Searching

Provide a Download CSV button.

---

# Visuals

Use Plotly.

Every graph should support:

* Zoom
* Pan
* Hover
* Export as PNG

---

# Error Handling

If Artifactory is unavailable:

Display an error banner.

If no CSV exists:

Display:

"No monitoring data found."

---

# Refresh

Provide a Refresh button.

Do not auto-refresh.

---

# Code Quality

Organize into functions:

```
download_csvs()
load_data()
filter_data()
build_summary()
build_system_charts()
build_process_charts()
build_statistics()
build_table()
```

Avoid duplicated code.

---

# Deliverables

```
app.py
requirements.txt
README.md
```

README must include:

* Installation
* Configuration
* Running the application
* Example screenshots (placeholder)
* Artifactory configuration
* Troubleshooting