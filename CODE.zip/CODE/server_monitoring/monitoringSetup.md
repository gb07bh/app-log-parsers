# monitor.sh Implementation Specification

## Goal

Create a production-ready Bash script named `monitor.sh` that runs once
per minute from cron and collects system and process metrics, storing
them in a CSV file hosted in Artifactory.

## Constraints

-   Bash only.
-   Use only standard Linux utilities.
-   No Python.
-   Compatible with RHEL/Rocky/Oracle Linux 8+.
-   Single self-contained script.

## Configuration Variables

At the top of the script expose:

-   PROCESS_NAME
-   DISK_PATH
-   ARTIFACTORY_URL
-   ARTIFACTORY_TOKEN

Generate the CSV filename automatically as:

`<hostname>`{=html}\_metrics.csv

using:

hostname -s

## Execution Flow

1.  Acquire an exclusive lock using flock.
2.  Register a trap to clean temporary files.
3.  Download the existing CSV from Artifactory.
4.  If the CSV does not exist (HTTP 404), create a new CSV with a
    header.
5.  Collect metrics.
6.  Append one CSV row.
7.  Upload the CSV back to Artifactory.
8.  Delete the local temporary CSV after a successful upload.
9.  Exit.

## Artifactory

Use curl.

Download: - Retry 3 times. - Connection timeout 10 seconds. - Max
execution time 60 seconds. - Validate HTTP response. - Treat HTTP 404 as
first execution.

Upload: - Retry 3 times. - Validate HTTP 200/201/204.

Log failures.

## Locking

Use flock to prevent concurrent execution.

## Logging

Log only failures.

Example:

/tmp/monitor.log

## System Metrics

Collect:

-   UTC ISO8601 timestamp
-   Hostname
-   CPU utilisation from /proc/stat
-   Load averages (1/5/15)
-   Total memory (MB)
-   Used memory (MB)
-   Available memory (MB)
-   Disk total (GB)
-   Disk used (GB)
-   Disk free (GB)
-   Disk utilisation %

CPU must be calculated using two reads of /proc/stat separated by
approximately one second.

## Process Metrics

Find every matching process using:

pgrep -f

Aggregate across every matching PID.

Collect:

-   PID list
-   CPU %
-   RSS MB
-   VMS MB
-   Memory %
-   Thread count
-   Open file descriptor count
-   Process uptime

Use the oldest matching process uptime.

## CSV Header

timestamp,hostname,process_found,process_name,pids,process_uptime_seconds,cpu_process_percent,memory_rss_mb,memory_vms_mb,memory_percent,thread_count,open_file_descriptors,cpu_system_percent,load_1,load_5,load_15,mem_total_mb,mem_used_mb,mem_available_mb,disk_total_gb,disk_used_gb,disk_free_gb,disk_used_percent

## Quality Requirements

-   Modular Bash functions.
-   Defensive error handling.
-   Quote variables.
-   ShellCheck-friendly.
-   No TODOs or placeholders.
-   Production-ready.

## Deliverables

1.  monitor.sh
2.  README section at the end explaining:
    -   Configuration
    -   Dependencies
    -   Cron entry
    -   CSV schema
    -   Assumptions
