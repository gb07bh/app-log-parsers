#!/usr/bin/env bash

set -uo pipefail

PROCESS_NAME="${PROCESS_NAME:-}"
DISK_PATH="${DISK_PATH:-/}"
ARTIFACTORY_URL="${ARTIFACTORY_URL:-}"
ARTIFACTORY_TOKEN="${ARTIFACTORY_TOKEN:-}"

LOG_FILE="/tmp/monitor.log"
LOCK_FILE="/tmp/monitor.lock"
CSV_HEADER="timestamp,hostname,process_found,process_name,pids,process_uptime_seconds,cpu_process_percent,memory_rss_mb,memory_vms_mb,memory_percent,thread_count,open_file_descriptors,cpu_system_percent,load_1,load_5,load_15,mem_total_mb,mem_used_mb,mem_available_mb,disk_total_gb,disk_used_gb,disk_free_gb,disk_used_percent"

TMP_DIR=""
LOCAL_CSV=""
DOWNLOAD_BODY=""
UPLOAD_BODY=""

log_failure() {
    printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" >> "$LOG_FILE"
}

cleanup() {
    if [[ -n "$TMP_DIR" && -d "$TMP_DIR" ]]; then
        rm -rf "$TMP_DIR"
    fi
}

die() {
    log_failure "$*"
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"
}

validate_config() {
    [[ -n "$PROCESS_NAME" ]] || die "PROCESS_NAME is required"
    [[ -n "$DISK_PATH" ]] || die "DISK_PATH is required"
    [[ -d "$DISK_PATH" ]] || die "DISK_PATH does not exist or is not a directory: $DISK_PATH"
    [[ -n "$ARTIFACTORY_URL" ]] || die "ARTIFACTORY_URL is required"
    [[ -n "$ARTIFACTORY_TOKEN" ]] || die "ARTIFACTORY_TOKEN is required"
}

csv_escape() {
    local value=${1:-}
    value=${value//\"/\"\"}
    printf '"%s"' "$value"
}

csv_number() {
    local value=${1:-0}
    [[ -n "$value" ]] && printf '%s' "$value" || printf '0'
}

remote_csv_url() {
    local host_name=$1
    local file_name="${host_name}_metrics.csv"
    printf '%s/%s' "${ARTIFACTORY_URL%/}" "$file_name"
}

curl_auth_args() {
    if [[ -n "$ARTIFACTORY_TOKEN" ]]; then
        printf '%s\n' "-H"
        printf '%s\n' "Authorization: Bearer ${ARTIFACTORY_TOKEN}"
    fi
}

download_csv() {
    local url=$1
    local status
    local auth_args=()

    mapfile -t auth_args < <(curl_auth_args)

    if ! status=$(curl -sS -L --retry 3 --connect-timeout 10 --max-time 60 \
        "${auth_args[@]}" -w '%{http_code}' -o "$DOWNLOAD_BODY" "$url" 2>>"$LOG_FILE"); then
        log_failure "Download failed for $url"
        return 1
    fi

    case "$status" in
        200)
            cp "$DOWNLOAD_BODY" "$LOCAL_CSV" || return 1
            if [[ ! -s "$LOCAL_CSV" ]]; then
                printf '%s\n' "$CSV_HEADER" > "$LOCAL_CSV" || return 1
            fi
            ;;
        404)
            printf '%s\n' "$CSV_HEADER" > "$LOCAL_CSV" || return 1
            ;;
        *)
            log_failure "Download returned HTTP $status for $url"
            return 1
            ;;
    esac
}

upload_csv() {
    local url=$1
    local status
    local auth_args=()

    mapfile -t auth_args < <(curl_auth_args)

    if ! status=$(curl -sS -L --retry 3 --connect-timeout 10 --max-time 60 \
        "${auth_args[@]}" -w '%{http_code}' -o "$UPLOAD_BODY" -T "$LOCAL_CSV" "$url" 2>>"$LOG_FILE"); then
        log_failure "Upload failed for $url"
        return 1
    fi

    case "$status" in
        200|201|204)
            rm -f "$LOCAL_CSV"
            ;;
        *)
            log_failure "Upload returned HTTP $status for $url"
            return 1
            ;;
    esac
}

read_cpu_totals() {
    local _cpu user nice system idle iowait irq softirq steal guest guest_nice
    read -r _cpu user nice system idle iowait irq softirq steal guest guest_nice < /proc/stat
    local idle_all=$((idle + iowait))
    local non_idle=$((user + nice + system + irq + softirq + steal))
    local total=$((idle_all + non_idle))
    printf '%s %s\n' "$total" "$idle_all"
}

system_cpu_percent() {
    local total1 idle1 total2 idle2 total_delta idle_delta
    read -r total1 idle1 < <(read_cpu_totals)
    sleep 1
    read -r total2 idle2 < <(read_cpu_totals)

    total_delta=$((total2 - total1))
    idle_delta=$((idle2 - idle1))

    if (( total_delta <= 0 )); then
        printf '0.00'
        return
    fi

    awk -v total="$total_delta" -v idle="$idle_delta" 'BEGIN { printf "%.2f", (100 * (total - idle) / total) }'
}

load_averages() {
    awk '{ printf "%s %s %s", $1, $2, $3 }' /proc/loadavg
}

memory_metrics() {
    awk '
        /^MemTotal:/ { total=$2 }
        /^MemAvailable:/ { available=$2 }
        END {
            used=total-available
            printf "%.0f %.0f %.0f", total/1024, used/1024, available/1024
        }
    ' /proc/meminfo
}

disk_metrics() {
    df -BG -P "$DISK_PATH" | awk 'NR == 2 {
        total=$2; used=$3; free=$4; pct=$5
        gsub(/G/, "", total)
        gsub(/G/, "", used)
        gsub(/G/, "", free)
        gsub(/%/, "", pct)
        printf "%s %s %s %s", total, used, free, pct
    }'
}

pid_start_seconds() {
    local pid=$1
    local stat_file="/proc/${pid}/stat"
    local start_ticks hz boot_seconds

    [[ -r "$stat_file" ]] || return 1

    start_ticks=$(awk '{ sub(/^.*\) /, ""); print $20 }' "$stat_file") || return 1
    hz=$(getconf CLK_TCK) || return 1
    boot_seconds=$(awk '/^btime / { print $2 }' /proc/stat) || return 1

    awk -v boot="$boot_seconds" -v ticks="$start_ticks" -v hz="$hz" 'BEGIN { printf "%.0f", boot + (ticks / hz) }'
}

process_metrics() {
    local pids=()
    local pid
    local pid_list=""
    local process_found=false
    local uptime_seconds=0
    local cpu_process_percent=0
    local memory_rss_mb=0
    local memory_vms_mb=0
    local memory_percent=0
    local thread_count=0
    local open_file_descriptors=0
    local oldest_start=0
    local current_epoch

    while IFS= read -r pid; do
        [[ -n "$pid" && -d "/proc/$pid" ]] && pids+=("$pid")
    done < <(pgrep -f "$PROCESS_NAME" || true)

    if (( ${#pids[@]} > 0 )); then
        process_found=true
        current_epoch=$(date +%s)

        for pid in "${pids[@]}"; do
            local proc_cpu proc_rss proc_vsz proc_mem proc_threads proc_fds proc_start

            proc_cpu=$(ps -p "$pid" -o %cpu= 2>/dev/null | awk '{ print $1 }')
            proc_rss=$(ps -p "$pid" -o rss= 2>/dev/null | awk '{ print $1 }')
            proc_vsz=$(ps -p "$pid" -o vsz= 2>/dev/null | awk '{ print $1 }')
            proc_mem=$(ps -p "$pid" -o %mem= 2>/dev/null | awk '{ print $1 }')
            proc_threads=$(awk '/^Threads:/ { print $2 }' "/proc/$pid/status" 2>/dev/null || printf '0')
            proc_fds=$(find "/proc/$pid/fd" -maxdepth 1 -type l 2>/dev/null | wc -l | awk '{ print $1 }')
            proc_start=$(pid_start_seconds "$pid" || printf '0')

            [[ -z "$proc_cpu" ]] && proc_cpu=0
            [[ -z "$proc_rss" ]] && proc_rss=0
            [[ -z "$proc_vsz" ]] && proc_vsz=0
            [[ -z "$proc_mem" ]] && proc_mem=0
            [[ -z "$proc_threads" ]] && proc_threads=0
            [[ -z "$proc_fds" ]] && proc_fds=0

            cpu_process_percent=$(awk -v a="$cpu_process_percent" -v b="$proc_cpu" 'BEGIN { printf "%.2f", a + b }')
            memory_rss_mb=$(awk -v a="$memory_rss_mb" -v b="$proc_rss" 'BEGIN { printf "%.2f", a + (b / 1024) }')
            memory_vms_mb=$(awk -v a="$memory_vms_mb" -v b="$proc_vsz" 'BEGIN { printf "%.2f", a + (b / 1024) }')
            memory_percent=$(awk -v a="$memory_percent" -v b="$proc_mem" 'BEGIN { printf "%.2f", a + b }')
            thread_count=$((thread_count + proc_threads))
            open_file_descriptors=$((open_file_descriptors + proc_fds))

            if (( proc_start > 0 )) && { (( oldest_start == 0 )) || (( proc_start < oldest_start )); }; then
                oldest_start=$proc_start
            fi

            if [[ -z "$pid_list" ]]; then
                pid_list=$pid
            else
                pid_list="${pid_list} ${pid}"
            fi
        done

        if (( oldest_start > 0 && current_epoch >= oldest_start )); then
            uptime_seconds=$((current_epoch - oldest_start))
        fi
    fi

    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
        "$process_found" \
        "$(csv_escape "$pid_list")" \
        "$(csv_number "$uptime_seconds")" \
        "$(csv_number "$cpu_process_percent")" \
        "$(csv_number "$memory_rss_mb")" \
        "$(csv_number "$memory_vms_mb")" \
        "$(csv_number "$memory_percent")" \
        "$(csv_number "$thread_count")" \
        "$(csv_number "$open_file_descriptors")"
}

append_metrics_row() {
    local host_name=$1
    local timestamp
    local cpu_system_percent
    local load_1 load_5 load_15
    local mem_total_mb mem_used_mb mem_available_mb
    local disk_total_gb disk_used_gb disk_free_gb disk_used_percent
    local process_found pids process_uptime_seconds cpu_process_percent memory_rss_mb memory_vms_mb memory_percent thread_count open_file_descriptors
    local load_values mem_values disk_values process_values

    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
    cpu_system_percent=$(system_cpu_percent) || return 1
    load_values=$(load_averages) || return 1
    mem_values=$(memory_metrics) || return 1
    disk_values=$(disk_metrics) || return 1
    process_values=$(process_metrics) || return 1

    read -r load_1 load_5 load_15 <<< "$load_values"
    read -r mem_total_mb mem_used_mb mem_available_mb <<< "$mem_values"
    read -r disk_total_gb disk_used_gb disk_free_gb disk_used_percent <<< "$disk_values"
    IFS=',' read -r process_found pids process_uptime_seconds cpu_process_percent memory_rss_mb memory_vms_mb memory_percent thread_count open_file_descriptors <<< "$process_values"

    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
        "$(csv_escape "$timestamp")" \
        "$(csv_escape "$host_name")" \
        "$process_found" \
        "$(csv_escape "$PROCESS_NAME")" \
        "$pids" \
        "$process_uptime_seconds" \
        "$cpu_process_percent" \
        "$memory_rss_mb" \
        "$memory_vms_mb" \
        "$memory_percent" \
        "$thread_count" \
        "$open_file_descriptors" \
        "$cpu_system_percent" \
        "$load_1" \
        "$load_5" \
        "$load_15" \
        "$mem_total_mb" \
        "$mem_used_mb" \
        "$mem_available_mb" \
        "$disk_total_gb" \
        "$disk_used_gb" \
        "$disk_free_gb" \
        "$disk_used_percent" >> "$LOCAL_CSV"
}

main() {
    local host_name
    local url

    require_command awk
    require_command cp
    require_command curl
    require_command date
    require_command df
    require_command find
    require_command flock
    require_command getconf
    require_command hostname
    require_command mktemp
    require_command pgrep
    require_command ps
    require_command rm
    require_command sleep
    require_command wc
    validate_config

    host_name=$(hostname -s) || die "Unable to determine hostname"
    url=$(remote_csv_url "$host_name")
    TMP_DIR=$(mktemp -d /tmp/monitor.XXXXXX) || die "Unable to create temporary directory"
    LOCAL_CSV="${TMP_DIR}/${host_name}_metrics.csv"
    DOWNLOAD_BODY="${TMP_DIR}/download.body"
    UPLOAD_BODY="${TMP_DIR}/upload.body"

    trap cleanup EXIT INT TERM

    exec 9>"$LOCK_FILE" || die "Unable to open lock file: $LOCK_FILE"
    flock -n 9 || die "Another monitor.sh instance is already running"

    download_csv "$url" || die "Unable to download or initialize CSV"
    append_metrics_row "$host_name" || die "Unable to collect metrics"
    upload_csv "$url" || die "Unable to upload CSV"
}

main "$@"

: <<'MONITOR_README'

README

Configuration

Edit the variables at the top of monitor.sh, or export them in the cron
environment before invoking the script:

- PROCESS_NAME: process search pattern passed to pgrep -f.
- DISK_PATH: filesystem path to measure with df.
- ARTIFACTORY_URL: Artifactory directory URL where CSV files are stored.
- ARTIFACTORY_TOKEN: Artifactory access token sent as Authorization: Bearer.

The script writes one CSV per host using hostname -s:

<hostname>_metrics.csv

Dependencies

The script is Bash-only and uses standard Linux utilities available on
RHEL, Rocky, and Oracle Linux 8+:

bash, awk, cp, curl, date, df, find, flock, getconf, hostname, mktemp,
pgrep, ps, rm, sleep, wc

Cron Entry

Run once per minute:

* * * * * /path/to/monitor.sh

CSV Schema

timestamp,hostname,process_found,process_name,pids,process_uptime_seconds,cpu_process_percent,memory_rss_mb,memory_vms_mb,memory_percent,thread_count,open_file_descriptors,cpu_system_percent,load_1,load_5,load_15,mem_total_mb,mem_used_mb,mem_available_mb,disk_total_gb,disk_used_gb,disk_free_gb,disk_used_percent

Assumptions

- ARTIFACTORY_URL points to a writable Artifactory folder, not a local path.
- ARTIFACTORY_TOKEN is a JFrog access token accepted by Bearer authentication.
- HTTP 404 on download means the host CSV does not exist yet.
- Process metrics aggregate every PID returned by pgrep -f PROCESS_NAME.
- Process uptime uses the oldest matching process.
- CPU system utilization is calculated from two /proc/stat reads about one
  second apart.
- The script logs only failures to /tmp/monitor.log.

MONITOR_README
