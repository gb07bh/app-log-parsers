import io
import numbers
import os
import re
from html.parser import HTMLParser
from urllib.parse import urljoin

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import streamlit as st


ARTIFACTORY_URL = os.getenv("ARTIFACTORY_URL", "")
ARTIFACTORY_TOKEN = os.getenv("ARTIFACTORY_TOKEN", "")

CSV_COLUMNS = [
    "timestamp",
    "hostname",
    "process_found",
    "process_name",
    "pids",
    "process_uptime_seconds",
    "cpu_process_percent",
    "memory_rss_mb",
    "memory_vms_mb",
    "memory_percent",
    "thread_count",
    "open_file_descriptors",
    "cpu_system_percent",
    "load_1",
    "load_5",
    "load_15",
    "mem_total_mb",
    "mem_used_mb",
    "mem_available_mb",
    "disk_total_gb",
    "disk_used_gb",
    "disk_free_gb",
    "disk_used_percent",
]

NUMERIC_COLUMNS = [
    "process_uptime_seconds",
    "cpu_process_percent",
    "memory_rss_mb",
    "memory_vms_mb",
    "memory_percent",
    "thread_count",
    "open_file_descriptors",
    "cpu_system_percent",
    "load_1",
    "load_5",
    "load_15",
    "mem_total_mb",
    "mem_used_mb",
    "mem_available_mb",
    "disk_total_gb",
    "disk_used_gb",
    "disk_free_gb",
    "disk_used_percent",
]


class CsvLinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag != "a":
            return
        attr_map = dict(attrs)
        href = attr_map.get("href", "")
        if href.lower().endswith(".csv"):
            self.links.append(href)


def auth_headers():
    if not ARTIFACTORY_TOKEN:
        return {}
    return {"Authorization": f"Bearer {ARTIFACTORY_TOKEN}"}


def csv_urls_from_json(base_url, payload):
    children = payload.get("children", [])
    urls = []
    for child in children:
        uri = child.get("uri", "")
        if uri.lower().endswith(".csv"):
            urls.append(urljoin(f"{base_url.rstrip('/')}/", uri.lstrip("/")))
    return urls


def csv_urls_from_html(base_url, html):
    parser = CsvLinkParser()
    parser.feed(html)
    urls = [urljoin(f"{base_url.rstrip('/')}/", link) for link in parser.links]
    if urls:
        return urls

    csv_names = sorted(set(re.findall(r'[\w.-]+\.csv', html, flags=re.IGNORECASE)))
    return [urljoin(f"{base_url.rstrip('/')}/", name) for name in csv_names]


@st.cache_data(show_spinner=False)
def download_csvs():
    if not ARTIFACTORY_URL:
        return [], "ARTIFACTORY_URL is not configured."

    session = requests.Session()
    session.headers.update(auth_headers())

    try:
        response = session.get(ARTIFACTORY_URL, timeout=30)
        response.raise_for_status()
    except requests.RequestException as exc:
        return [], f"Artifactory is unavailable: {exc}"

    if ARTIFACTORY_URL.lower().endswith(".csv"):
        csv_urls = [ARTIFACTORY_URL]
    else:
        csv_urls = []
        try:
            csv_urls = csv_urls_from_json(ARTIFACTORY_URL, response.json())
        except ValueError:
            csv_urls = csv_urls_from_html(ARTIFACTORY_URL, response.text)

    frames = []
    errors = []
    for csv_url in sorted(set(csv_urls)):
        try:
            csv_response = session.get(csv_url, timeout=30)
            csv_response.raise_for_status()
            if csv_response.text.strip():
                frame = pd.read_csv(io.StringIO(csv_response.text))
                frame["source_file"] = csv_url.rsplit("/", 1)[-1]
                frames.append(frame)
        except requests.RequestException as exc:
            errors.append(f"{csv_url}: {exc}")
        except pd.errors.ParserError as exc:
            errors.append(f"{csv_url}: CSV parse failed: {exc}")

    return frames, "\n".join(errors)


def load_data():
    frames, error = download_csvs()
    if not frames:
        return pd.DataFrame(columns=CSV_COLUMNS + ["source_file"]), error

    data = pd.concat(frames, ignore_index=True)
    for column in CSV_COLUMNS:
        if column not in data.columns:
            data[column] = pd.NA

    data = data[CSV_COLUMNS + [column for column in data.columns if column not in CSV_COLUMNS]]
    data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce", utc=True)
    data["process_found"] = data["process_found"].astype(str).str.lower().isin(["true", "1", "yes"])

    for column in NUMERIC_COLUMNS:
        data[column] = pd.to_numeric(data[column], errors="coerce")

    data = data.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
    return data, error


def filter_data(data):
    if data.empty:
        return data

    hostnames = sorted(data["hostname"].dropna().unique())
    process_names = sorted(data["process_name"].dropna().unique())
    min_date = data["timestamp"].min().date()
    max_date = data["timestamp"].max().date()

    selected_hosts = st.sidebar.multiselect("Hostname", hostnames, default=hostnames)
    selected_processes = st.sidebar.multiselect("Process Name", process_names, default=process_names)
    date_range = st.sidebar.date_input("Date Range", value=(min_date, max_date), min_value=min_date, max_value=max_date)

    filtered = data.copy()
    if selected_hosts:
        filtered = filtered[filtered["hostname"].isin(selected_hosts)]
    if selected_processes:
        filtered = filtered[filtered["process_name"].isin(selected_processes)]
    if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
        start = pd.Timestamp(date_range[0], tz="UTC")
        end = pd.Timestamp(date_range[1], tz="UTC") + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
        filtered = filtered[(filtered["timestamp"] >= start) & (filtered["timestamp"] <= end)]

    return filtered.sort_values("timestamp")


def latest_row(data):
    if data.empty:
        return None
    return data.sort_values("timestamp").iloc[-1]


def metric_value(row, column, suffix="", decimals=2):
    if row is None or pd.isna(row[column]):
        return "N/A"
    value = row[column]
    if isinstance(value, numbers.Number):
        return f"{value:,.{decimals}f}{suffix}"
    return f"{value}{suffix}"


def build_summary(data):
    st.subheader("Summary")
    row = latest_row(data)
    cols = st.columns(4)
    cols[0].metric("Latest CPU %", metric_value(row, "cpu_system_percent", "%"))
    cols[1].metric("Latest Memory Used", metric_value(row, "mem_used_mb", " MB", 0))
    cols[2].metric("Latest Disk %", metric_value(row, "disk_used_percent", "%"))
    cols[3].metric("Latest Thread Count", metric_value(row, "thread_count", "", 0))

    cols = st.columns(3)
    cols[0].metric("Latest Open File Descriptors", metric_value(row, "open_file_descriptors", "", 0))
    process_running = "N/A" if row is None else ("Yes" if bool(row["process_found"]) else "No")
    cols[1].metric("Process Running", process_running)
    last_updated = "N/A" if row is None else row["timestamp"].strftime("%Y-%m-%d %H:%M:%S UTC")
    cols[2].metric("Last Updated Timestamp", last_updated)


def line_chart(data, y, title, labels=None):
    if data.empty:
        st.info("No data available for this chart.")
        return

    fig = px.line(
        data,
        x="timestamp",
        y=y,
        color="hostname",
        line_dash="process_name",
        markers=True,
        title=title,
        labels=labels or {},
    )
    fig.update_layout(hovermode="x unified", legend_title_text="Host / Process")
    st.plotly_chart(fig, use_container_width=True)


def load_average_chart(data):
    if data.empty:
        st.info("No load average data available.")
        return

    melted = data.melt(
        id_vars=["timestamp", "hostname", "process_name"],
        value_vars=["load_1", "load_5", "load_15"],
        var_name="load_window",
        value_name="load_average",
    )
    fig = px.line(
        melted,
        x="timestamp",
        y="load_average",
        color="hostname",
        line_dash="load_window",
        facet_row="process_name" if melted["process_name"].nunique() > 1 else None,
        title="Load Average (1, 5, 15)",
    )
    fig.update_layout(hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True)


def build_system_charts(data):
    st.subheader("System")
    line_chart(data, "cpu_system_percent", "System CPU %", {"cpu_system_percent": "CPU %"})
    line_chart(data, "mem_used_mb", "Memory Used", {"mem_used_mb": "MB"})
    line_chart(data, "mem_available_mb", "Memory Available", {"mem_available_mb": "MB"})
    line_chart(data, "disk_used_percent", "Disk Used %", {"disk_used_percent": "Disk %"})
    load_average_chart(data)


def build_process_charts(data):
    st.subheader("Process")
    line_chart(data, "cpu_process_percent", "Process CPU %", {"cpu_process_percent": "CPU %"})
    line_chart(data, "memory_rss_mb", "RSS Memory", {"memory_rss_mb": "MB"})
    line_chart(data, "memory_vms_mb", "VMS Memory", {"memory_vms_mb": "MB"})
    line_chart(data, "memory_percent", "Memory %", {"memory_percent": "Memory %"})
    line_chart(data, "thread_count", "Thread Count")
    line_chart(data, "open_file_descriptors", "Open File Descriptors")


def restart_rows(data):
    restart_frames = []
    for _, group in data.sort_values("timestamp").groupby(["hostname", "process_name"], dropna=False):
        previous_uptime = group["process_uptime_seconds"].shift(1)
        previous_found = group["process_found"].shift(1).fillna(False)
        restarted = (group["process_uptime_seconds"] < previous_uptime) | (~previous_found & group["process_found"])
        restart_frames.append(group[restarted])
    if not restart_frames:
        return data.iloc[0:0]
    return pd.concat(restart_frames).sort_values("timestamp")


def build_uptime(data):
    st.subheader("Uptime")
    if data.empty:
        st.info("No uptime data available.")
        return

    fig = px.line(
        data,
        x="timestamp",
        y="process_uptime_seconds",
        color="hostname",
        line_dash="process_name",
        markers=True,
        title="Process Uptime",
        labels={"process_uptime_seconds": "Uptime Seconds"},
    )

    restarts = restart_rows(data)
    if not restarts.empty:
        fig.add_trace(
            go.Scatter(
                x=restarts["timestamp"],
                y=restarts["process_uptime_seconds"],
                mode="markers",
                name="Restart detected",
                marker={"symbol": "x", "size": 12, "color": "red"},
                text=restarts["hostname"] + " / " + restarts["process_name"].astype(str),
                hovertemplate="%{text}<br>%{x}<br>uptime=%{y}<extra>Restart</extra>",
            )
        )

    fig.update_layout(hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True)


def build_statistics(data):
    st.subheader("Statistics")
    if data.empty:
        st.info("No numeric data available.")
        return

    stats = data[NUMERIC_COLUMNS].agg(["min", "max", "mean", "median", "std"]).T
    stats["p90"] = data[NUMERIC_COLUMNS].quantile(0.90)
    stats["p95"] = data[NUMERIC_COLUMNS].quantile(0.95)
    stats["p99"] = data[NUMERIC_COLUMNS].quantile(0.99)
    stats = stats.rename(
        columns={
            "min": "Minimum",
            "max": "Maximum",
            "mean": "Average",
            "median": "Median",
            "std": "Standard Deviation",
            "p90": "P90",
            "p95": "P95",
            "p99": "P99",
        }
    )
    ordered_columns = ["Minimum", "Maximum", "Average", "Median", "P90", "P95", "P99", "Standard Deviation"]
    st.dataframe(stats[ordered_columns], use_container_width=True)


def build_trends(data):
    st.subheader("Trends")
    if data.empty:
        st.info("No trend data available.")
        return

    trend_specs = [
        ("Highest CPU observed", "cpu_system_percent", "%"),
        ("Highest RSS observed", "memory_rss_mb", " MB"),
        ("Highest FD count", "open_file_descriptors", ""),
        ("Highest Thread count", "thread_count", ""),
        ("Maximum Disk %", "disk_used_percent", "%"),
        ("Maximum Memory %", "memory_percent", "%"),
    ]
    cols = st.columns(3)
    for index, (label, column, suffix) in enumerate(trend_specs):
        value = data[column].max()
        display = "N/A" if pd.isna(value) else f"{value:,.2f}{suffix}"
        cols[index % 3].metric(label, display)


def build_table(data):
    st.subheader("Data Table")
    if data.empty:
        st.info("No rows match the current filters.")
        return

    search = st.text_input("Search")
    table_data = data
    if search:
        search_mask = table_data.astype(str).apply(
            lambda col: col.str.contains(search, case=False, na=False, regex=False)
        ).any(axis=1)
        table_data = table_data[search_mask]

    st.dataframe(table_data, use_container_width=True, hide_index=True)
    st.download_button(
        "Download CSV",
        table_data.to_csv(index=False).encode("utf-8"),
        file_name="filtered_monitoring_data.csv",
        mime="text/csv",
    )


def main():
    st.set_page_config(page_title="Server Monitoring", layout="wide")
    st.title("Server Monitoring")

    with st.sidebar:
        st.header("Configuration")
        st.caption("Set ARTIFACTORY_URL and ARTIFACTORY_TOKEN at the top of app.py or through environment variables.")
        if st.button("Refresh", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

    data, error = load_data()
    if error:
        st.error(error)
    if data.empty:
        st.info("No monitoring data found.")
        return

    filtered = filter_data(data)
    build_summary(filtered)

    tabs = st.tabs(["System", "Process", "Uptime", "Statistics", "Trends", "Data Table"])
    with tabs[0]:
        build_system_charts(filtered)
    with tabs[1]:
        build_process_charts(filtered)
    with tabs[2]:
        build_uptime(filtered)
    with tabs[3]:
        build_statistics(filtered)
    with tabs[4]:
        build_trends(filtered)
    with tabs[5]:
        build_table(filtered)


if __name__ == "__main__":
    main()
