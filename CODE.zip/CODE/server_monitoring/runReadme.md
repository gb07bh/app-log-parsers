# Streamlit Monitoring Dashboard Run Guide

## Files

- `app.py`: read-only Streamlit dashboard.
- `monitor.sh`: server-side metrics collector that uploads CSVs to Artifactory.
- `streamlitSetup.md`: dashboard build specification.

## Requirements

- Python 3.10 or newer
- Network access from the dashboard machine to the Artifactory CSV directory
- Python packages:

```bash
pip install streamlit pandas plotly requests
```

## Required Variables

Set these as environment variables before launching the app, or edit the values at the top of `app.py`.

```bash
export ARTIFACTORY_URL="https://artifactory.example.com/artifactory/path/to/monitoring"
export ARTIFACTORY_TOKEN="your-access-token"
```

`ARTIFACTORY_URL` should point to the Artifactory directory containing files like:

```text
server1_metrics.csv
server2_metrics.csv
```

You can also point `ARTIFACTORY_URL` directly at one CSV file for a single-host view.

`ARTIFACTORY_TOKEN` is sent as:

```text
Authorization: Bearer <token>
```

Leave it empty only if the Artifactory location is readable without authentication.

## Run

From this folder:

```bash
streamlit run app.py
```

From the repository root:

```bash
streamlit run server_monitoring/app.py
```

To bind a specific address or port:

```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Then open:

```text
http://localhost:8501
```

If running on a remote server, replace `localhost` with the server hostname or IP address.

## Refresh Behavior

The app does not auto-refresh. Use the sidebar `Refresh` button to clear cached CSV data and download the latest files from Artifactory.

## Notes

- The dashboard is read-only.
- It does not SSH into servers.
- It does not write or modify monitoring data.
- Plotly charts support zoom, pan, hover, and PNG export through the chart toolbar.
