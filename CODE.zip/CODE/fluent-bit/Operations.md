# OPERATIONS_GUIDE.md

# 5. Dashboard 1 – Executive Overview

## Purpose

This dashboard provides a high-level operational view of the Digital.ai Release platform. It is intended for Engineering Managers, Platform Owners, Release Managers, and leadership who need to quickly assess platform health without investigating individual log events.

The dashboard should answer:

- Is the platform healthy?
- Are releases succeeding?
- Are users actively using the platform?
- Are there any critical issues requiring investigation?

---

## Layout

Row 1 – KPI Cards

- Total Releases Started
- Total Releases Completed
- Release Success Rate
- Active Users
- Exception Count
- HTTP Error Rate
- Scheduler Failures
- Average Response Time

---

Row 2 – Trends

Visualization | Type | Query
------------- | ---- | -----
Release Activity | Line Chart | event_category = release
Workflow Activity | Line Chart | event_category = workflow
HTTP Requests | Line Chart | log_type = access
Exceptions | Line Chart | event_category = exception

---

Row 3 – Distribution

Visualization | Type
------------- | ----
Release Status | Pie Chart
Task Status | Pie Chart
HTTP Status Codes | Pie Chart
Log Level Distribution | Pie Chart

---

Row 4 – Top Lists

Visualization | Type
------------- | ----
Top Failed Releases | Data Table
Top Exception Types | Data Table
Top Active Users | Data Table
Top Plugins | Data Table

---

# 6. Dashboard 2 – Operations Console

## Purpose

This dashboard is intended for SREs, Platform Engineers, DevOps Engineers, and Support Teams.

It should be the primary investigation dashboard.

Every visualization should respond to the global filter bar.

---

## Layout

```
+--------------------------------------------------------------+
|                     Global Filter Bar                        |
+--------------------------------------------------------------+

| Release Timeline | Workflow Timeline | Task Timeline         |

---------------------------------------------------------------

| Plugin Health | Scheduler | Authentication | Exceptions      |

---------------------------------------------------------------

| Access Analytics                                        |

---------------------------------------------------------------

| Audit Activity                                          |

---------------------------------------------------------------

| Searchable Log Table                                    |

---------------------------------------------------------------

| Raw Document Viewer                                     |

---------------------------------------------------------------+
```

---

## Sections

### Release Analytics

Visualizations

- Release Timeline
- Running Releases
- Failed Releases
- Release Status Distribution

---

### Workflow Analytics

Visualizations

- Workflow Timeline
- Workflow Failures
- Long Running Workflows

---

### Task Analytics

Visualizations

- Failed Tasks
- Retried Tasks
- Task Timeline

---

### Plugin Health

Visualizations

- Installed Plugins
- Plugin Synchronization
- Plugin Failures
- Restart Required

---

### Scheduler

Visualizations

- Scheduler Timeline
- Scheduler Failures

---

### Authentication

Visualizations

- Login Successes
- Login Failures
- Active Users

---

### Exception Analytics

Visualizations

- Exception Timeline
- Exception Distribution
- Top Exception Messages
- Top Loggers

---

### Access Analytics

Visualizations

- Request Rate
- Status Code Distribution
- Top URLs
- Top Client IPs
- Top User Agents
- Average Response Time
- P95 Response Time

---

### Audit Analytics

Visualizations

- User Administration
- Permission Changes
- Configuration Changes
- Release Changes

---

### Log Explorer

Columns

- Timestamp
- Level
- Logger
- Event
- Username
- Release
- Workflow
- Message

---

### Document Viewer

Display the complete OpenSearch document for the selected log.

---

# 7. Global Filter Bar

Every visualization on the Operations Dashboard must respond to these filters.

| Filter | Type |
|----------|------|
| Time Range | Global |
| Environment | Dropdown |
| Host | Dropdown |
| Service | Dropdown |
| Log Type | Dropdown |
| Log Level | Dropdown |
| Event Category | Dropdown |
| Event | Dropdown |
| Username | Dropdown |
| Release Name | Dropdown |
| Workflow Name | Dropdown |
| Phase Name | Dropdown |
| Task Name | Dropdown |
| Plugin Name | Dropdown |
| Repository | Dropdown |
| HTTP Status | Dropdown |
| Client IP | Dropdown |
| Logger | Dropdown |

---

# 8. Visualization Catalog

For every visualization document:

## Name

Release Failure Trend

## Dashboard

Operations Console

## Visualization Type

Line Chart

## Index

digitalai-application-*

## Filter

event = release.failed

## Aggregation

Date Histogram

## Metric

Count

## Purpose

Shows trends in release failures over time.

---

Repeat this format for every visualization.

Suggested catalog:

- Release Activity
- Release Failures
- Workflow Activity
- Workflow Failures
- Task Failures
- Retry Trend
- Scheduler Activity
- Plugin Health
- Login Trend
- Audit Activity
- Exception Trend
- Exception Distribution
- Request Rate
- HTTP Status Distribution
- Response Time Trend
- Top URLs
- Top Users
- Top Client IPs
- Top Plugins
- Top Releases
- Top Workflows

---