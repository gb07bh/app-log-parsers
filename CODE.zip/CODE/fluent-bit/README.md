# Digital.ai Release Fluent Bit Parser

## Overview

This project provides a production-ready Fluent Bit pipeline for Digital.ai Release (formerly XL Release).

Its purpose is to normalize application logs into structured OpenSearch documents.

The architecture intentionally separates parsing from business logic.

```
Tail

↓

Filesystem Buffer

↓

Multiline Parser

↓

Regex Parser

↓

Lua Normalization

↓

OpenSearch
```

---

# Philosophy

Regex parsers perform extraction only.

Lua performs all business logic.

OpenSearch receives normalized events.

No business logic belongs inside Fluent Bit regex parsers.

---

# Project Structure

```
fluent-bit/

├── fluent-bit.conf

├── parsers.conf

├── multiline-parsers.conf

├── README.md

├── SETUP.md

└── lua/

    └── digitalai.lua
```

---

# Supported Logs

- xl-release.log
- audit.log
- access.log
- wrapper.log

---

# Architecture

The Lua processor is organized into four layers.

```
Dispatcher

↓

Handlers

↓

Classifiers

↓

Rule Engine

↓

Helpers
```

Each log type has its own handler.

Application

Audit

Access

Wrapper

Application logs are classified into business events.

Access logs are normalized.

Audit logs are classified separately.

Wrapper logs are normalized separately.

---

# Versioning

Parser Version

```
1.0.0
```

Every event must include

```
parser_version
```

---

# Reference

Official logging documentation

https://docs.digital.ai/release/docs/concept/logging-in-xl-release