local PARSER_VERSION = "1.0.0"
local SERVICE_NAME = "digitalai-release"

local CATEGORY_ORDER = {
    "authentication",
    "release",
    "workflow",
    "phase",
    "task",
    "plugin",
    "repository",
    "scheduler",
    "api",
    "exception",
    "system",
}

local AUTH_PATTERNS = {
    { pattern = "logged in", event = "auth.login.success", category = "authentication", status = "success", metric = "login_count", extract = { "username" } },
    { pattern = "login succeeded", event = "auth.login.success", category = "authentication", status = "success", metric = "login_count", extract = { "username" } },
    { pattern = "failed log in", event = "auth.login.failed", category = "authentication", status = "failure", metric = "login_count", extract = { "username" } },
    { pattern = "login failed", event = "auth.login.failed", category = "authentication", status = "failure", metric = "login_count", extract = { "username" } },
    { pattern = "logged out", event = "auth.logout", category = "authentication", status = "success", extract = { "username" } },
    { pattern = "session expired", event = "auth.session.expired", category = "authentication", status = "failure", extract = { "username" } },
}

local RELEASE_PATTERNS = {
    { pattern = "created release", event = "release.created", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "release created", event = "release.created", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "updated release", event = "release.updated", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "release updated", event = "release.updated", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "started release", event = "release.started", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "release started", event = "release.started", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "completed release", event = "release.completed", category = "release", status = "success", metric = "release_count", extract = { "release", "duration", "environment" } },
    { pattern = "release completed", event = "release.completed", category = "release", status = "success", metric = "release_count", extract = { "release", "duration", "environment" } },
    { pattern = "failed release", event = "release.failed", category = "release", status = "failure", metric = "release_count", extract = { "release", "duration", "environment" } },
    { pattern = "release failed", event = "release.failed", category = "release", status = "failure", metric = "release_count", extract = { "release", "duration", "environment" } },
    { pattern = "cancelled release", event = "release.cancelled", category = "release", status = "failure", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "release cancelled", event = "release.cancelled", category = "release", status = "failure", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "deleted release", event = "release.deleted", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
    { pattern = "release deleted", event = "release.deleted", category = "release", status = "success", metric = "release_count", extract = { "release", "environment" } },
}

local WORKFLOW_PATTERNS = {
    { pattern = "started workflow", event = "workflow.started", category = "workflow", status = "success", extract = { "workflow", "release", "environment" } },
    { pattern = "workflow started", event = "workflow.started", category = "workflow", status = "success", extract = { "workflow", "release", "environment" } },
    { pattern = "completed workflow", event = "workflow.completed", category = "workflow", status = "success", extract = { "workflow", "release", "duration", "environment" } },
    { pattern = "workflow completed", event = "workflow.completed", category = "workflow", status = "success", extract = { "workflow", "release", "duration", "environment" } },
    { pattern = "failed workflow", event = "workflow.failed", category = "workflow", status = "failure", extract = { "workflow", "release", "duration", "environment" } },
    { pattern = "workflow failed", event = "workflow.failed", category = "workflow", status = "failure", extract = { "workflow", "release", "duration", "environment" } },
}

local PHASE_PATTERNS = {
    { pattern = "started phase", event = "phase.started", category = "phase", status = "success", extract = { "phase", "release", "environment" } },
    { pattern = "phase started", event = "phase.started", category = "phase", status = "success", extract = { "phase", "release", "environment" } },
    { pattern = "completed phase", event = "phase.completed", category = "phase", status = "success", extract = { "phase", "release", "duration", "environment" } },
    { pattern = "phase completed", event = "phase.completed", category = "phase", status = "success", extract = { "phase", "release", "duration", "environment" } },
    { pattern = "failed phase", event = "phase.failed", category = "phase", status = "failure", extract = { "phase", "release", "duration", "environment" } },
    { pattern = "phase failed", event = "phase.failed", category = "phase", status = "failure", extract = { "phase", "release", "duration", "environment" } },
}

local TASK_PATTERNS = {
    { pattern = "started task", event = "task.started", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
    { pattern = "task started", event = "task.started", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
    { pattern = "completed task", event = "task.completed", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "duration", "environment" } },
    { pattern = "task completed", event = "task.completed", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "duration", "environment" } },
    { pattern = "failed task", event = "task.failed", category = "task", status = "failure", metric = "task_count", extract = { "task", "phase", "release", "duration", "environment" } },
    { pattern = "task failed", event = "task.failed", category = "task", status = "failure", metric = "task_count", extract = { "task", "phase", "release", "duration", "environment" } },
    { pattern = "skipped task", event = "task.skipped", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
    { pattern = "task skipped", event = "task.skipped", category = "task", status = "success", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
    { pattern = "retry task", event = "task.retry", category = "task", status = "failure", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
    { pattern = "retrying task", event = "task.retry", category = "task", status = "failure", metric = "task_count", extract = { "task", "phase", "release", "environment" } },
}

local PLUGIN_PATTERNS = {
    { pattern = "installing plugin", event = "plugin.started", category = "plugin", status = "success", extract = { "plugin" } },
    { pattern = "copying plugin", event = "plugin.started", category = "plugin", status = "success", extract = { "plugin" } },
    { pattern = "started plugin", event = "plugin.started", category = "plugin", status = "success", extract = { "plugin", "task", "release", "environment" } },
    { pattern = "plugin started", event = "plugin.started", category = "plugin", status = "success", extract = { "plugin", "task", "release", "environment" } },
    { pattern = "requires a restart", event = "plugin.completed", category = "plugin", status = "success", extract = { "plugin" } },
    { pattern = "successfully synced plugins", event = "plugin.completed", category = "plugin", status = "success" },
    { pattern = "completed plugin", event = "plugin.completed", category = "plugin", status = "success", extract = { "plugin", "task", "release", "duration", "environment" } },
    { pattern = "plugin completed", event = "plugin.completed", category = "plugin", status = "success", extract = { "plugin", "task", "release", "duration", "environment" } },
    { pattern = "failed plugin", event = "plugin.failed", category = "plugin", status = "failure", extract = { "plugin", "task", "release", "duration", "environment" } },
    { pattern = "plugin failed", event = "plugin.failed", category = "plugin", status = "failure", extract = { "plugin", "task", "release", "duration", "environment" } },
}

local REPOSITORY_PATTERNS = {
    { pattern = "connected repository", event = "repository.connected", category = "repository", status = "success", extract = { "repository", "environment" } },
    { pattern = "repository connected", event = "repository.connected", category = "repository", status = "success", extract = { "repository", "environment" } },
    { pattern = "failed repository", event = "repository.failed", category = "repository", status = "failure", extract = { "repository", "environment" } },
    { pattern = "repository failed", event = "repository.failed", category = "repository", status = "failure", extract = { "repository", "environment" } },
}

local SCHEDULER_PATTERNS = {
    { pattern = "started scheduler", event = "scheduler.started", category = "scheduler", status = "success", extract = { "duration" } },
    { pattern = "scheduler started", event = "scheduler.started", category = "scheduler", status = "success", extract = { "duration" } },
    { pattern = "executed scheduler", event = "scheduler.executed", category = "scheduler", status = "success", extract = { "duration" } },
    { pattern = "scheduler executed", event = "scheduler.executed", category = "scheduler", status = "success", extract = { "duration" } },
    { pattern = "failed scheduler", event = "scheduler.failed", category = "scheduler", status = "failure", extract = { "duration" } },
    { pattern = "scheduler failed", event = "scheduler.failed", category = "scheduler", status = "failure", extract = { "duration" } },
}

local API_PATTERNS = {
    { pattern = "api request", event = "api.request", category = "api", status = "success", extract = { "username", "duration" } },
    { pattern = "rest request", event = "api.request", category = "api", status = "success", extract = { "username", "duration" } },
    { pattern = "api error", event = "api.error", category = "api", status = "failure", extract = { "username", "duration" } },
    { pattern = "rest error", event = "api.error", category = "api", status = "failure", extract = { "username", "duration" } },
}

local EXCEPTION_PATTERNS = {
    { pattern = "runtimeexception", event = "exception.runtime", category = "exception", status = "failure", metric = "exception_count" },
    { pattern = "sqlexception", event = "exception.database", category = "exception", status = "failure", metric = "exception_count" },
    { pattern = "database", event = "exception.database", category = "exception", status = "failure", metric = "exception_count" },
    { pattern = "validation", event = "exception.validation", category = "exception", status = "failure", metric = "exception_count" },
    { pattern = "timeout", event = "exception.timeout", category = "exception", status = "failure", metric = "exception_count", extract = { "duration" } },
    { pattern = "exception", event = "exception.unknown", category = "exception", status = "failure", metric = "exception_count" },
}

local SYSTEM_PATTERNS = {
    { pattern = "digital.ai release version", event = "system.startup", category = "system", status = "success" },
    { pattern = "running in standalone mode", event = "system.startup", category = "system", status = "success" },
    { pattern = "authentication provider", event = "system.startup", category = "system", status = "success" },
    { pattern = "initializing type system", event = "system.startup", category = "system", status = "success" },
    { pattern = "registering bouncycastle", event = "system.startup", category = "system", status = "success" },
    { pattern = "starting plugin synchronization", event = "system.startup", category = "system", status = "success" },
    { pattern = "attempting plugin synchronization", event = "system.startup", category = "system", status = "success" },
    { pattern = "system started", event = "system.startup", category = "system", status = "success" },
    { pattern = "server started", event = "system.startup", category = "system", status = "success" },
    { pattern = "system stopped", event = "system.shutdown", category = "system", status = "success" },
    { pattern = "server stopped", event = "system.shutdown", category = "system", status = "success" },
}

local AUDIT_PATTERNS = {
    { pattern = "logged in", event = "audit.login", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "login", event = "audit.login", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "logout", event = "audit.logout", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "created release", event = "audit.release.create", category = "audit", status = "success", metric = "audit_count", extract = { "username", "release" } },
    { pattern = "updated release", event = "audit.release.update", category = "audit", status = "success", metric = "audit_count", extract = { "username", "release" } },
    { pattern = "deleted release", event = "audit.release.delete", category = "audit", status = "success", metric = "audit_count", extract = { "username", "release" } },
    { pattern = "permission", event = "audit.permission.change", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "configuration", event = "audit.configuration.change", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "created user", event = "audit.user.create", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "updated user", event = "audit.user.update", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "deleted user", event = "audit.user.delete", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
    { pattern = "role", event = "audit.role.change", category = "audit", status = "success", metric = "audit_count", extract = { "username" } },
}

local PATTERN_SETS = {
    authentication = AUTH_PATTERNS,
    release = RELEASE_PATTERNS,
    workflow = WORKFLOW_PATTERNS,
    phase = PHASE_PATTERNS,
    task = TASK_PATTERNS,
    plugin = PLUGIN_PATTERNS,
    repository = REPOSITORY_PATTERNS,
    scheduler = SCHEDULER_PATTERNS,
    api = API_PATTERNS,
    exception = EXCEPTION_PATTERNS,
    system = SYSTEM_PATTERNS,
    audit = AUDIT_PATTERNS,
}

local function as_string(value)
    if value == nil then
        return ""
    end
    return tostring(value)
end

function lower(value)
    return string.lower(as_string(value))
end

function contains(value, pattern)
    local text = lower(value)
    local needle = lower(pattern)
    if text == "" or needle == "" then
        return false
    end
    return string.find(text, needle, 1, true) ~= nil
end

local function first_match(text, patterns)
    local source = as_string(text)
    for _, pattern in ipairs(patterns) do
        local value = string.match(source, pattern)
        if value ~= nil and value ~= "" then
            return value
        end
    end
    return nil
end

local function tonumber_or_nil(value)
    if value == nil or value == "-" then
        return nil
    end
    return tonumber(value)
end

local function compact_record(record)
    for key, value in pairs(record) do
        if value == "" then
            record[key] = nil
        end
    end
end

local function remove_parser_fields(record)
    record.audit = nil
    record.bytes = nil
    record.component = nil
    record.duration = nil
    record.protocol = nil
    record.user = nil
end

function set_event(record, event, category)
    record.event = as_string(event)
    record.event_category = as_string(category)
end

function set_log_type(record, log_type)
    record.log_type = as_string(log_type)
end

function set_service(record)
    record.service = SERVICE_NAME
end

function set_parser_version(record)
    record.parser_version = PARSER_VERSION
end

function set_success(record)
    record.status = "success"
end

function set_failure(record)
    record.status = "failure"
end

function classify_unknown(record)
    set_event(record, "unknown", "unknown")
end

function inc_metric(record, metric_name)
    if metric_name == nil or metric_name == "" then
        return
    end
    local current = tonumber(record[metric_name]) or 0
    record[metric_name] = current + 1
end

function extract_username(record)
    if record.username ~= nil then
        record.username = as_string(record.username)
        return
    end
    if record.user ~= nil and record.user ~= "-" then
        record.username = as_string(record.user)
        return
    end
    local message = as_string(record.message)
    record.username = first_match(message, {
        "[Uu]ser%s+['\"]?([^'\"%s,%]]+)",
        "[Uu]sername%s+['\"]?([^'\"%s,%]]+)",
        "%s([%w._@%-]+)%s+%-%s+",
        "^([%w._@%-]+)%s+%-%s+",
    })
end

function extract_release(record)
    local message = as_string(record.message)
    record.release_name = first_match(message, {
        "[Rr]elease%s+['\"]([^'\"]+)['\"]",
        "[Rr]elease%s+%[([^%]]+)%]",
        "[Rr]elease%s+([^,%s][^,]+)",
    })
end

function extract_workflow(record)
    local message = as_string(record.message)
    record.workflow_name = first_match(message, {
        "[Ww]orkflow%s+['\"]([^'\"]+)['\"]",
        "[Ww]orkflow%s+%[([^%]]+)%]",
        "[Ww]orkflow%s+([^,%s][^,]+)",
    })
end

function extract_phase(record)
    local message = as_string(record.message)
    record.phase_name = first_match(message, {
        "[Pp]hase%s+['\"]([^'\"]+)['\"]",
        "[Pp]hase%s+%[([^%]]+)%]",
        "[Pp]hase%s+([^,%s][^,]+)",
    })
end

function extract_task(record)
    local message = as_string(record.message)
    record.task_name = first_match(message, {
        "[Tt]ask%s+['\"]([^'\"]+)['\"]",
        "[Tt]ask%s+%[([^%]]+)%]",
        "[Tt]ask%s+([^,%s][^,]+)",
    })
end

function extract_duration(record)
    local direct = tonumber_or_nil(record.duration)
    if direct ~= nil then
        record.duration_ms = direct
        return
    end
    local message = as_string(record.message)
    local milliseconds = first_match(message, { "(%d+)%s*ms", "(%d+)%s*milliseconds" })
    if milliseconds ~= nil then
        record.duration_ms = tonumber(milliseconds)
        return
    end
    local seconds = first_match(message, { "(%d+)%s*s", "(%d+)%s*seconds" })
    if seconds ~= nil then
        record.duration_ms = tonumber(seconds) * 1000
    end
end

function extract_environment(record)
    local message = as_string(record.message)
    record.environment = first_match(message, {
        "[Ee]nvironment%s+['\"]([^'\"]+)['\"]",
        "[Ee]nvironment%s+%[([^%]]+)%]",
        "[Ee]nvironment%s+([^,%s][^,]+)",
    })
end

local function extract_plugin(record)
    local message = as_string(record.message)
    record.plugin_name = first_match(message, {
        "[Ii]nstalling%s+plugin%s+([^%s,]+)",
        "[Cc]opying%s+plugin%s+([^%s,]+)",
        "[Pp]lugin%s+([^%s,]+)%s+requires",
        "[Pp]lugin%s+['\"]([^'\"]+)['\"]",
        "[Pp]lugin%s+%[([^%]]+)%]",
        "[Pp]lugin%s+([^,%s][^,]+)",
    })
end

local function extract_repository(record)
    local message = as_string(record.message)
    record.repository = first_match(message, {
        "[Rr]epository%s+['\"]([^'\"]+)['\"]",
        "[Rr]epository%s+%[([^%]]+)%]",
        "[Rr]epository%s+([^,%s][^,]+)",
        "([%w._%-]+%.Repository%[[^%]]+%])",
    })
end

function normalize_status(record, explicit_status)
    if explicit_status == "success" then
        set_success(record)
    elseif explicit_status == "failure" then
        set_failure(record)
    else
        local status_value = record.status or record.http_status
        local numeric_status = tonumber(status_value)
        if numeric_status ~= nil then
            record.http_status = numeric_status
            if numeric_status >= 200 and numeric_status < 400 then
                set_success(record)
            else
                set_failure(record)
            end
        elseif status_value ~= nil then
            record.status = lower(status_value)
        end
    end
end

local EXTRACTORS = {
    username = extract_username,
    release = extract_release,
    workflow = extract_workflow,
    phase = extract_phase,
    task = extract_task,
    duration = extract_duration,
    environment = extract_environment,
    plugin = extract_plugin,
    repository = extract_repository,
}

local function apply_extractors(record, extractor_names)
    if extractor_names == nil then
        return
    end
    for _, extractor_name in ipairs(extractor_names) do
        local extractor = EXTRACTORS[extractor_name]
        if extractor ~= nil then
            extractor(record)
        end
    end
end

local function normalize_numeric_fields(record)
    if record.bytes_sent ~= nil then
        record.bytes_sent = tonumber_or_nil(record.bytes_sent)
    elseif record.bytes ~= nil then
        record.bytes_sent = tonumber_or_nil(record.bytes)
    end
    if record.http_status ~= nil then
        record.http_status = tonumber_or_nil(record.http_status)
    end
    if record.duration_ms ~= nil then
        record.duration_ms = tonumber_or_nil(record.duration_ms)
    end
end

local function normalize_common(record, log_type)
    set_log_type(record, log_type)
    set_service(record)
    set_parser_version(record)
    if record.logger == nil then
        record.logger = record.audit or record.component
    end
    if record.message == nil and record.log ~= nil then
        record.message = as_string(record.log)
    end
end

local function rule_engine(record, pattern_tables)
    local message = as_string(record.message)
    for _, rules in ipairs(pattern_tables) do
        for _, rule in ipairs(rules) do
            if contains(message, rule.pattern) then
                set_event(record, rule.event, rule.category)
                normalize_status(record, rule.status)
                apply_extractors(record, rule.extract)
                inc_metric(record, rule.metric)
                compact_record(record)
                return true
            end
        end
    end
    return false
end

local function classify_application(record)
    local ordered_patterns = {}
    for _, category in ipairs(CATEGORY_ORDER) do
        table.insert(ordered_patterns, PATTERN_SETS[category])
    end
    return rule_engine(record, ordered_patterns)
end

local function classify_audit(record)
    return rule_engine(record, { PATTERN_SETS.audit })
end

local function classify_wrapper(record)
    return rule_engine(record, { PATTERN_SETS.exception, PATTERN_SETS.system })
end

local function handle_application(record)
    normalize_common(record, "application")
    if not classify_application(record) then
        classify_unknown(record)
    end
    normalize_numeric_fields(record)
    remove_parser_fields(record)
    compact_record(record)
    return record
end

local function handle_audit(record)
    normalize_common(record, "audit")
    extract_username(record)
    if not classify_audit(record) then
        classify_unknown(record)
    end
    normalize_numeric_fields(record)
    remove_parser_fields(record)
    compact_record(record)
    return record
end

local function handle_access(record)
    normalize_common(record, "access")
    set_event(record, "api.request", "api")
    normalize_status(record)
    extract_username(record)
    extract_duration(record)
    normalize_numeric_fields(record)
    remove_parser_fields(record)
    compact_record(record)
    return record
end

local function handle_wrapper(record)
    normalize_common(record, "wrapper")
    if not classify_wrapper(record) then
        classify_unknown(record)
    end
    normalize_numeric_fields(record)
    remove_parser_fields(record)
    compact_record(record)
    return record
end

local function dispatch(tag, record)
    if contains(tag, ".application") then
        return handle_application(record)
    end
    if contains(tag, ".audit") then
        return handle_audit(record)
    end
    if contains(tag, ".access") then
        return handle_access(record)
    end
    if contains(tag, ".wrapper") then
        return handle_wrapper(record)
    end
    normalize_common(record, "application")
    classify_unknown(record)
    return record
end

function cb_filter(tag, timestamp, record)
    local normalized = dispatch(tag, record or {})
    return 1, timestamp, normalized
end
