# Implementation Specification

## Multiline Parser

Implement timestamp-driven multiline parsing.

Every timestamp begins a new record.

Everything until the next timestamp belongs to the previous record.

Do not rely on Java stack trace keywords.

---

## Regex Parsers

Application

timestamp

thread

mdc

level

logger

message

Access

client_ip

username

timestamp

method

uri

protocol

http_status

bytes_sent

referer

user_agent

duration_ms

Wrapper

timestamp

level

component

message

Audit

timestamp

audit

message

No enrichment.

No business logic.

---

# Lua

Implement a single production-quality file.

```
lua/digitalai.lua
```

Architecture

```
cb_filter()

↓

Dispatcher

↓

handle_application()

handle_access()

handle_audit()

handle_wrapper()

↓

Category Classifiers

↓

Generic Rule Engine

↓

Helper Functions
```

Dispatcher contains no business logic.

---

# Classification Order

Authentication

Release

Workflow

Phase

Task

Plugin

Repository

Scheduler

API

Exception

System

Unknown

---

# Pattern Tables

Business logic must never contain hardcoded string matching.

Implement pattern tables.

Example

```lua
AUTH_PATTERNS = {

{
pattern="logged in",
event="auth.login.success",
category="authentication"
}

}
```

Handlers iterate pattern tables.

---

# Required Helper Functions

- set_event()
- set_log_type()
- set_service()
- set_parser_version()
- set_success()
- set_failure()
- classify_unknown()
- inc_metric()
- extract_username()
- extract_release()
- extract_workflow()
- extract_phase()
- extract_task()
- extract_duration()
- extract_environment()
- normalize_status()
- contains()
- lower()

---

# Generic Rule Engine

Must

- iterate pattern tables
- match rules
- assign event
- assign category
- normalize status
- extract entities
- increment metrics
- return boolean

---

# Log Types

application

audit

access

wrapper

---

# Event Categories

authentication

release

workflow

phase

task

audit

plugin

repository

scheduler

api

system

exception

unknown

---

# Event Taxonomy

Authentication

- auth.login.success
- auth.login.failed
- auth.logout
- auth.session.expired

Release

- release.created
- release.updated
- release.started
- release.completed
- release.failed
- release.cancelled
- release.deleted

Workflow

- workflow.started
- workflow.completed
- workflow.failed

Phase

- phase.started
- phase.completed
- phase.failed

Task

- task.started
- task.completed
- task.failed
- task.skipped
- task.retry

Plugin

- plugin.started
- plugin.completed
- plugin.failed

Repository

- repository.connected
- repository.failed

Scheduler

- scheduler.started
- scheduler.executed
- scheduler.failed

API

- api.request
- api.error

System

- system.startup
- system.shutdown

Exception

- exception.runtime
- exception.database
- exception.validation
- exception.timeout
- exception.unknown

Audit

- audit.login
- audit.logout
- audit.release.create
- audit.release.update
- audit.release.delete
- audit.permission.change
- audit.configuration.change
- audit.user.create
- audit.user.update
- audit.user.delete
- audit.role.change

Unknown

- unknown

---

# Normalized Fields

Core

- event
- event_category
- log_type
- service
- host
- timestamp
- logger
- level
- message
- parser_version
- thread
- mdc

Business

- username
- release_name
- workflow_name
- phase_name
- task_name
- plugin_name
- repository
- environment
- status

Access

- client_ip
- method
- uri
- http_status
- bytes_sent
- referer
- user_agent

Metrics

- duration_ms
- login_count
- release_count
- task_count
- audit_count
- exception_count

Numeric values must be emitted as Lua numbers.

---

# Fluent Bit

Implement

- filesystem buffering
- multiline parser
- regex parsers
- Lua filter
- OpenSearch output
- one SQLite DB per tail input
- retry forever
- bounded storage configuration
- production-safe defaults

---

# Code Quality

- Production quality
- No placeholder code
- No TODOs
- No duplicated logic
- Nil-safe
- Modular
- Well documented
- Ready for deployment
