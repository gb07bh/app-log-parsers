# VISUALIZATION_CATALOG.md

# Purpose

This document defines every visualization that should be created for the Digital.ai Release OpenSearch dashboards.

Each visualization includes:

- Dashboard
- Section
- Visualization Type
- Index Pattern
- Filter
- Aggregation
- Metric
- Fields Used
- Purpose

---

# Executive Dashboard

---

## 1. Releases Started

Dashboard
: Executive Overview

Section
: Release Health

Visualization
: Metric

Index
: digitalai-application-*

Filter

event = release.started

Metric

Count

Purpose

Number of releases started during the selected time range.

---

## 2. Releases Completed

Visualization
: Metric

Filter

event = release.completed

Metric

Count

Purpose

Completed releases.

---

## 3. Releases Failed

Visualization
: Metric

Filter

event = release.failed

Metric

Count

Purpose

Failed releases.

---

## 4. Release Success Rate

Visualization
: Formula Metric

Formula

release.completed /
(release.completed + release.failed)

Purpose

Overall platform success percentage.

---

## 5. Active Users

Visualization
: Metric

Aggregation

Unique Count

Field

username.keyword

Purpose

Unique users using the platform.

---

## 6. Exception Count

Visualization
: Metric

Filter

event_category = exception

Metric

Count

Purpose

Total exceptions.

---

## 7. Scheduler Failures

Visualization
: Metric

Filter

event = scheduler.failed

Metric

Count

Purpose

Scheduler health.

---

## 8. HTTP Error Rate

Visualization
: Formula Metric

Index

digitalai-access-*

Formula

status >= 400 /
total requests

Purpose

HTTP reliability.

---

## 9. Average Response Time

Visualization
: Metric

Index

digitalai-access-*

Aggregation

Average

Field

duration_ms

Purpose

Platform responsiveness.

---

## 10. Release Activity

Visualization
: Line Chart

Aggregation

Date Histogram

Split Series

event

Filter

event_category = release

Purpose

Release trend.

---

## 11. Workflow Activity

Visualization
: Line Chart

Filter

event_category = workflow

Purpose

Workflow trend.

---

## 12. Request Rate

Visualization
: Line Chart

Index

digitalai-access-*

Aggregation

Date Histogram

Metric

Count

Purpose

Traffic over time.

---

## 13. Exception Trend

Visualization
: Line Chart

Filter

event_category = exception

Purpose

Platform stability.

---

## 14. Release Status Distribution

Visualization
: Pie Chart

Field

event

Filter

event_category = release

Purpose

Release status distribution.

---

## 15. HTTP Status Distribution

Visualization
: Pie Chart

Index

digitalai-access-*

Field

http_status

Purpose

Response code distribution.

---

## 16. Log Level Distribution

Visualization
: Pie Chart

Field

level

Purpose

Log severity.

---

## 17. Top Failed Releases

Visualization
: Data Table

Aggregation

Terms

Field

release_name

Sort

Descending Count

Purpose

Most failing releases.

---

## 18. Top Exception Messages

Visualization
: Data Table

Field

message

Filter

event_category = exception

Purpose

Most common exceptions.

---

## 19. Top Active Users

Visualization
: Data Table

Field

username

Purpose

Most active users.

---

## 20. Top Plugins

Visualization
: Data Table

Field

plugin_name

Purpose

Most active plugins.

---

# Operations Dashboard

---

## 21. Release Timeline

Visualization

Line Chart

Split

release_name

Purpose

Release activity.

---

## 22. Running Releases

Visualization

Data Table

Filter

event = release.started

Purpose

Currently running releases.

---

## 23. Failed Releases

Visualization

Data Table

Filter

event = release.failed

Purpose

Release investigation.

---

## 24. Workflow Timeline

Visualization

Line Chart

Split

workflow_name

Purpose

Workflow activity.

---

## 25. Workflow Failures

Visualization

Bar Chart

Filter

event = workflow.failed

Purpose

Most failing workflows.

---

## 26. Failed Tasks

Visualization

Horizontal Bar Chart

Field

task_name

Filter

event = task.failed

Purpose

Top failed tasks.

---

## 27. Retried Tasks

Visualization

Bar Chart

Filter

event = task.retry

Purpose

Retry hotspots.

---

## 28. Plugin Installations

Visualization

Line Chart

Filter

plugin.started

Purpose

Plugin activity.

---

## 29. Plugin Failures

Visualization

Bar Chart

Filter

plugin.failed

Purpose

Plugin reliability.

---

## 30. Scheduler Timeline

Visualization

Line Chart

Filter

event_category = scheduler

Purpose

Scheduler activity.

---

## 31. Scheduler Failures

Visualization

Metric + Data Table

Filter

scheduler.failed

Purpose

Failed scheduler executions.

---

## 32. Login Trend

Visualization

Line Chart

Filter

event_category = authentication

Purpose

Authentication activity.

---

## 33. Login Failures

Visualization

Bar Chart

Filter

event = auth.login.failed

Purpose

Security monitoring.

---

## 34. Exception Timeline

Visualization

Line Chart

Filter

event_category = exception

Purpose

Exception trend.

---

## 35. Exception Distribution

Visualization

Pie Chart

Field

event

Purpose

Exception breakdown.

---

## 36. Top Exception Loggers

Visualization

Horizontal Bar Chart

Field

logger

Filter

event_category = exception

Purpose

Identify noisy components.

---

## 37. Request Rate

Visualization

Line Chart

Index

digitalai-access-*

Metric

Count

Purpose

Traffic monitoring.

---

## 38. Response Time Trend

Visualization

Line Chart

Metric

Average(duration_ms)

Purpose

Latency monitoring.

---

## 39. Slowest URLs

Visualization

Horizontal Bar Chart

Metric

Average(duration_ms)

Field

uri

Purpose

Performance bottlenecks.

---

## 40. HTTP Status Distribution

Visualization

Pie Chart

Field

http_status

Purpose

HTTP health.

---

## 41. Top Client IPs

Visualization

Horizontal Bar Chart

Field

client_ip

Purpose

Traffic sources.

---

## 42. Top User Agents

Visualization

Horizontal Bar Chart

Field

user_agent

Purpose

Client analysis.

---

## 43. Audit Timeline

Visualization

Line Chart

Index

digitalai-audit-*

Metric

Count

Purpose

Audit activity.

---

## 44. Configuration Changes

Visualization

Data Table

Filter

audit.configuration.change

Purpose

Configuration monitoring.

---

## 45. Permission Changes

Visualization

Data Table

Filter

audit.permission.change

Purpose

Security auditing.

---

## 46. Searchable Log Explorer

Visualization

Document Table

Columns

- timestamp
- level
- logger
- event
- username
- release_name
- workflow_name
- message

Purpose

Primary investigation table.

---

## 47. Raw Document Viewer

Visualization

Expanded Document View

Purpose

Display the complete OpenSearch document for any selected record.

Used for detailed troubleshooting and field verification.