# Bitbucket Repository Activity Reporting --- Coding Outline & Architecture

## 1. Purpose

Build a Flask-based internal reporting application that periodically
scans a Bitbucket instance and produces repository-level and user-level
activity reports.

The application must:

-   Scan selected Bitbucket projects and repositories.
-   Report total commits per repository.
-   Report total pull requests per repository.
-   Expand a repository to show users and their commit / pull-request
    activity.
-   Support arbitrary graph time-range selection with an automatically
    recalculated summary.
-   Support a month picker for monthly reporting.
-   Run on demand through a **Run Now** action.
-   Execute repository scans in parallel.
-   Persist generated reports in Artifactory.
-   Provide search by user ID, project name, and repository name.
-   Be fully controlled through YAML configuration.
-   Default to five parallel workers.
-   Be suitable for an ad-hoc monthly operational workflow.

> **Scope assumption:** "Bitbucket instance" means Bitbucket Server/Data
> Center or an equivalent self-hosted Bitbucket API. The API client must
> be isolated behind an adapter so the implementation can accommodate
> the exact Bitbucket version/API available in the environment.

------------------------------------------------------------------------

# 2. Functional Requirements

## 2.1 Repository metrics

For every selected repository, calculate:

-   Total commits in the selected reporting period.
-   Total pull requests in the selected reporting period.
-   Number of unique commit authors.
-   Number of unique pull-request authors.
-   Optional breakdown by day/month.

## 2.2 User drill-down

A repository must be expandable to show users such as:

  User      Commits   Pull Requests
  ------- --------- ---------------
  user1          42               7
  user2          18               3

The underlying data should retain enough detail to support future
metrics without rescanning Bitbucket.

Recommended stored event dimensions:

-   project key
-   project name
-   repository ID
-   repository name
-   repository slug
-   user ID
-   display name
-   event type
-   event timestamp
-   event ID/hash where available

## 2.4 Time-range selection

The UI must support:

-   Start date/time.
-   End date/time.
-   Preset ranges such as:
    -   Current month
    -   Previous month
    -   Last 7 days
    -   Last 30 days
    -   Custom
-   Selecting a range on the graph should update the summary
    automatically.

The preferred implementation is to store normalized event-level data and
perform aggregation in the reporting layer.

## 2.5 Month picker

Provide a month selector, for example:

`September 2026`

Selecting a month should automatically set:

`start = first day of month 00:00:00`

`end = first day of next month 00:00:00`

Use a half-open interval:

`start <= event_time < end`

This avoids end-of-day precision problems.

## 2.6 Search

Search must support:

-   User ID
-   Project key/name
-   Repository name/slug

Examples:

-   `john.doe`
-   `PROJ1`
-   `payment-service`

Search results should link to the relevant project/repository/user
detail view.

## 2.7 Run Now

A **Run Now** button must:

1.  Validate configuration.
2.  Create a report job.
3.  Return immediately to the UI.
4.  Execute the scan in the background.
5.  Process repositories in parallel.
6.  Show job progress/status.
7.  Store the completed report in Artifactory.
8.  Preserve job logs/errors.

The browser must not remain blocked while the report is being generated.

------------------------------------------------------------------------

# 3. High-Level Architecture

``` text
                         +----------------------+
                         |      Web Browser      |
                         |----------------------|
                         | Dashboard            |
                         | Graphs               |
                         | Search               |
                         | Month Picker         |
                         | Time Range Selector  |
                         | Run Now              |
                         +----------+-----------+
                                    |
                                    | HTTP/JSON
                                    v
                         +----------------------+
                         |      Flask App       |
                         |----------------------|
                         | REST API             |
                         | UI routes            |
                         | Auth middleware*     |
                         +----------+-----------+
                                    |
                    +---------------+----------------+
                    |                                |
                    v                                v
          +-------------------+             +-------------------+
          | Reporting Service |             | Job Service       |
          |-------------------|             |-------------------|
          | Aggregation       |             | Run management    |
          | Filtering         |             | Progress          |
          | Search            |             | Background jobs   |
          +---------+---------+             +---------+---------+
                    |                                 |
                    v                                 v
          +-------------------+             +-------------------+
          | Report Data Store |             | Worker Pool       |
          |-------------------|             |-------------------|
          | Raw events        |             | Default: 5        |
          | Aggregates        |             | Parallel repos    |
          | Job metadata      |             +---------+---------+
          +-------------------+                       |
                                                      |
                                                      v
                                          +----------------------+
                                          | Bitbucket API Client |
                                          |----------------------|
                                          | Projects             |
                                          | Repositories         |
                                          | Commits              |
                                          | Pull Requests        |
                                          +----------+-----------+
                                                     |
                                                     v
                                          +----------------------+
                                          | Bitbucket Instance   |
                                          +----------------------+

          +----------------------+
          | Artifactory          |
          |----------------------|
          | Monthly report JSON  |
          | Optional CSV         |
          | Optional HTML        |
          +----------^-----------+
                     |
                     |
              Report Publisher
```

`*` Authentication/authorization should use the organization's standard
mechanism rather than introducing a second identity system.

------------------------------------------------------------------------

# 4. Recommended Component Structure

``` text
app/
├── __init__.py
├── config/
│   ├── config.yaml
│   ├── config_loader.py
│   └── schema.py
│
├── api/
│   ├── routes.py
│   ├── report_routes.py
│   ├── search_routes.py
│   └── job_routes.py
│
├── bitbucket/
│   ├── client.py
│   ├── models.py
│   ├── pagination.py
│   └── adapter.py
│
├── jobs/
│   ├── manager.py
│   ├── worker.py
│   └── status.py
│
├── reporting/
│   ├── collector.py
│   ├── aggregator.py
│   ├── filters.py
│   ├── search.py
│   └── models.py
│
├── storage/
│   ├── repository.py
│   ├── local_store.py
│   └── artifactory.py
│
├── templates/
│   ├── dashboard.html
│   ├── report.html
│   └── job.html
│
├── static/
│   ├── css/
│   └── js/
│
└── main.py

tests/
├── unit/
├── integration/
└── fixtures/

config/
└── config.yaml

requirements.txt
Dockerfile
README.md
```

------------------------------------------------------------------------

# 5. YAML Configuration

A starting configuration should look like:

``` yaml
application:
  name: bitbucket-activity-report
  environment: production

bitbucket:
  api:
    # Keep the API version/path configurable because Bitbucket
    # Server/Data Center versions can expose different API paths.
    base_url: "https://bitbucket.example.com"
    api_path: "/rest/api/latest"

  credentials:
    # Prefer environment-variable references or a secret manager.
    # Do not commit actual credentials to source control.
    username_env: "BITBUCKET_USERNAME"
    password_env: "BITBUCKET_PASSWORD"
    # Alternatively:
    # token_env: "BITBUCKET_TOKEN"

  projects:
    # Empty list means all projects.
    keys: []

  repositories:
    # Integer = first N repositories per project.
    # "NA" = all repositories.
    limit: "NA"

report:
  storage:
    provider: "artifactory"
    base_url: "https://artifactory.example.com"
    path: "bitbucket-reports/monthly"

    credentials:
      username_env: "ARTIFACTORY_USERNAME"
      password_env: "ARTIFACTORY_PASSWORD"

  formats:
    - json
    - csv

workers:
  count: 5

execution:
  background: true
  timeout_seconds: 3600
  retry_count: 2

run_now:
  # When false, the Run Now UI action must be disabled/hidden
  # and the manual-run API must reject requests.
  enabled: true

logging:
  level: INFO

  # Component-specific levels may override the global level.
  components:
    flask: INFO
    api: INFO
    bitbucket_client: INFO
    collector: INFO
    repository_worker: INFO
    job_manager: INFO
    aggregator: INFO
    search: INFO
    storage: INFO
    artifactory: INFO
    frontend: INFO
```

## Configuration semantics

### Project selection

``` yaml
projects:
  keys:
    - PROJ1
    - PROJ2
```

Only the listed project keys are processed.

An empty list:

``` yaml
projects:
  keys: []
```

means all accessible projects.

### Repository selection

``` yaml
repositories:
  limit: 10
```

means the first 10 repositories returned for each selected project.

``` yaml
repositories:
  limit: "NA"
```

means all repositories.

The exact meaning of "first" should be deterministic. Prefer an explicit
Bitbucket ordering such as repository ID/name rather than relying on an
unstable API order.

------------------------------------------------------------------------

# 6. API Client Design

Do not put Bitbucket HTTP calls directly into Flask routes.

Use an interface:

``` python
class BitbucketClient:
    def list_projects(self):
        ...

    def list_repositories(self, project_key):
        ...

    def list_commits(self, project_key, repo_slug, start, end):
        ...

    def list_pull_requests(self, project_key, repo_slug, start, end):
        ...
```

A separate adapter can implement the exact Bitbucket API:

``` text
BitbucketClient
       |
       +-- BitbucketServerClient
       |
       +-- BitbucketDataCenterClient
       |
       +-- FutureBitbucketClient
```

This keeps the reporting application independent of the exact Bitbucket
API version.

## Pagination

Every Bitbucket collection API must be treated as paginated.

Never assume that a single API request returns all:

-   Projects
-   Repositories
-   Commits
-   Pull requests

Create a reusable pagination helper:

``` python
def paginate(fetch_page):
    start = 0

    while True:
        page = fetch_page(start)

        for item in page["values"]:
            yield item

        if page.get("isLastPage", True):
            break

        start = page["nextPageStart"]
```

The implementation should also handle APIs that expose pagination
differently.

------------------------------------------------------------------------

# 7. Data Collection Strategy

The recommended pipeline is:

``` text
Discover Projects
       |
       v
Select Projects
       |
       v
Discover Repositories
       |
       v
Apply Repository Limit
       |
       v
Create Repository Jobs
       |
       v
+------+------+------+------+------+
| Repo | Repo | Repo | Repo | Repo |
|  1   |  2   |  3   |  4   |  5   |
+------+------+------+------+------+
       |
       v
Collect commits + pull requests
       |
       v
Normalize events
       |
       v
Persist data
       |
       v
Aggregate
       |
       v
Generate report
       |
       v
Publish to Artifactory
```

------------------------------------------------------------------------

# 8. Parallel Execution

The requested default is five workers.

For an I/O-heavy workload, a thread pool is a reasonable initial
implementation:

``` python
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=config.workers) as executor:
    futures = [
        executor.submit(process_repository, repo)
        for repo in repositories
    ]
```

## Important rule

The parallel unit should be the **repository**, not individual API
requests.

For example:

``` text
Worker 1 -> Project A / Repo 1
Worker 2 -> Project A / Repo 2
Worker 3 -> Project B / Repo 1
Worker 4 -> Project B / Repo 2
Worker 5 -> Project C / Repo 1
```

This makes job tracking, retries, and error handling simpler.

## API rate limiting

The worker pool must not blindly generate unlimited requests.

Implement:

-   configurable request timeout
-   retries with exponential backoff
-   handling of HTTP 429
-   handling of transient 5xx responses
-   maximum retry count
-   connection pooling

------------------------------------------------------------------------

# 9. Background Job Model

The Run Now request should create a job:

``` text
POST /api/reports/run
       |
       v
job_id = 20260905-130700-abc123
       |
       +--> status = QUEUED
       |
       v
Background worker
       |
       +--> RUNNING
       |
       +--> 20/100 repositories
       |
       +--> 80/100 repositories
       |
       +--> COMPLETED
       |
       v
Artifactory publication
```

Suggested job states:

``` text
QUEUED
RUNNING
COMPLETED
FAILED
PARTIAL_SUCCESS
CANCELLED
```

Suggested API:

``` text
POST /api/reports/run
GET  /api/reports/jobs/{job_id}
GET  /api/reports/jobs
```

Example response:

``` json
{
  "job_id": "20260905-130700-abc123",
  "status": "RUNNING",
  "total_repositories": 100,
  "completed_repositories": 42,
  "failed_repositories": 1
}
```

------------------------------------------------------------------------

# 10. Storage Architecture

Separate the logical report repository from the physical Artifactory
implementation.

``` python
class ReportStorage:
    def publish(self, report, metadata):
        ...

    def get_report(self, report_id):
        ...

    def list_reports(self):
        ...
```

Implementation:

``` text
ReportStorage
      |
      +-- ArtifactoryStorage
      |
      +-- LocalStorage (development/testing)
```

This makes local development possible without requiring Artifactory.

------------------------------------------------------------------------

# 11. Artifactory Report Layout

Recommended layout:

``` text
bitbucket-reports/
└── YYYY/
    └── MM/
        └── YYYY-MM/
            ├── report.json
            ├── report.csv
            └── metadata.json
```

Example:

``` text
bitbucket-reports/
└── 2026/
    └── 09/
        └── 2026-09/
            ├── report.json
            ├── report.csv
            └── metadata.json
```

For repeatable/ad-hoc runs, use a run-specific directory:

``` text
bitbucket-reports/
└── 2026/
    └── 09/
        └── 20260905-130700-abc123/
            ├── report.json
            ├── report.csv
            └── metadata.json
```

`metadata.json` should contain:

``` json
{
  "job_id": "20260905-130700-abc123",
  "generated_at": "2026-09-05T13:07:00+05:30",
  "period_start": "2026-09-01T00:00:00+05:30",
  "period_end": "2026-10-01T00:00:00+05:30",
  "projects": [],
  "repository_limit": "NA",
  "worker_count": 5,
  "status": "COMPLETED"
}
```

------------------------------------------------------------------------

# 12. Report Data Model

A normalized internal model is preferable to storing only final totals.

## Repository

``` json
{
  "project_key": "PAY",
  "project_name": "Payments",
  "repository_id": "12345",
  "repository_slug": "payment-service",
  "repository_name": "payment-service"
}
```

## Activity event

``` json
{
  "project_key": "PAY",
  "repository_slug": "payment-service",
  "event_type": "commit",
  "event_id": "abc123",
  "user_id": "john.doe",
  "display_name": "John Doe",
  "event_time": "2026-09-05T10:30:00Z"
}
```

Pull-request events can use:

``` json
{
  "event_type": "pull_request",
  "event_id": "456",
  "user_id": "john.doe",
  "event_time": "2026-09-05T11:00:00Z"
}
```

This allows the same data to power:

-   repository totals
-   user drill-down
-   graphs
-   date filtering
-   month filtering
-   search
-   future reports

------------------------------------------------------------------------

# 13. Aggregation Model

For a selected period:

``` python
repository_summary = {
    "commit_count": 0,
    "pull_request_count": 0,
    "users": {}
}
```

User aggregation:

``` python
users[user_id] = {
    "commit_count": 0,
    "pull_request_count": 0
}
```

Repository result:

``` json
{
  "project": "Payments",
  "repository": "payment-service",
  "commits": 125,
  "pull_requests": 37,
  "users": [
    {
      "user_id": "john.doe",
      "commits": 80,
      "pull_requests": 20
    },
    {
      "user_id": "jane.doe",
      "commits": 45,
      "pull_requests": 17
    }
  ]
}
```

------------------------------------------------------------------------

# 14. Graph / Dashboard Design

The dashboard should have four major areas.

``` text
+-------------------------------------------------------------+
| Bitbucket Activity Report                   [ RUN NOW ]     |
+-------------------------------------------------------------+
| Month: [ September 2026 v ]                                 |
| From:  [ 01-Sep-2026 ]  To: [ 30-Sep-2026 ]               |
+-------------------------------------------------------------+
| Total Commits | Total PRs | Repositories | Active Users     |
|     4,382     |    921    |      87      |      143         |
+-------------------------------------------------------------+
|                                                             |
| Commit / PR Activity Over Time                              |
|                                                             |
|                    GRAPH                                    |
|                                                             |
+-------------------------------------------------------------+
| Project / Repository                                       |
|                                                             |
| > PAY / payment-service      125 commits     37 PRs        |
|   > john.doe                   80 commits     20 PRs        |
|   > jane.doe                   45 commits     17 PRs        |
|                                                             |
| > PAY / invoice-service        91 commits     21 PRs        |
+-------------------------------------------------------------+
| Search: [ user / project / repository                 ]    |
+-------------------------------------------------------------+
```

------------------------------------------------------------------------

# 15. Graph Time Selection

The graph should emit:

``` text
rangeSelected(start, end)
```

The frontend then requests:

``` text
GET /api/reports/summary?from=...&to=...
```

The server returns:

``` json
{
  "period": {
    "from": "2026-09-05T09:00:00Z",
    "to": "2026-09-05T13:00:00Z"
  },
  "commits": 53,
  "pull_requests": 12,
  "active_users": 18,
  "repositories": 7
}
```

This is preferable to recalculating the entire report in the browser.

------------------------------------------------------------------------

# 16. Search API

Suggested endpoint:

``` text
GET /api/search?q=john.doe
```

Response:

``` json
{
  "query": "john.doe",
  "results": [
    {
      "type": "user",
      "user_id": "john.doe",
      "repositories": 12,
      "commits": 420,
      "pull_requests": 85
    }
  ]
}
```

For repository search:

``` text
GET /api/search?q=payment-service
```

The search implementation can initially use database indexes or an
in-memory index if the report volume is small.

If the dataset becomes large, introduce a dedicated search backend
later.

------------------------------------------------------------------------

# 17. Suggested API Surface

## Report APIs

``` text
POST /api/reports/run

GET /api/reports/jobs
GET /api/reports/jobs/{job_id}

GET /api/reports/latest

GET /api/reports/summary
GET /api/reports/repositories/{repository_id}
GET /api/reports/repositories/{repository_id}/users
```

## Search

``` text
GET /api/search?q=<query>
```

## Health

``` text
GET /health
GET /ready
```

## Configuration

Do not expose credentials.

A safe configuration endpoint may expose only non-secret operational
settings:

``` text
GET /api/config
```

Example:

``` json
{
  "worker_count": 5,
  "repository_limit": "NA",
  "configured_projects": []
}
```

------------------------------------------------------------------------

# 18. Error Handling

One failed repository should not necessarily fail the entire report.

Recommended behavior:

``` text
100 repositories
      |
      +-- 96 successful
      +-- 4 failed
              |
              v
       PARTIAL_SUCCESS
```

The report should include an error section:

``` json
{
  "errors": [
    {
      "project": "PAY",
      "repository": "legacy-service",
      "operation": "pull_requests",
      "status": 403,
      "message": "Permission denied"
    }
  ]
}
```

Do not store credentials or authorization headers in logs.

------------------------------------------------------------------------

# 19. Security Requirements

## Credentials

Credentials must never be stored directly in `config.yaml`.

Use:

``` yaml
username_env: BITBUCKET_USERNAME
password_env: BITBUCKET_PASSWORD
```

or a supported secret manager.

## Transport

Use HTTPS for:

-   Bitbucket
-   Artifactory
-   Application access where applicable

## Access control

The application should have at least:

-   authenticated user access
-   permission to run reports
-   permission to view reports

Ideally:

``` text
REPORT_VIEWER
REPORT_OPERATOR
REPORT_ADMIN
```

## Logging

Never log:

-   passwords
-   access tokens
-   Authorization headers
-   cookies

------------------------------------------------------------------------

# 20. Concurrency and Consistency

The report should capture a single logical reporting window.

For example:

``` text
September 1 00:00:00
        |
        +--- report job starts
        |
        +--- repositories collected
        |
        +--- aggregation
        |
        +--- report generated
        |
September 30 23:59:59
```

For repeatability, store the exact:

-   start timestamp
-   end timestamp
-   configuration version/hash
-   application version
-   job ID

with every report.

------------------------------------------------------------------------

# 21. Idempotency

A monthly report can be rerun.

Example:

``` text
2026-09 report
     |
     +-- Run 1
     +-- Run 2
     +-- Run 3
```

Do not overwrite previous runs unless explicitly requested.

Store each run independently.

Mark one report as:

``` text
latest = true
```

if the UI needs a "latest report" concept.

------------------------------------------------------------------------

# 22. Performance Strategy

Potential bottlenecks:

1.  Number of repositories.
2.  Number of commits.
3.  Number of pull requests.
4.  API pagination.
5.  Bitbucket server response time.
6.  Artifactory upload time.

Recommended optimizations:

-   repository-level parallelism
-   HTTP connection pooling
-   pagination
-   configurable worker count
-   retries only for transient failures
-   avoid fetching unnecessary fields
-   incremental processing where supported
-   persist normalized results
-   cache project/repository metadata
-   aggregate after collection rather than repeatedly querying Bitbucket

------------------------------------------------------------------------

# 23. Incremental Reporting --- Future Enhancement

The first version can scan the requested month.

A later version can maintain a checkpoint:

``` text
last_successful_collection_time
```

Then collect only new activity.

This can substantially reduce API load.

However, the initial implementation should prioritize correctness and
simplicity over incremental synchronization.

------------------------------------------------------------------------

# 24. Timezone Rules

Use UTC internally.

Store timestamps as:

``` text
ISO-8601 UTC
```

For example:

``` text
2026-09-05T07:30:00Z
```

The UI can display the configured/business timezone.

The configured timezone should ideally be explicit:

``` yaml
report:
  timezone: "Asia/Kolkata"
```

Monthly boundaries should be calculated in that timezone and then
converted to UTC for API queries.

------------------------------------------------------------------------

# 25. Suggested Technology Stack

## Backend

-   Python 3.11+
-   Flask
-   requests/httpx
-   PyYAML
-   Pydantic or JSON Schema for configuration validation
-   concurrent.futures initially

## Persistence

For a small/medium deployment:

-   SQLite for development
-   PostgreSQL recommended for production

The database is useful for:

-   job state
-   normalized activity
-   report metadata
-   search indexes
-   aggregation

Artifactory remains the system of record for generated report artifacts.

## Frontend

Keep the first version lightweight:

-   Server-rendered Flask templates or a small JavaScript frontend.
-   Existing Graphs plugin can be used as the visualization layer if it
    supports the required interaction hooks.
-   Otherwise use the plugin for presentation where possible and expose
    the report APIs as the data source.

The architecture should not make the reporting engine dependent on a
particular charting library.

------------------------------------------------------------------------

# 26. Testing Strategy

## Unit tests

Test:

-   YAML loading
-   configuration validation
-   project filtering
-   repository limit
-   pagination
-   date filtering
-   month boundaries
-   commit aggregation
-   PR aggregation
-   user aggregation
-   search
-   retry handling

## Integration tests

Mock Bitbucket API responses and test:

``` text
project -> repositories -> commits/PRs -> report
```

Test Artifactory upload using a test repository or mock HTTP server.

## Failure tests

Simulate:

-   Bitbucket timeout
-   401/403
-   404
-   429
-   500/502/503
-   malformed API response
-   Artifactory unavailable
-   one worker failure
-   all workers failing

## UI tests

Test:

-   Run Now
-   job status
-   graph time selection
-   month picker
-   repository expansion
-   user expansion
-   search

------------------------------------------------------------------------

# 27. Observability

Every report run should have a correlation/job ID.

Example log:

``` text
job=20260905-130700-abc123
project=PAY
repo=payment-service
operation=commits
status=success
duration_ms=1820
```

Metrics worth exposing:

``` text
reports_started_total
reports_completed_total
reports_failed_total
repositories_processed_total
repositories_failed_total
bitbucket_api_requests_total
bitbucket_api_errors_total
report_duration_seconds
```

------------------------------------------------------------------------

# 28. Deployment

Recommended container:

``` text
                    +------------------+
                    | Reverse Proxy    |
                    +--------+---------+
                             |
                             v
                    +------------------+
                    | Flask Application |
                    +--------+---------+
                             |
              +--------------+--------------+
              |                             |
              v                             v
       +--------------+              +--------------+
       | PostgreSQL   |              | Artifactory  |
       +--------------+              +--------------+
                             |
                             v
                     Bitbucket Server
```

For the first implementation, Flask plus an in-process background
executor may be sufficient for a single-instance deployment.

For production/high availability, move background execution to a
dedicated job queue/worker architecture.

Examples of a future worker layer:

``` text
Flask
  |
  v
Job Queue
  |
  +--> Worker 1
  +--> Worker 2
  +--> Worker 3
  +--> Worker 4
  +--> Worker 5
```

A queue-backed architecture also prevents a Flask process restart from
losing active jobs.

------------------------------------------------------------------------

# 29. Recommended MVP Phases

## Phase 1 --- Core collector

Implement:

-   YAML configuration
-   Bitbucket client
-   project selection
-   repository selection
-   repository limit
-   commit collection
-   PR collection
-   pagination
-   five-worker parallel processing

Deliverable:

``` text
CLI/API -> JSON report
```

## Phase 2 --- Persistent reporting

Implement:

-   normalized event storage
-   job metadata
-   aggregation
-   report metadata
-   Artifactory publishing

Deliverable:

``` text
Run -> persisted report -> Artifactory
```

## Phase 3 --- Flask UI

Implement:

-   dashboard
-   Run Now
-   job status
-   month picker
-   repository table
-   user drill-down

## Phase 4 --- Graph integration

Implement:

-   commits over time
-   PRs over time
-   repository comparison
-   graph range selection
-   dynamic selected-range summary

## Phase 5 --- Search

Implement:

-   user search
-   project search
-   repository search
-   detail navigation

## Phase 6 --- Production hardening

Implement:

-   authentication/authorization
-   retry/backoff
-   rate limiting
-   observability
-   automated tests
-   container deployment
-   queue-backed workers if required

------------------------------------------------------------------------

# 30. Coding Outline

A logical implementation sequence:

``` text
1. Define configuration schema
2. Implement config loader
3. Implement secret/environment-variable resolver
4. Implement Bitbucket HTTP client
5. Implement pagination
6. Implement project discovery
7. Implement repository discovery
8. Apply project/repository filters
9. Implement commit collector
10. Implement pull-request collector
11. Normalize activity events
12. Implement repository worker
13. Implement worker pool
14. Implement job manager
15. Implement persistence
16. Implement aggregation service
17. Implement Artifactory publisher
18. Implement report APIs
19. Implement search API
20. Build dashboard
21. Add month picker
22. Add graph time-range selection
23. Add repository/user drill-down
24. Add Run Now and job progress
25. Add security
26. Add tests
27. Add logging/metrics
28. Containerize
29. Deploy to test environment
30. Run a complete monthly report and validate totals
```

------------------------------------------------------------------------

# 31. Key Design Decision: Raw Events vs Only Aggregates

**Recommendation: store normalized activity events plus report
metadata.**

Do not store only:

``` text
Repo A = 100 commits
```

Instead retain enough information to derive:

``` text
Repo A
  100 commits
  30 PRs

  user1
    60 commits
    10 PRs

  user2
    40 commits
    20 PRs
```

and time-series data:

``` text
Sep 01 -> 5 commits
Sep 02 -> 8 commits
Sep 03 -> 12 commits
...
```

This is what makes requirements #3 and #4 straightforward.

------------------------------------------------------------------------

# 32. Key Design Decision: Artifactory vs Database

Use both for different purposes.

### Database

Use for:

-   querying
-   search
-   time filtering
-   job status
-   dashboard APIs
-   aggregation

### Artifactory

Use for:

-   durable report artifacts
-   monthly report archive
-   downloading/exporting reports
-   retaining generated snapshots

Conceptually:

``` text
Bitbucket
    |
    v
Collection
    |
    v
Database <---- Dashboard/Search
    |
    v
Report Generator
    |
    v
Artifactory <---- Monthly archive
```

------------------------------------------------------------------------

# 33. Acceptance Criteria

The implementation is complete when:

### Collection

-   [ ] All configured projects can be scanned.
-   [ ] Empty project list scans all accessible projects.
-   [ ] Repository limit supports an integer.
-   [ ] Repository limit supports `NA`.
-   [ ] Commits are counted correctly.
-   [ ] Pull requests are counted correctly.
-   [ ] Pagination is handled correctly.

### User reporting

-   [ ] Repository can be expanded.
-   [ ] User commit totals are displayed.
-   [ ] User PR totals are displayed.

### Time filtering

-   [ ] Custom date range works.
-   [ ] Graph selection updates summary.
-   [ ] Month picker works.
-   [ ] Timezone handling is deterministic.

### Search

-   [ ] User ID search works.
-   [ ] Project search works.
-   [ ] Repository search works.

### Execution

-   [ ] Run Now does not block the browser.
-   [ ] Default worker count is 5.
-   [ ] Repositories execute in parallel.
-   [ ] Job status is visible.
-   [ ] Partial failures are recorded.

### Storage

-   [ ] Reports are published to Artifactory.
-   [ ] Each run has a unique report location.
-   [ ] Report metadata is stored.
-   [ ] Previous monthly runs remain accessible.

### Configuration

-   [ ] API path is configurable.
-   [ ] Base URL is configurable.
-   [ ] Credentials come from secure references.
-   [ ] Artifactory path is configurable.
-   [ ] Project selection is configurable.
-   [ ] Repository limit is configurable.
-   [ ] Worker count is configurable.

------------------------------------------------------------------------

# 34. Important Open Questions Before Coding

The following should be confirmed before implementation:

1.  **Exact Bitbucket product/version**
    -   Bitbucket Server or Data Center?
    -   Exact version?
2.  **Graphs plugin**
    -   Exact Stillsoft plugin name/version?
    -   Does it expose an API/extension mechanism?
    -   Is the requirement to embed this application into Bitbucket, or
        is the application external?
3.  **Authentication**
    -   Personal access token?
    -   Username/password?
    -   Service account?
    -   SSO?
4.  **Artifactory**
    -   Generic repository or another repository type?
    -   Existing repository name?
    -   Required authentication method?
5.  **Data retention**
    -   How many months/years should reports remain searchable?
    -   Should raw events be retained, or only generated monthly
        snapshots?
6.  **Pull-request definition**
    -   Count all PRs created during the period?
    -   Or PRs updated/merged during the period?
    -   The user requirement currently says "PR made/create", so this
        needs an explicit definition.
7.  **Commit definition**
    -   Count commits authored by a user?
    -   Or commits pushed by a user?
    -   Merge commits included?
8.  **Identity mapping**
    -   Should Bitbucket user ID be the primary user key?
    -   What should happen for deleted/deactivated users?
9.  **Repository selection**
    -   What does "first N" mean?
    -   Alphabetical?
    -   Repository ID?
    -   Bitbucket API default order?
10. **Scale**

-   Approximate number of projects?
-   Approximate repositories?
-   Approximate commits/PRs per month?

These answers affect the storage model and API implementation more than
the Flask UI itself.

------------------------------------------------------------------------

# 35. Recommended Final Architecture

For the stated requirements, the recommended first production design is:

``` text
                         Bitbucket
                            |
                            v
                    +---------------+
                    | API Adapter    |
                    +-------+-------+
                            |
                            v
                    +---------------+
                    | Repository Job|
                    | Coordinator   |
                    +-------+-------+
                            |
                     Thread Pool (5)
              +-------------+-------------+
              |             |             |
              v             v             v
           Repo A        Repo B        Repo C
              |             |             |
              +-------------+-------------+
                            |
                            v
                    +---------------+
                    | Normalization |
                    +-------+-------+
                            |
                            v
                    +---------------+
                    | PostgreSQL    |
                    | Events/Jobs   |
                    +-------+-------+
                            |
              +-------------+-------------+
              |                           |
              v                           v
      Flask REST API                Report Generator
              |                           |
              v                           v
        Dashboard UI                 Artifactory
              |
              +--> Graphs
              +--> Search
              +--> Month Picker
              +--> Time Range
              +--> Drill-down
              +--> Run Now
```

## Architectural principles

1.  **Separate collection from presentation.**
2.  **Use an API adapter for Bitbucket.**
3.  **Store normalized events so arbitrary date ranges are possible.**
4.  **Treat repository as the primary parallel execution unit.**
5.  **Keep Artifactory as report artifact storage, not the query
    database.**
6.  **Keep all environment-specific values in YAML/secret references.**
7.  **Make report runs immutable and identifiable by job ID.**
8.  **Design the graph layer as replaceable.**
9.  **Use UTC internally and an explicit business timezone for monthly
    boundaries.**
10. **Build the MVP around correctness and pagination before
    optimizing.**
