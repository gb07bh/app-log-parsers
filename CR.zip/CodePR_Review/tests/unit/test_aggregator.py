from app.bitbucket.models import Repository, CommitEvent, PullRequestEvent
from app.reporting.models import ReportMetadata
from app.reporting.aggregator import Aggregator
from app.reporting.exporter import Exporter


def test_aggregator_build_report():
    metadata = ReportMetadata(
        job_id="test-job-01",
        trace_id="trace-01",
        generated_at="2026-09-05T12:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z",
        projects_configured=["PAY"],
        repository_limit=10,
        worker_count=2,
        status="COMPLETED",
        total_repositories=1,
        completed_repositories=1,
        failed_repositories=0,
        errors=[]
    )

    repos = [
        Repository(slug="repo-1", name="Repo One", id=1, project_key="PAY", project_name="Payments")
    ]

    commits = {
        "repo-1": [
            CommitEvent(
                event_id="c1", project_key="PAY", repo_slug="repo-1",
                user_id="user1", display_name="User One", timestamp="2026-09-02T10:00:00Z",
                lines_added=120, lines_deleted=20
            ),
            CommitEvent(
                event_id="c2", project_key="PAY", repo_slug="repo-1",
                user_id="user2", display_name="User Two", timestamp="2026-09-03T11:00:00Z",
                lines_added=80, lines_deleted=30
            )
        ]
    }

    prs = {
        "repo-1": [
            PullRequestEvent(
                event_id="pr1", project_key="PAY", repo_slug="repo-1",
                user_id="user1", display_name="User One", created_date="2026-09-02T12:00:00Z"
            )
        ]
    }

    report = Aggregator.build_report(metadata, repos, commits, prs)

    assert report.total_commits == 2
    assert report.total_pull_requests == 1
    assert report.total_repositories == 1
    assert report.total_active_users == 2
    assert report.total_lines_added == 200
    assert report.total_lines_deleted == 50

    # Check EfficiencyMetrics
    assert report.efficiency is not None
    assert report.efficiency.avg_commits_per_repo == 2.0
    assert report.efficiency.avg_commits_per_project == 2.0
    assert report.efficiency.avg_commits_per_user == 1.0
    assert report.efficiency.avg_prs_per_repo == 1.0
    assert report.efficiency.avg_prs_per_user == 0.5
    # (200 + 50) / 2 = 125.0
    assert report.efficiency.avg_lines_per_commit == 125.0
    assert report.efficiency.net_lines_changed == 150

    # Check user drilldown for user1
    repo_summary = report.repositories[0]
    user1_stat = next(u for u in repo_summary.users if u.user_id == "user1")
    assert user1_stat.commits == 1
    assert user1_stat.pull_requests == 1
    assert user1_stat.lines_added == 120
    assert user1_stat.lines_deleted == 20

    # Check CSV export
    csv_text = Exporter.to_csv(report)
    assert "User One" in csv_text
    assert "repo-1" in csv_text
    assert "Total Repo Lines Added" in csv_text
    assert "User Net Lines" in csv_text

    # Check slice_timeline
    sliced = Aggregator.slice_timeline(report, from_date="2026-09-02", to_date="2026-09-02")
    assert sliced["commits"] == 1
    assert sliced["lines_added"] == 120
    assert sliced["lines_deleted"] == 20
    assert sliced["net_lines_changed"] == 100
    assert sliced["avg_lines_per_commit"] == 140.0
