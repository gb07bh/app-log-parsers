import pytest
from app.reporting.aggregator import Aggregator
from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity,
    EfficiencyMetrics
)
from app.storage.file_store import FileStore
from app.storage.resolver import ReportResolver


def test_quarter_conversion_helpers():
    assert Aggregator.month_to_quarter("2026-01") == "2026-Q1"
    assert Aggregator.month_to_quarter("2026-03") == "2026-Q1"
    assert Aggregator.month_to_quarter("2026-04") == "2026-Q2"
    assert Aggregator.month_to_quarter("2026-08") == "2026-Q3"
    assert Aggregator.month_to_quarter("2026-09") == "2026-Q3"
    assert Aggregator.month_to_quarter("2026-11") == "2026-Q4"

    q3_months = Aggregator.quarter_to_months("2026-Q3")
    assert q3_months == ["2026-07", "2026-08", "2026-09"]

    q1_months = Aggregator.quarter_to_months("2026-Q1")
    assert q1_months == ["2026-01", "2026-02", "2026-03"]


def test_compute_efficiency_metrics():
    eff = Aggregator.compute_efficiency_metrics(
        total_commits=100,
        total_prs=25,
        total_lines_added=15000,
        total_lines_deleted=3000,
        num_repos=2,
        num_projects=1,
        num_users=5
    )
    assert eff.avg_commits_per_repo == 50.0
    assert eff.avg_commits_per_project == 100.0
    assert eff.avg_commits_per_user == 20.0
    assert eff.avg_prs_per_repo == 12.5
    assert eff.avg_prs_per_project == 25.0
    assert eff.avg_prs_per_user == 5.0
    assert eff.avg_lines_per_commit == 180.0
    assert eff.total_lines_added == 15000
    assert eff.total_lines_deleted == 3000
    assert eff.net_lines_changed == 12000


def test_trend_and_comparison_aggregation(app):
    cfg = app.config["APP_CONFIG"]
    store = FileStore(cfg.report.storage_path)
    resolver = ReportResolver(cfg)

    # Seed 2 months of reports
    for m, c_cnt in [("2026-07", 50), ("2026-08", 80)]:
        meta = ReportMetadata(
            job_id=f"test-{m}",
            trace_id=f"trace-{m}",
            generated_at=f"{m}-15T12:00:00Z",
            period_start=f"{m}-01T00:00:00Z",
            period_end=f"{m}-28T00:00:00Z"
        )
        report = ReportData(
            metadata=meta,
            total_commits=c_cnt,
            total_pull_requests=10,
            total_repositories=2,
            total_active_users=3,
            total_lines_added=c_cnt * 100,
            total_lines_deleted=c_cnt * 20,
            repositories=[
                RepoSummary(
                    project_key="PAY", project_name="Payments",
                    repo_slug="gateway", repo_name="gateway",
                    commits=c_cnt - 10, pull_requests=8,
                    lines_added=(c_cnt - 10) * 100, lines_deleted=(c_cnt - 10) * 20,
                    users=[UserActivity(user_id="alice", display_name="Alice", commits=c_cnt - 10, pull_requests=8)]
                ),
                RepoSummary(
                    project_key="CORE", project_name="Core",
                    repo_slug="ledger", repo_name="ledger",
                    commits=10, pull_requests=2,
                    lines_added=1000, lines_deleted=200,
                    users=[UserActivity(user_id="bob", display_name="Bob", commits=10, pull_requests=2)]
                )
            ]
        )
        store.save_report(report)

    # 1. Test get_available_periods
    periods = Aggregator.get_available_periods(store)
    assert "2026-07" in periods.months
    assert "2026-08" in periods.months
    assert "2026-Q3" in periods.quarters
    assert any(p["key"] == "PAY" for p in periods.projects)
    assert any(r["repo_slug"] == "gateway" for r in periods.repositories)

    # 2. Test aggregate_period (month)
    item_aug = Aggregator.aggregate_period(resolver, "2026-08", period_type="month")
    assert item_aug is not None
    assert item_aug.total_commits == 80
    assert item_aug.efficiency.avg_lines_per_commit == 120.0
    assert item_aug.efficiency.total_lines_added == 8000

    # 3. Test aggregate_period with project filter
    item_pay = Aggregator.aggregate_period(resolver, "2026-08", period_type="month", project_key="PAY")
    assert item_pay is not None
    assert item_pay.total_commits == 70  # 80 - 10 from ledger
    assert item_pay.total_repositories == 1

    # 4. Test aggregate_period with repo filter
    item_repo = Aggregator.aggregate_period(resolver, "2026-08", period_type="month", repo_slug="gateway")
    assert item_repo is not None
    assert item_repo.total_commits == 70

    # 5. Test aggregate_period (quarter)
    item_q = Aggregator.aggregate_period(resolver, "2026-Q3", period_type="quarter")
    assert item_q is not None
    # 50 (jul) + 80 (aug) + existing 2026-09 (30) = 160
    assert item_q.total_commits == 160
    assert item_q.total_pull_requests >= 20
    assert item_q.total_active_users >= 2

    # 6. Test build_trend
    trend = Aggregator.build_trend(resolver, interval="month", periods=["2026-07", "2026-08"])
    assert trend.interval == "month"
    assert len(trend.periods) == 2
    assert trend.periods[0].total_commits == 50
    assert trend.periods[1].total_commits == 80
    assert trend.summary_efficiency is not None
    assert trend.summary_efficiency.total_lines_added == 13000

    # 7. Test build_comparison
    comp = Aggregator.build_comparison(resolver, comparison_type="month", period1="2026-07", period2="2026-08")
    assert comp.comparison_type == "month"
    assert comp.period1 == "2026-07"
    assert comp.period2 == "2026-08"
    commits_delta = next(d for d in comp.deltas if d.metric_key == "total_commits")
    assert commits_delta.period1_val == 50
    assert commits_delta.period2_val == 80
    assert commits_delta.diff == 30
    assert commits_delta.pct_change == 60.0

    lines_added_delta = next(d for d in comp.deltas if d.metric_key == "total_lines_added")
    assert lines_added_delta.period1_val == 5000
    assert lines_added_delta.period2_val == 8000
    assert lines_added_delta.diff == 3000


def test_trend_and_compare_api_routes(client):
    # Test GET /api/reports/periods
    resp = client.get("/api/reports/periods")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "months" in data
    assert "quarters" in data
    assert "projects" in data
    assert "repositories" in data

    # Test GET /api/reports/trend
    trend_resp = client.get("/api/reports/trend?interval=month")
    assert trend_resp.status_code == 200
    trend_data = trend_resp.get_json()
    assert "periods" in trend_data
    assert "summary_efficiency" in trend_data

    # Test GET /api/reports/compare without params -> 400
    bad_comp = client.get("/api/reports/compare")
    assert bad_comp.status_code == 400

    # Test GET /api/reports/compare with params
    good_comp = client.get("/api/reports/compare?type=month&period1=2026-07&period2=2026-08")
    assert good_comp.status_code == 200
    comp_data = good_comp.get_json()
    assert "deltas" in comp_data
    assert "repo_comparisons" in comp_data
