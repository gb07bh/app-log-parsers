from app.bitbucket.models import Repository, CommitEvent, PullRequestEvent
from app.reporting.models import ReportMetadata
from app.reporting.aggregator import Aggregator
from app.reporting.search import SearchService


def test_user_profile_with_multi_project_contributions():
    metadata = ReportMetadata(
        job_id="test-job-multi",
        trace_id="trace-multi",
        generated_at="2026-09-05T12:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z"
    )

    repos = [
        Repository(slug="repo-pay", name="Payments Repo", id=1, project_key="PAY", project_name="Payments"),
        Repository(slug="repo-core", name="Core Repo", id=2, project_key="CORE", project_name="Core Services")
    ]

    commits = {
        "repo-pay": [
            CommitEvent(
                event_id="c1", project_key="PAY", repo_slug="repo-pay",
                user_id="john.doe", display_name="John Doe", timestamp="2026-09-02T10:00:00Z"
            ),
            CommitEvent(
                event_id="c2", project_key="PAY", repo_slug="repo-pay",
                user_id="john.doe", display_name="John Doe", timestamp="2026-09-03T11:00:00Z"
            )
        ],
        "repo-core": [
            CommitEvent(
                event_id="c3", project_key="CORE", repo_slug="repo-core",
                user_id="john.doe", display_name="John Doe", timestamp="2026-09-05T14:00:00Z"
            )
        ]
    }

    prs = {
        "repo-pay": [
            PullRequestEvent(
                event_id="pr1", project_key="PAY", repo_slug="repo-pay",
                user_id="john.doe", display_name="John Doe", created_date="2026-09-02T12:00:00Z"
            )
        ],
        "repo-core": []
    }

    report = Aggregator.build_report(metadata, repos, commits, prs)

    # 1. Verify user profile was created
    assert "john.doe" in report.users
    profile = report.users["john.doe"]
    assert profile.total_commits == 3
    assert profile.total_pull_requests == 1

    # 2. Verify multiple project contributions
    assert len(profile.project_contributions) == 2
    proj_keys = [c.project_key for c in profile.project_contributions]
    assert "PAY" in proj_keys
    assert "CORE" in proj_keys

    # 3. Verify user timeline graph points
    assert len(profile.timeline) >= 3
    dates = [p.date for p in profile.timeline]
    assert "2026-09-02" in dates
    assert "2026-09-03" in dates
    assert "2026-09-05" in dates

    # 4. Verify per-project timeline
    assert "PAY" in profile.project_timeline
    assert "CORE" in profile.project_timeline
    assert len(profile.project_timeline["PAY"]) == 2
    assert len(profile.project_timeline["CORE"]) == 1

    # 5. Verify search returns multi-project flags
    search_results = SearchService.search(report, "john")
    assert len(search_results) == 1
    u_res = search_results[0]
    assert u_res["type"] == "user"
    assert u_res["has_multiple_projects"] is True
    assert u_res["projects_count"] == 2
    assert "PAY" in u_res["project_keys"]
    assert "CORE" in u_res["project_keys"]
