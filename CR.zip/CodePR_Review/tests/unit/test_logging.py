import os
import logging
from app.logging_config import configure_logging, set_trace_context, get_trace_id


def test_logging_configuration(tmp_path):
    log_dir = str(tmp_path / "logs")
    configure_logging(log_dir=log_dir, log_level="DEBUG")

    set_trace_context("trace-test-123", "job-test-456")
    assert get_trace_id() == "trace-test-123"

    dc_logger = logging.getLogger("bitbucket.dc_client")
    ag_logger = logging.getLogger("bitbucket.awesome_graphs")
    root_logger = logging.getLogger("app.test")

    dc_logger.info("Project PROJ1 discovered")
    ag_logger.info("AwesomeGraphs commit query finished")
    root_logger.info("General application message")

    # Verify log files exist
    assert os.path.exists(os.path.join(log_dir, "console.log"))
    assert os.path.exists(os.path.join(log_dir, "projects.log"))
    assert os.path.exists(os.path.join(log_dir, "awesome_graphs.log"))

    with open(os.path.join(log_dir, "projects.log"), "r", encoding="utf-8") as f:
        projects_content = f.read()
        assert "trace-test-123" in projects_content
        assert "PROJ1" in projects_content

    with open(os.path.join(log_dir, "awesome_graphs.log"), "r", encoding="utf-8") as f:
        ag_content = f.read()
        assert "trace-test-123" in ag_content
        assert "AwesomeGraphs commit query finished" in ag_content
