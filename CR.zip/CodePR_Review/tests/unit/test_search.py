from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity
)
from app.reporting.search import SearchService


def test_search_service():
    metadata = ReportMetadata(
        job_id="test-job", trace_id="trace-01",
        generated_at="2026-09-05T12:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z"
    )

    repos = [
        RepoSummary(
            project_key="PAY", project_name="Payments",
            repo_slug="billing-api", repo_name="billing-api",
            commits=10, pull_requests=2,
            users=[
                UserActivity(user_id="john.doe", display_name="John Doe", commits=10, pull_requests=2)
            ]
        )
    ]

    report = ReportData(
        metadata=metadata,
        total_commits=10,
        total_pull_requests=2,
        total_repositories=1,
        total_active_users=1,
        repositories=repos,
        timeline=[]
    )

    # 1. Search by user ID
    user_res = SearchService.search(report, "john.doe")
    assert len(user_res) == 1
    assert user_res[0]["type"] == "user"
    assert user_res[0]["commits"] == 10

    # 2. Search by repo slug
    repo_res = SearchService.search(report, "billing")
    assert len(repo_res) == 1
    assert repo_res[0]["type"] == "repository"

    # 3. Search by project key
    proj_res = SearchService.search(report, "PAY")
    assert len(proj_res) == 1
