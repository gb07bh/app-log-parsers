import os
from app.config.config_loader import load_config
from app.config.schema import AppConfig


def test_config_loader():
    cfg = load_config("config/test_config.yaml")
    assert isinstance(cfg, AppConfig)
    assert cfg.application.environment == "testing"
    assert cfg.workers.count == 2
    assert cfg.bitbucket.projects.keys == ["PROJA", "PROJB"]
    assert cfg.bitbucket.repositories.limit == 2


def test_config_env_resolution(monkeypatch):
    monkeypatch.setenv("TEST_BITBUCKET_USERNAME", "myuser")
    monkeypatch.setenv("TEST_BITBUCKET_PASSWORD", "secret123")

    cfg = load_config("config/test_config.yaml")
    assert cfg.bitbucket.get_username() == "myuser"
    assert cfg.bitbucket.get_password() == "secret123"
