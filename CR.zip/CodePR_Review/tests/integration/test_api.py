import json
from app.reporting.models import ReportData, ReportMetadata, RepoSummary, UserActivity, TimeseriesPoint
from app.storage.file_store import FileStore


def test_health_route(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "healthy"


def test_safe_config_route(client):
    resp = client.get("/api/config")
    assert resp.status_code == 200
    data = resp.get_json()
    assert "bitbucket" in data
    assert "workers" in data
    # Ensure sensitive fields are not in output
    assert "password" not in json.dumps(data)


def test_run_now_prohibits_in_process_execution(client):
    """
    Verifies that Flask NEVER executes the scan runner in-process.
    """
    resp = client.post("/api/reports/jobs/run", json={"month": "2026-09"})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "EXTERNAL_RUNNER_REQUIRED"
    assert "Flask is strictly a presentation and report-pulling server" in data["message"]


def test_report_and_search_apis(app, client):
    # Seed a test report
    cfg = app.config["APP_CONFIG"]
    store = FileStore(cfg.report.storage_path)

    metadata = ReportMetadata(
        job_id="api-test-run",
        trace_id="trace-api-01",
        generated_at="2026-09-05T10:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z"
    )

    report = ReportData(
        metadata=metadata,
        total_commits=20,
        total_pull_requests=5,
        total_repositories=1,
        total_active_users=1,
        repositories=[
            RepoSummary(
                project_key="PAY", project_name="Payments",
                repo_slug="pay-api", repo_name="pay-api",
                commits=20, pull_requests=5,
                users=[UserActivity(user_id="alice", display_name="Alice", commits=20, pull_requests=5)]
            )
        ],
        timeline=[TimeseriesPoint(date="2026-09-05", commits=20, pull_requests=5)]
    )
    store.save_report(report)

    # 1. GET /api/reports/latest
    resp = client.get("/api/reports/latest?month=2026-09")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["total_commits"] == 20

    # 2. GET /api/reports/summary
    summary_resp = client.get("/api/reports/summary?month=2026-09&from=2026-09-05&to=2026-09-05")
    assert summary_resp.status_code == 200
    summary_data = summary_resp.get_json()
    assert summary_data["commits"] == 20

    # 3. GET /api/search
    search_resp = client.get("/api/search?q=alice&month=2026-09")
    assert search_resp.status_code == 200
    search_data = search_resp.get_json()
    assert len(search_data["results"]) == 1

    # 4. GET /api/reports/export format=csv
    csv_resp = client.get("/api/reports/export?month=2026-09&format=csv")
    assert csv_resp.status_code == 200
    assert "Alice" in csv_resp.data.decode("utf-8")
