from unittest.mock import patch, MagicMock
from app.config.schema import AppConfig
from app.runner.scan_runner import ScanRunner


def test_scan_runner_execution_with_mocks(tmp_path):
    cfg = AppConfig()
    cfg.report.storage_path = str(tmp_path / "reports")
    cfg.logging.directory = str(tmp_path / "logs")
    cfg.workers.count = 2

    runner = ScanRunner(cfg)

    # Mock projects response
    mock_projects = [
        {"key": "PAY", "name": "Payments Platform", "id": 1, "public": False}
    ]
    # Mock repos response
    mock_repos = [
        {"slug": "payment-api", "name": "payment-api", "id": 10, "project": {"key": "PAY", "name": "Payments Platform"}}
    ]
    # Mock commits response (Awesome Graphs API)
    mock_commits = [
        {
            "id": "commit123",
            "author": {"name": "john.doe", "displayName": "John Doe", "emailAddress": "jdoe@example.com"},
            "authorTimestamp": "2026-09-03T10:00:00Z",
            "linesOfCode": {"added": 25, "deleted": 5}
        }
    ]
    # Mock PRs response (Awesome Graphs API)
    mock_prs = [
        {
            "id": 101,
            "title": "Add ApplePay support",
            "author": {"user": {"name": "john.doe", "displayName": "John Doe"}},
            "state": "MERGED",
            "createdDate": "2026-09-04T12:00:00Z"
        }
    ]

    with patch.object(runner.client.dc_client.session, "get") as mock_dc_get, \
         patch.object(runner.client.ag_client.session, "get") as mock_ag_get:

        def dc_side_effect(url, **kwargs):
            m = MagicMock()
            m.status_code = 200
            if "/projects/" in url and "/repos" in url:
                m.json.return_value = {"values": mock_repos, "isLastPage": True}
            elif "/projects" in url:
                m.json.return_value = {"values": mock_projects, "isLastPage": True}
            return m

        def ag_side_effect(url, **kwargs):
            m = MagicMock()
            m.status_code = 200
            if "/commits" in url:
                m.json.return_value = {"values": mock_commits, "isLastPage": True}
            elif "/pull-requests" in url:
                m.json.return_value = {"values": mock_prs, "isLastPage": True}
            return m

        mock_dc_get.side_effect = dc_side_effect
        mock_ag_get.side_effect = ag_side_effect

        report = runner.execute(year_month="2026-09")

        assert report.total_commits == 1
        assert report.total_pull_requests == 1
        assert report.total_repositories == 1
        assert report.metadata.status == "COMPLETED"
        assert len(report.repositories[0].users) == 1
        assert report.repositories[0].users[0].user_id == "john.doe"
