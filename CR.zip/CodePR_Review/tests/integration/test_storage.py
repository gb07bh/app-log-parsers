import os
from app.storage.file_store import FileStore
from app.reporting.models import ReportData, ReportMetadata, RepoSummary, UserActivity


def test_file_store_save_and_retrieve(tmp_path):
    store = FileStore(base_path=str(tmp_path / "reports"))

    metadata = ReportMetadata(
        job_id="test-run-101",
        trace_id="trace-101",
        generated_at="2026-09-05T10:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z"
    )

    report = ReportData(
        metadata=metadata,
        total_commits=5,
        total_pull_requests=1,
        total_repositories=1,
        total_active_users=1,
        repositories=[
            RepoSummary(
                project_key="TEST", project_name="Test Project",
                repo_slug="test-repo", repo_name="test-repo",
                commits=5, pull_requests=1,
                users=[UserActivity(user_id="u1", display_name="User 1", commits=5, pull_requests=1)]
            )
        ],
        timeline=[]
    )

    save_path = store.save_report(report)
    assert os.path.exists(os.path.join(save_path, "report.json"))
    assert os.path.exists(os.path.join(save_path, "report.csv"))
    assert os.path.exists(os.path.join(save_path, "metadata.json"))

    loaded = store.get_latest_report_for_month("2026-09")
    assert loaded is not None
    assert loaded.total_commits == 5
    assert loaded.metadata.job_id == "test-run-101"
