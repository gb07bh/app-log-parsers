from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity,
    UserProfile, UserProjectContribution, TimeseriesPoint
)
from app.storage.file_store import FileStore


def test_get_user_profile_api(app, client):
    cfg = app.config["APP_CONFIG"]
    store = FileStore(cfg.report.storage_path)

    metadata = ReportMetadata(
        job_id="user-api-test-run",
        trace_id="trace-user-01",
        generated_at="2026-09-05T10:00:00Z",
        period_start="2026-09-01T00:00:00Z",
        period_end="2026-10-01T00:00:00Z"
    )

    profile = UserProfile(
        user_id="jane.doe",
        display_name="Jane Doe",
        email="jane@example.com",
        total_commits=50,
        total_pull_requests=12,
        timeline=[
            TimeseriesPoint(date="2026-09-01", commits=20, pull_requests=5),
            TimeseriesPoint(date="2026-09-02", commits=30, pull_requests=7),
        ],
        project_contributions=[
            UserProjectContribution(
                project_key="PAY", project_name="Payments",
                repo_slug="gateway", repo_name="gateway",
                commits=30, pull_requests=8
            ),
            UserProjectContribution(
                project_key="AUTH", project_name="Identity",
                repo_slug="oauth", repo_name="oauth",
                commits=20, pull_requests=4
            )
        ],
        project_timeline={
            "PAY": [TimeseriesPoint(date="2026-09-01", commits=20, pull_requests=5), TimeseriesPoint(date="2026-09-02", commits=10, pull_requests=3)],
            "AUTH": [TimeseriesPoint(date="2026-09-02", commits=20, pull_requests=4)]
        }
    )

    report = ReportData(
        metadata=metadata,
        total_commits=50,
        total_pull_requests=12,
        total_repositories=2,
        total_active_users=1,
        repositories=[
            RepoSummary(
                project_key="PAY", project_name="Payments",
                repo_slug="gateway", repo_name="gateway",
                commits=30, pull_requests=8,
                users=[UserActivity(user_id="jane.doe", display_name="Jane Doe", commits=30, pull_requests=8)]
            )
        ],
        timeline=[],
        users={"jane.doe": profile}
    )
    store.save_report(report)

    # 1. Test GET /api/reports/users/jane.doe
    resp = client.get("/api/reports/users/jane.doe?month=2026-09")
    assert resp.status_code == 200
    data = resp.get_json()
    prof = data["profile"]
    assert prof["user_id"] == "jane.doe"
    assert prof["total_commits"] == 50
    assert len(prof["project_contributions"]) == 2
    assert len(prof["timeline"]) == 2
    assert "PAY" in prof["project_timeline"]
    assert "AUTH" in prof["project_timeline"]

    # 2. Test 404 for non-existent user
    not_found_resp = client.get("/api/reports/users/unknown.user?month=2026-09")
    assert not_found_resp.status_code == 404
