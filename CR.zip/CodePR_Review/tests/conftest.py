import pytest
import os
import sys

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config.schema import AppConfig
from app.config.config_loader import load_config
from app import create_app


@pytest.fixture
def test_config():
    return load_config("config/test_config.yaml")


@pytest.fixture
def app(test_config):
    app = create_app(test_config)
    app.config["TESTING"] = True
    return app


@pytest.fixture
def client(app):
    return app.test_client()
