# Running Standalone Report Scans & Tests via Jenkins

This guide details how to execute standalone repository activity scans and automated tests using the provided \Jenkinsfile\, how the pipeline works, and how the application dynamically resolves API endpoints and credentials from \config/config.yaml\.

---

## 1. How the Code Connects to Bitbucket & Awesome Graphs APIs

### Does the code use \config.yaml\ for API endpoints?
**Yes, absolutely.** The codebase does not hardcode any hostnames, endpoints, or API paths. Everything is dynamically read from \config/config.yaml\ (or overridden by a custom configuration via \--config <path>\ or the \CONFIG_PATH\ environment variable).

Here is how the configuration maps directly to the API calls:

| \config.yaml\ Property | Default in Config | Used By | Exact Endpoint Constructed |
| :--- | :--- | :--- | :--- |
| \itbucket.base_url\ | \https://bitbucket.example.com\ | \BitbucketDCClient\<br>\AwesomeGraphsClient\ | Host base URL for all Bitbucket calls |
| \itbucket.dc_api_path\ | \/rest/api/latest\ | \BitbucketDCClient\ (\pp/bitbucket/dc_client.py\) | Projects & Repos discovery:<br>• \{base_url}/rest/api/latest/projects\<br>• \{base_url}/rest/api/latest/projects/{key}/repos\ |
| \itbucket.awesome_graphs_api_path\ | \/rest/awesome-graphs-api/latest\ | \AwesomeGraphsClient\ (\pp/bitbucket/awesome_graphs_client.py\) | Commits & PRs extraction:<br>• \{base_url}/rest/awesome-graphs-api/latest/projects/{key}/repos/{slug}/commits\<br>• \{base_url}/rest/awesome-graphs-api/latest/projects/{key}/repos/{slug}/pull-requests\ |
| \itbucket.auth_type\ | \asic\ (or \earer\) | Both HTTP Clients | Authentication scheme (\Basic Auth\ or \Bearer <token>\) |
| \itbucket.username_env\ | \BITBUCKET_USERNAME\ | Credential resolver | Environment variable name for the username |
| \itbucket.password_env\ | \BITBUCKET_PASSWORD\ | Credential resolver | Environment variable name for the password / PAT |
| \itbucket.token_env\ | \BITBUCKET_TOKEN\ | Credential resolver | Environment variable name for Bearer token |
| \itbucket.projects.keys\ | \[]\ (empty = all) | \HybridClient\ | Scans only specified project keys if list is non-empty |
| \itbucket.repositories.limit\ | "NA\ (or integer e.g. \10\) | \HybridClient\ | Caps the number of repositories processed per project |

### Secure Credential Resolution
To adhere to enterprise security guidelines:
- Passwords, tokens, and secrets are **never** stored in plaintext inside \config.yaml\.
- Instead, \config.yaml\ specifies the **names** of the environment variables (e.g. \BITBUCKET_USERNAME\, \BITBUCKET_PASSWORD\, \ARTIFACTORY_USERNAME\).
- The Jenkins pipeline binds credentials from the Jenkins Credential Store into these environment variables at runtime.

---

## 2. Setting Up the Jenkins Pipeline

The project includes a production-ready declarative pipeline in [Jenkinsfile](Jenkinsfile).

### Step 1: Configure Credentials in Jenkins
Navigate to **Manage Jenkins** ➔ **Credentials** ➔ **System** ➔ **Global credentials** and add:

1. **Bitbucket Credentials**:
 - Kind: \Username with password\ (or \Secret text\ if using a Personal Access Token)
 - ID: \itbucket-user-creds-id\ / \itbucket-pass-creds-id\
2. **Artifactory Credentials** (Optional, if publishing/pulling reports):
 - Kind: \Username with password\
 - ID: \rtifactory-user-creds-id\ / \rtifactory-pass-creds-id\

### Step 2: Create a Jenkins Pipeline Job
1. In Jenkins, click **New Item** ➔ Name: \Bitbucket-Activity-Report-Scan\ ➔ Select **Pipeline** ➔ Click **OK**.
2. Under **Pipeline Definition**, select **Pipeline script from SCM**.
3. SCM: **Git** ➔ Enter your repository URL and credentials.
4. Script Path: \Jenkinsfile\.
5. Click **Save**.

---

## 3. Pipeline Parameters & Execution Options

When you click **Build with Parameters** in Jenkins, you can customize the run:

| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| \MONTH\ | String | *(empty)* | Reporting month in \YYYY-MM\ format (e.g. \2026-09\). Leave empty to automatically scan the current calendar month. |
| \WORKERS\ | String | \5\ | Number of concurrent repository extraction worker threads. |
| \MOCK_SCAN\ | Boolean | \alse\ | Run a dry-run test using simulated Bitbucket & Awesome Graphs data (no live Bitbucket connection needed). |
| \RUN_TESTS\ | Boolean | \ rue\ | Runs the automated \pytest\ test suite prior to scanning. |

---

## 4. How the Jenkins Pipeline Executes

\\\ ext
[Pipeline Trigger]
 │
 ▼
[Stage 1: Checkout] ────────── Clone source code from Git
 │
 ▼
[Stage 2: Setup & Test] ────── Create virtualenv, install dependencies, run pytest
 │
 ▼
[Stage 3: Execute Scan] ────── Run standalone CLI:
                               python scripts/run_scan.py --month ${MONTH} --log-level ${LOG_LEVEL} [--mock]
       │
       ▼
[Post: Artifact Archival] ──── Archive data/reports/** and logs/** to Jenkins build artifacts
       │
       ▼
[Optional: Artifactory] ────── Publish report.json and report.csv to Artifactory
\\\

### What Happens During the Scan:
1. **Trace ID Created**: A trace ID (e.g., \ race-a7b2...\) is generated and logged to \logs/console.log\, \logs/projects.log\, and \logs/awesome_graphs.log\.
2. **Bitbucket Discovery**: The runner calls \{base_url}/rest/api/latest/projects\ and finds repositories according to your configured project list and repository limits.
3. **Multi-Threaded Extraction**: The worker pool spawns 5 threads (configurable) to query Stiltsoft Awesome Graphs for commit events and pull requests within the exact UTC boundary of the specified month.
4. **Report Compilation**: The aggregator compiles metrics across users, projects, and repositories (including daily timelines for the interactive commit graphs).
5. **Artifacts Saved**:
 - \data/reports/YYYY/MM/<job_id>/report.json\
 - \data/reports/YYYY/MM/<job_id>/report.csv\
 - \data/reports/YYYY/MM/<job_id>/metadata.json\
 - Copied to \data/reports/YYYY/MM/latest/\ for instant resolution by Flask.
6. **Archived in Jenkins**: Jenkins archives \data/reports/**\ and \logs/**\ directly to the build execution history for immediate download and audit.

---

## 5. Running Standalone via Command Line (Local / Agent)

You can run the exact same standalone runner directly in your shell or terminal:

### A. Run Automated Unit & Integration Tests
\\\ash
# Activate virtual environment
source venv/bin/activate # Linux/macOS
# or: .\\venv\\Scripts\\Activate.ps1 (Windows PowerShell)

# Run full test suite
python -m pytest tests/ -v
\\\

### B. Run a Dry-Run (Mock Mode) Test
Verify the end-to-end report generation and commit graphs without connecting to live Bitbucket:
\\\ash
python app/main.py scan --month 2026-09 --mock
\\\

### C. Run a Live Scan Against Bitbucket Data Center
Ensure environment variables are populated with your credentials:
\\\ash
# Linux / macOS
export BITBUCKET_USERNAME=your-service-account
export BITBUCKET_PASSWORD=your-secure-token-or-password
python app/main.py scan --month 2026-09

# Windows PowerShell
\=your-service-account
\=your-secure-token-or-password
python app/main.py scan --month 2026-09
\\\

### D. Use a Custom Configuration File
If you have different Bitbucket environments (e.g., staging vs. production):
\\\ash
python app/main.py scan --config config/staging_config.yaml --month 2026-09
\\\

---

## 6. Verifying the Results in the Flask Dashboard

Once the Jenkins job or CLI scan completes:
1. Start the Flask server (if not already running):
 \\\ash
 python app/main.py serve
 \\\
2. Open your browser to \http://localhost:5520\.
3. Select the month you scanned (e.g. \2026-09\).
4. **All data, KPI cards, and Commit Graphs for Contributors, Projects, and Repositories will instantly populate from the generated report!**
5. If running on another server where Artifactory publishing is enabled, simply click **Pull from Artifactory** in the dashboard header to fetch the report generated by Jenkins.
