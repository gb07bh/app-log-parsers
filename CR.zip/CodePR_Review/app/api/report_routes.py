import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, Response, current_app

from app.storage.resolver import ReportResolver
from app.reporting.aggregator import Aggregator
from app.reporting.exporter import Exporter

logger = logging.getLogger("api.report_routes")
report_bp = Blueprint("reports", __name__, url_prefix="/api/reports")


def get_resolver() -> ReportResolver:
    return current_app.config["REPORT_RESOLVER"]


def get_current_month() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


@report_bp.route("/latest", methods=["GET"])
def get_latest_report():
    """
    GET /api/reports/latest?month=YYYY-MM&force_pull=true/false
    Resolves the report for the month:
      1. Check local cache
      2. Pull from Artifactory if missing
      3. Return 404 with guidance if missing from both
    """
    month = request.args.get("month", get_current_month())
    force_pull = request.args.get("force_pull", "false").lower() == "true"

    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month, force_pull=force_pull)

    if not report:
        return jsonify({
            "status": "NOT_FOUND",
            "month": month,
            "message": f"No report found for {month} in local cache or Artifactory. "
                       f"Please trigger the external scan runner (Jenkins or CLI) to generate it."
        }), 404

    return jsonify(report.model_dump()), 200


@report_bp.route("/summary", methods=["GET"])
def get_summary_slice():
    """
    GET /api/reports/summary?month=YYYY-MM&from=YYYY-MM-DD&to=YYYY-MM-DD
    Recalculates summary metrics for a selected time sub-range on the chart.
    """
    month = request.args.get("month", get_current_month())
    from_date = request.args.get("from")
    to_date = request.args.get("to")

    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({
            "status": "NOT_FOUND",
            "message": f"No report found for {month}"
        }), 404

    sliced = Aggregator.slice_timeline(report, from_date=from_date, to_date=to_date)
    return jsonify(sliced), 200


@report_bp.route("/repositories", methods=["GET"])
def get_repositories():
    """
    GET /api/reports/repositories?month=YYYY-MM
    Returns list of repositories with user activity drill-down.
    """
    month = request.args.get("month", get_current_month())
    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({"repositories": [], "month": month}), 404

    return jsonify({
        "month": month,
        "total_repositories": report.total_repositories,
        "repositories": [r.model_dump() for r in report.repositories]
    }), 200


@report_bp.route("/export", methods=["GET"])
def export_report():
    """
    GET /api/reports/export?month=YYYY-MM&format=csv|json
    Download report in CSV or JSON format.
    """
    month = request.args.get("month", get_current_month())
    fmt = request.args.get("format", "json").lower()

    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({"error": f"Report for {month} not found"}), 404

    if fmt == "csv":
        csv_content = Exporter.to_csv(report)
        return Response(
            csv_content,
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment;filename=bitbucket-report-{month}.csv"}
        )
    else:
        json_content = Exporter.to_json(report)
        return Response(
            json_content,
            mimetype="application/json",
            headers={"Content-Disposition": f"attachment;filename=bitbucket-report-{month}.json"}
        )


@report_bp.route("/users/<path:user_id>", methods=["GET"])
def get_user_profile(user_id: str):
    """
    GET /api/reports/users/<user_id>?month=YYYY-MM
    Returns detailed user profile including:
      - Daily commit and PR timeline graph
      - Multi-project contribution breakdown
      - Per-project commit timeline
    """
    month = request.args.get("month", get_current_month())
    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({"error": f"Report for month {month} not found"}), 404

    profile = Aggregator.get_user_profile(report, user_id)
    if not profile:
        return jsonify({"error": f"User '{user_id}' not found in report for {month}"}), 404

    return jsonify({
        "month": month,
        "profile": profile.model_dump()
    }), 200


@report_bp.route("/projects/<path:project_key>", methods=["GET"])
def get_project_profile(project_key: str):
    """
    GET /api/reports/projects/<project_key>?month=YYYY-MM
    Returns detailed project profile including:
      - Daily commit and PR timeline graph
      - Multi-repository contribution breakdown
      - Per-repository commit timeline
    """
    month = request.args.get("month", get_current_month())
    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({"error": f"Report for month {month} not found"}), 404

    profile = Aggregator.get_project_profile(report, project_key)
    if not profile:
        return jsonify({"error": f"Project '{project_key}' not found in report for {month}"}), 404

    return jsonify({
        "month": month,
        "project": profile.model_dump()
    }), 200


@report_bp.route("/repositories/<path:full_repo_path>", methods=["GET"])
def get_repo_profile(full_repo_path: str):
    """
    GET /api/reports/repositories/<project_key>/<repo_slug>?month=YYYY-MM
    or GET /api/reports/repositories/<repo_slug>?month=YYYY-MM
    Returns detailed repository profile including:
      - Daily commit and PR timeline graph
      - Contributor activity breakdown
      - Per-contributor commit timeline
    """
    month = request.args.get("month", get_current_month())
    resolver = get_resolver()
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({"error": f"Report for month {month} not found"}), 404

    parts = full_repo_path.strip("/").split("/")
    if len(parts) >= 2:
        project_key = parts[0]
        repo_slug = parts[1]
    else:
        project_key = ""
        repo_slug = parts[0]

    profile = Aggregator.get_repo_profile(report, project_key, repo_slug)
    if not profile:
        return jsonify({"error": f"Repository '{full_repo_path}' not found in report for {month}"}), 404

    return jsonify({
        "month": month,
        "repository": profile.model_dump()
    }), 200


@report_bp.route("/periods", methods=["GET"])
def get_available_periods():
    """
    GET /api/reports/periods
    Returns available months, quarters, projects, and repositories discovered in storage.
    """
    resolver = get_resolver()
    periods_data = Aggregator.get_available_periods(resolver.file_store)
    return jsonify(periods_data.model_dump()), 200


@report_bp.route("/trend", methods=["GET"])
def get_trend():
    """
    GET /api/reports/trend?interval=month|quarter&project=<key>&repo=<slug>&periods=2026-07,2026-08...
    Builds chronological trend metrics for project / repository level.
    """
    interval = request.args.get("interval", "month").lower()
    project = request.args.get("project") or None
    repo = request.args.get("repo") or None
    periods_param = request.args.get("periods")
    periods = [p.strip() for p in periods_param.split(",") if p.strip()] if periods_param else None

    resolver = get_resolver()
    trend = Aggregator.build_trend(
        resolver=resolver,
        interval=interval,
        project_key=project,
        repo_slug=repo,
        periods=periods
    )
    return jsonify(trend.model_dump()), 200


@report_bp.route("/compare", methods=["GET"])
def compare_periods():
    """
    GET /api/reports/compare?type=month|quarter&period1=2026-08&period2=2026-09&project=<key>&repo=<slug>
    Compares two months or quarters with side-by-side efficiency metrics and deltas.
    """
    comp_type = request.args.get("type", "month").lower()
    period1 = request.args.get("period1", "")
    period2 = request.args.get("period2", "")
    project = request.args.get("project") or None
    repo = request.args.get("repo") or None

    if not period1 or not period2:
        return jsonify({"error": "Both 'period1' and 'period2' query parameters are required"}), 400

    resolver = get_resolver()
    comparison = Aggregator.build_comparison(
        resolver=resolver,
        comparison_type=comp_type,
        period1=period1,
        period2=period2,
        project_key=project,
        repo_slug=repo
    )
    return jsonify(comparison.model_dump()), 200


