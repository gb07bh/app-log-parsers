from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class UserActivity(BaseModel):
    user_id: str
    display_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class UserProjectContribution(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class TimeseriesPoint(BaseModel):
    date: str  # YYYY-MM-DD
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class UserProfile(BaseModel):
    user_id: str
    display_name: str
    email: Optional[str] = None
    total_commits: int = 0
    total_pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    project_contributions: List[UserProjectContribution] = Field(default_factory=list)
    project_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class ProjectRepoContribution(BaseModel):
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    users: List[UserActivity] = Field(default_factory=list)


class ProjectProfile(BaseModel):
    project_key: str
    project_name: str
    total_commits: int = 0
    total_pull_requests: int = 0
    total_repositories: int = 0
    total_active_users: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    repo_contributions: List[ProjectRepoContribution] = Field(default_factory=list)
    repo_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class RepoSummary(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    users: List[UserActivity] = Field(default_factory=list)
    timeline: List[TimeseriesPoint] = Field(default_factory=list)


class RepoProfile(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    total_commits: int = 0
    total_pull_requests: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    total_active_users: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    users: List[UserActivity] = Field(default_factory=list)
    user_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class ReportMetadata(BaseModel):
    job_id: str
    trace_id: str
    generated_at: str  # ISO-8601 UTC
    period_start: str  # ISO-8601 UTC
    period_end: str    # ISO-8601 UTC
    projects_configured: List[str] = Field(default_factory=list)
    repository_limit: Any = "NA"
    worker_count: int = 5
    status: str = "COMPLETED"  # COMPLETED, PARTIAL_SUCCESS, FAILED
    total_repositories: int = 0
    completed_repositories: int = 0
    failed_repositories: int = 0
    errors: List[Dict[str, Any]] = Field(default_factory=list)


class EfficiencyMetrics(BaseModel):
    avg_commits_per_repo: float = 0.0
    avg_commits_per_project: float = 0.0
    avg_commits_per_user: float = 0.0
    avg_prs_per_repo: float = 0.0
    avg_prs_per_project: float = 0.0
    avg_prs_per_user: float = 0.0
    avg_lines_per_commit: float = 0.0
    total_lines_added: int = 0
    total_lines_deleted: int = 0
    net_lines_changed: int = 0


class ReportData(BaseModel):
    metadata: ReportMetadata
    total_commits: int = 0
    total_pull_requests: int = 0
    total_repositories: int = 0
    total_active_users: int = 0
    total_lines_added: int = 0
    total_lines_deleted: int = 0
    efficiency: Optional[EfficiencyMetrics] = None
    repositories: List[RepoSummary] = Field(default_factory=list)
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    users: Dict[str, UserProfile] = Field(default_factory=dict)
    projects: Dict[str, ProjectProfile] = Field(default_factory=dict)
    repo_profiles: Dict[str, RepoProfile] = Field(default_factory=dict)


class TrendPeriodItem(BaseModel):
    period: str  # "2026-07" or "2026-Q3"
    period_label: str  # "Jul 2026" or "Q3 2026"
    total_commits: int = 0
    total_pull_requests: int = 0
    total_lines_added: int = 0
    total_lines_deleted: int = 0
    net_lines_changed: int = 0
    total_active_users: int = 0
    total_repositories: int = 0
    efficiency: EfficiencyMetrics
    repositories: List[RepoSummary] = Field(default_factory=list)


class TrendResponse(BaseModel):
    interval: str  # "month" or "quarter"
    project: Optional[str] = None
    repo: Optional[str] = None
    periods: List[TrendPeriodItem] = Field(default_factory=list)
    summary_efficiency: Optional[EfficiencyMetrics] = None


class MetricDelta(BaseModel):
    metric_key: str
    label: str
    period1_val: float
    period2_val: float
    diff: float
    pct_change: Optional[float] = None
    higher_is_better: bool = True


class RepoComparisonItem(BaseModel):
    project_key: str
    repo_slug: str
    repo_name: str
    commits_p1: int = 0
    commits_p2: int = 0
    commits_diff: int = 0
    commits_pct: Optional[float] = None
    prs_p1: int = 0
    prs_p2: int = 0
    prs_diff: int = 0
    prs_pct: Optional[float] = None
    lines_added_p1: int = 0
    lines_added_p2: int = 0
    lines_added_diff: int = 0
    lines_added_pct: Optional[float] = None
    lines_deleted_p1: int = 0
    lines_deleted_p2: int = 0
    lines_deleted_diff: int = 0
    lines_deleted_pct: Optional[float] = None
    users_p1: int = 0
    users_p2: int = 0
    users_diff: int = 0
    users_pct: Optional[float] = None


class ComparisonResponse(BaseModel):
    comparison_type: str  # "month" or "quarter"
    period1: str
    period2: str
    project: Optional[str] = None
    repo: Optional[str] = None
    period1_metrics: Dict[str, Any] = Field(default_factory=dict)
    period2_metrics: Dict[str, Any] = Field(default_factory=dict)
    deltas: List[MetricDelta] = Field(default_factory=list)
    repo_comparisons: List[RepoComparisonItem] = Field(default_factory=list)


class AvailablePeriodsResponse(BaseModel):
    months: List[str] = Field(default_factory=list)
    quarters: List[str] = Field(default_factory=list)
    projects: List[Dict[str, str]] = Field(default_factory=list)
    repositories: List[Dict[str, str]] = Field(default_factory=list)


