from collections import defaultdict
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import dateutil.parser

from app.bitbucket.models import Repository, CommitEvent, PullRequestEvent
from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity,
    TimeseriesPoint, UserProfile, UserProjectContribution,
    ProjectProfile, ProjectRepoContribution, RepoProfile,
    EfficiencyMetrics, TrendPeriodItem, TrendResponse,
    MetricDelta, RepoComparisonItem, ComparisonResponse,
    AvailablePeriodsResponse
)


def parse_date_utc(date_str: str) -> Optional[datetime]:
    """Parse ISO date string safely to UTC datetime."""
    if not date_str:
        return None
    try:
        dt = dateutil.parser.parse(date_str)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


class Aggregator:
    """
    In-memory aggregator for raw events, calculating totals,
    user drill-down matrices, daily time-series, and per-user commit graphs.
    """
    @staticmethod
    def build_report(
        metadata: ReportMetadata,
        repositories: List[Repository],
        commits_by_repo: Dict[str, List[CommitEvent]],
        prs_by_repo: Dict[str, List[PullRequestEvent]],
    ) -> ReportData:
        """
        Aggregate all commits and PRs into full ReportData.
        Key for dicts is repo.slug.
        """
        repo_summaries: List[RepoSummary] = []
        overall_users = set()
        timeline_map: Dict[str, Dict[str, int]] = defaultdict(lambda: {"commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0})
        total_commits = 0
        total_prs = 0
        total_lines_added = 0
        total_lines_deleted = 0

        # User profile trackers
        user_meta: Dict[str, Dict[str, Any]] = defaultdict(
            lambda: {"display_name": "", "email": None, "commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0}
        )
        # user_id -> date -> {commits, prs, lines_added, lines_deleted}
        user_timeline: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(
            lambda: defaultdict(lambda: {"commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0})
        )
        # user_id -> project_key -> date -> {commits, prs, lines_added, lines_deleted}
        user_proj_timeline: Dict[str, Dict[str, Dict[str, Dict[str, int]]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(lambda: {"commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0}))
        )
        # user_id -> (project_key, project_name, repo_slug, repo_name) -> {commits, prs, lines_added, lines_deleted}
        user_repo_contribs: Dict[str, Dict[tuple, Dict[str, int]]] = defaultdict(
            lambda: defaultdict(lambda: {"commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0})
        )

        for repo in repositories:
            repo_commits = commits_by_repo.get(repo.slug, [])
            repo_prs = prs_by_repo.get(repo.slug, [])

            total_commits += len(repo_commits)
            total_prs += len(repo_prs)

            commit_authors = set()
            pr_authors = set()
            repo_lines_added = 0
            repo_lines_deleted = 0

            repo_user_stats: Dict[str, Dict[str, Any]] = defaultdict(
                lambda: {"display_name": "", "commits": 0, "pull_requests": 0, "lines_added": 0, "lines_deleted": 0}
            )

            # Process Commits
            for c in repo_commits:
                uid = c.user_id
                commit_authors.add(uid)
                overall_users.add(uid)
                c_add = c.lines_added or 0
                c_del = c.lines_deleted or 0
                repo_lines_added += c_add
                repo_lines_deleted += c_del
                total_lines_added += c_add
                total_lines_deleted += c_del

                repo_user_stats[uid]["commits"] += 1
                repo_user_stats[uid]["lines_added"] += c_add
                repo_user_stats[uid]["lines_deleted"] += c_del
                if not repo_user_stats[uid]["display_name"]:
                    repo_user_stats[uid]["display_name"] = c.display_name or uid

                # Global user stats
                user_meta[uid]["commits"] += 1
                user_meta[uid]["lines_added"] += c_add
                user_meta[uid]["lines_deleted"] += c_del
                if not user_meta[uid]["display_name"]:
                    user_meta[uid]["display_name"] = c.display_name or uid
                if c.email and not user_meta[uid]["email"]:
                    user_meta[uid]["email"] = c.email

                # Repo contribution
                key_tuple = (repo.project_key, repo.project_name or repo.project_key, repo.slug, repo.name)
                user_repo_contribs[uid][key_tuple]["commits"] += 1
                user_repo_contribs[uid][key_tuple]["lines_added"] += c_add
                user_repo_contribs[uid][key_tuple]["lines_deleted"] += c_del

                # Timeline mapping (by YYYY-MM-DD)
                dt = parse_date_utc(c.timestamp)
                if dt:
                    day_key = dt.strftime("%Y-%m-%d")
                    timeline_map[day_key]["commits"] += 1
                    timeline_map[day_key]["lines_added"] += c_add
                    timeline_map[day_key]["lines_deleted"] += c_del
                    user_timeline[uid][day_key]["commits"] += 1
                    user_timeline[uid][day_key]["lines_added"] += c_add
                    user_proj_timeline[uid][repo.project_key][day_key]["commits"] += 1
                    user_proj_timeline[uid][repo.project_key][day_key]["lines_added"] += c_add
                    user_proj_timeline[uid][repo.project_key][day_key]["lines_deleted"] += c_del

            # Process PRs
            for p in repo_prs:
                uid = p.user_id
                pr_authors.add(uid)
                overall_users.add(uid)
                repo_user_stats[uid]["pull_requests"] += 1
                if not repo_user_stats[uid]["display_name"]:
                    repo_user_stats[uid]["display_name"] = p.display_name or uid

                user_meta[uid]["prs"] += 1
                if not user_meta[uid]["display_name"]:
                    user_meta[uid]["display_name"] = p.display_name or uid

                key_tuple = (repo.project_key, repo.project_name or repo.project_key, repo.slug, repo.name)
                user_repo_contribs[uid][key_tuple]["prs"] += 1

                dt = parse_date_utc(p.created_date)
                if dt:
                    day_key = dt.strftime("%Y-%m-%d")
                    timeline_map[day_key]["prs"] += 1
                    user_timeline[uid][day_key]["prs"] += 1
                    user_proj_timeline[uid][repo.project_key][day_key]["prs"] += 1

            users_list = [
                UserActivity(
                    user_id=uid,
                    display_name=stat["display_name"] or uid,
                    commits=stat["commits"],
                    pull_requests=stat["pull_requests"],
                    lines_added=stat["lines_added"],
                    lines_deleted=stat["lines_deleted"]
                )
                for uid, stat in sorted(
                    repo_user_stats.items(),
                    key=lambda x: (x[1]["commits"] + x[1]["pull_requests"]),
                    reverse=True
                )
            ]

            repo_summary = RepoSummary(
                project_key=repo.project_key,
                project_name=repo.project_name or repo.project_key,
                repo_slug=repo.slug,
                repo_name=repo.name,
                commits=len(repo_commits),
                pull_requests=len(repo_prs),
                lines_added=repo_lines_added,
                lines_deleted=repo_lines_deleted,
                unique_commit_authors=len(commit_authors),
                unique_pr_authors=len(pr_authors),
                users=users_list
            )
            repo_summaries.append(repo_summary)

        # Sort repos by total activity
        repo_summaries.sort(key=lambda r: (r.commits + r.pull_requests), reverse=True)

        # Build overall timeline sorted by date
        sorted_timeline = [
            TimeseriesPoint(
                date=day,
                commits=counts["commits"],
                pull_requests=counts["prs"],
                lines_added=counts["lines_added"],
                lines_deleted=counts["lines_deleted"]
            )
            for day, counts in sorted(timeline_map.items())
        ]

        # Build User Profiles
        user_profiles: Dict[str, UserProfile] = {}
        for uid, meta in user_meta.items():
            u_tl = [
                TimeseriesPoint(
                    date=day,
                    commits=cnt["commits"],
                    pull_requests=cnt["prs"],
                    lines_added=cnt["lines_added"],
                    lines_deleted=cnt["lines_deleted"]
                )
                for day, cnt in sorted(user_timeline[uid].items())
            ]

            contrib_list = [
                UserProjectContribution(
                    project_key=k[0],
                    project_name=k[1],
                    repo_slug=k[2],
                    repo_name=k[3],
                    commits=stats["commits"],
                    pull_requests=stats["prs"],
                    lines_added=stats["lines_added"],
                    lines_deleted=stats["lines_deleted"]
                )
                for k, stats in sorted(
                    user_repo_contribs[uid].items(),
                    key=lambda item: (item[1]["commits"] + item[1]["prs"]),
                    reverse=True
                )
            ]

            u_proj_tl: Dict[str, List[TimeseriesPoint]] = {}
            for proj_key, p_days in user_proj_timeline[uid].items():
                u_proj_tl[proj_key] = [
                    TimeseriesPoint(
                        date=day,
                        commits=cnt["commits"],
                        pull_requests=cnt["prs"],
                        lines_added=cnt["lines_added"],
                        lines_deleted=cnt["lines_deleted"]
                    )
                    for day, cnt in sorted(p_days.items())
                ]

            user_profiles[uid] = UserProfile(
                user_id=uid,
                display_name=meta["display_name"] or uid,
                email=meta["email"],
                total_commits=meta["commits"],
                total_pull_requests=meta["prs"],
                lines_added=meta["lines_added"],
                lines_deleted=meta["lines_deleted"],
                timeline=u_tl,
                project_contributions=contrib_list,
                project_timeline=u_proj_tl
            )

        # Build Project Profiles & Repo Profiles
        project_profiles: Dict[str, ProjectProfile] = {}
        repo_profiles: Dict[str, RepoProfile] = {}

        proj_repos_map: Dict[str, List[RepoSummary]] = defaultdict(list)
        for rs in repo_summaries:
            proj_repos_map[rs.project_key].append(rs)

        for pkey, p_repos in proj_repos_map.items():
            p_name = p_repos[0].project_name if p_repos else pkey
            p_total_commits = sum(r.commits for r in p_repos)
            p_total_prs = sum(r.pull_requests for r in p_repos)
            p_lines_added = sum(r.lines_added for r in p_repos)
            p_lines_deleted = sum(r.lines_deleted for r in p_repos)
            p_users_set = set()
            for r in p_repos:
                for u in r.users:
                    p_users_set.add(u.user_id)

            p_repo_contribs = [
                ProjectRepoContribution(
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=r.commits,
                    pull_requests=r.pull_requests,
                    lines_added=r.lines_added,
                    lines_deleted=r.lines_deleted,
                    unique_commit_authors=r.unique_commit_authors,
                    unique_pr_authors=r.unique_pr_authors,
                    users=r.users
                )
                for r in p_repos
            ]

            p_days_commits: Dict[str, int] = defaultdict(int)
            p_days_prs: Dict[str, int] = defaultdict(int)
            p_days_lines_added: Dict[str, int] = defaultdict(int)
            p_days_lines_deleted: Dict[str, int] = defaultdict(int)
            for uid, p_data in user_proj_timeline.items():
                if pkey in p_data:
                    for d, d_cnt in p_data[pkey].items():
                        p_days_commits[d] += d_cnt["commits"]
                        p_days_prs[d] += d_cnt["prs"]
                        p_days_lines_added[d] += d_cnt["lines_added"]
                        p_days_lines_deleted[d] += d_cnt["lines_deleted"]

            all_p_days = sorted(set(list(p_days_commits.keys()) + list(p_days_prs.keys())))
            p_timeline = [
                TimeseriesPoint(
                    date=d,
                    commits=p_days_commits[d],
                    pull_requests=p_days_prs[d],
                    lines_added=p_days_lines_added[d],
                    lines_deleted=p_days_lines_deleted[d]
                )
                for d in all_p_days
            ]

            p_repo_timeline: Dict[str, List[TimeseriesPoint]] = {}
            for r in p_repos:
                p_repo_timeline[r.repo_slug] = []

            project_profiles[pkey] = ProjectProfile(
                project_key=pkey,
                project_name=p_name,
                total_commits=p_total_commits,
                total_pull_requests=p_total_prs,
                total_repositories=len(p_repos),
                total_active_users=len(p_users_set),
                lines_added=p_lines_added,
                lines_deleted=p_lines_deleted,
                timeline=p_timeline,
                repo_contributions=p_repo_contribs,
                repo_timeline=p_repo_timeline
            )

        # Build each RepoProfile
        for rs in repo_summaries:
            key = f"{rs.project_key}/{rs.repo_slug}"
            repo_profiles[key] = RepoProfile(
                project_key=rs.project_key,
                project_name=rs.project_name,
                repo_slug=rs.repo_slug,
                repo_name=rs.repo_name,
                total_commits=rs.commits,
                total_pull_requests=rs.pull_requests,
                unique_commit_authors=rs.unique_commit_authors,
                unique_pr_authors=rs.unique_pr_authors,
                total_active_users=len(rs.users),
                lines_added=rs.lines_added,
                lines_deleted=rs.lines_deleted,
                timeline=[],
                users=rs.users,
                user_timeline={}
            )

        # Compute Efficiency Metrics
        num_repos = len(repositories)
        num_projects = len(proj_repos_map)
        num_users = len(overall_users)

        efficiency = EfficiencyMetrics(
            avg_commits_per_repo=round(total_commits / num_repos, 2) if num_repos > 0 else 0.0,
            avg_commits_per_project=round(total_commits / num_projects, 2) if num_projects > 0 else 0.0,
            avg_commits_per_user=round(total_commits / num_users, 2) if num_users > 0 else 0.0,
            avg_prs_per_repo=round(total_prs / num_repos, 2) if num_repos > 0 else 0.0,
            avg_prs_per_project=round(total_prs / num_projects, 2) if num_projects > 0 else 0.0,
            avg_prs_per_user=round(total_prs / num_users, 2) if num_users > 0 else 0.0,
            avg_lines_per_commit=round((total_lines_added + total_lines_deleted) / total_commits, 2) if total_commits > 0 else 0.0,
            total_lines_added=total_lines_added,
            total_lines_deleted=total_lines_deleted,
            net_lines_changed=total_lines_added - total_lines_deleted
        )

        return ReportData(
            metadata=metadata,
            total_commits=total_commits,
            total_pull_requests=total_prs,
            total_repositories=num_repos,
            total_active_users=num_users,
            total_lines_added=total_lines_added,
            total_lines_deleted=total_lines_deleted,
            efficiency=efficiency,
            repositories=repo_summaries,
            timeline=sorted_timeline,
            users=user_profiles,
            projects=project_profiles,
            repo_profiles=repo_profiles
        )

    @staticmethod
    def get_user_profile(report: ReportData, user_id: str) -> Optional[UserProfile]:
        """
        Retrieve or derive UserProfile for a user from report.
        """
        if not user_id:
            return None

        found_profile: Optional[UserProfile] = None

        # 1. Direct lookup in report.users
        if report.users and user_id in report.users:
            found_profile = report.users[user_id]
        else:
            # Case-insensitive lookup in report.users
            for uid, p in (report.users or {}).items():
                if uid.lower() == user_id.lower():
                    found_profile = p
                    break

        # 2. Fallback: reconstruct from report.repositories if report was loaded from legacy schema
        if not found_profile:
            matching_contribs: List[UserProjectContribution] = []
            total_commits = 0
            total_prs = 0
            total_lines_added = 0
            total_lines_deleted = 0
            display_name = user_id

            for repo in report.repositories:
                for u in repo.users:
                    if u.user_id.lower() == user_id.lower():
                        display_name = u.display_name or display_name
                        total_commits += u.commits
                        total_prs += u.pull_requests
                        total_lines_added += u.lines_added
                        total_lines_deleted += u.lines_deleted
                        matching_contribs.append(
                            UserProjectContribution(
                                project_key=repo.project_key,
                                project_name=repo.project_name,
                                repo_slug=repo.repo_slug,
                                repo_name=repo.repo_name,
                                commits=u.commits,
                                pull_requests=u.pull_requests,
                                lines_added=u.lines_added,
                                lines_deleted=u.lines_deleted
                            )
                        )

            if not matching_contribs:
                return None

            found_profile = UserProfile(
                user_id=user_id,
                display_name=display_name,
                total_commits=total_commits,
                total_pull_requests=total_prs,
                lines_added=total_lines_added,
                lines_deleted=total_lines_deleted,
                timeline=[],
                project_contributions=matching_contribs,
                project_timeline={}
            )

        # 3. Ensure timelines are populated if empty
        if not found_profile.timeline or (found_profile.total_commits > 0 and sum(p.commits for p in found_profile.timeline) == 0):
            timeline_dates = [p.date for p in report.timeline] if report.timeline else []
            if not timeline_dates:
                # Default to month days if timeline missing
                p_start = (report.metadata.period_start or "2026-09-01")[:7]
                timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

            num_days = len(timeline_dates)
            u_proj_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

            # Distribute per project contribution
            for contrib in found_profile.project_contributions:
                c_rem = contrib.commits
                pr_rem = contrib.pull_requests
                for i, d in enumerate(timeline_dates):
                    days_left = num_days - i
                    c_alloc = (c_rem // days_left) if days_left > 0 else 0
                    pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                    if days_left > 0 and c_rem % days_left != 0:
                        c_alloc += 1
                    if days_left > 0 and pr_rem % days_left != 0:
                        pr_alloc += 1
                    c_alloc = min(c_rem, c_alloc)
                    pr_alloc = min(pr_rem, pr_alloc)
                    c_rem -= c_alloc
                    pr_rem -= pr_alloc
                    u_proj_tl[contrib.project_key].append(
                        TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                    )

            # Build overall daily timeline
            u_tl: List[TimeseriesPoint] = []
            for d in timeline_dates:
                d_c = sum(pt.commits for proj_pts in u_proj_tl.values() for pt in proj_pts if pt.date == d)
                d_pr = sum(pt.pull_requests for proj_pts in u_proj_tl.values() for pt in proj_pts if pt.date == d)
                u_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

            found_profile.timeline = u_tl
            found_profile.project_timeline = dict(u_proj_tl)

        return found_profile

    @staticmethod
    def get_project_profile(report: ReportData, project_key: str) -> Optional[ProjectProfile]:
        """
        Retrieve or derive ProjectProfile for a project key from report.
        """
        if not project_key:
            return None

        pkey_clean = project_key.strip()
        found_profile: Optional[ProjectProfile] = None

        # 1. Direct lookup in report.projects
        if report.projects and pkey_clean in report.projects:
            found_profile = report.projects[pkey_clean]
        else:
            # Case-insensitive lookup
            for pk, p in (report.projects or {}).items():
                if pk.lower() == pkey_clean.lower():
                    found_profile = p
                    break

        # 2. Fallback: reconstruct from report.repositories if not found
        if not found_profile:
            matching_repos: List[RepoSummary] = [
                r for r in report.repositories
                if r.project_key.lower() == pkey_clean.lower()
            ]
            if not matching_repos:
                return None

            p_name = matching_repos[0].project_name or pkey_clean
            p_commits = sum(r.commits for r in matching_repos)
            p_prs = sum(r.pull_requests for r in matching_repos)
            p_lines_added = sum(r.lines_added for r in matching_repos)
            p_lines_deleted = sum(r.lines_deleted for r in matching_repos)
            p_users = set()
            for r in matching_repos:
                for u in r.users:
                    p_users.add(u.user_id)

            repo_contribs = [
                ProjectRepoContribution(
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=r.commits,
                    pull_requests=r.pull_requests,
                    lines_added=r.lines_added,
                    lines_deleted=r.lines_deleted,
                    unique_commit_authors=r.unique_commit_authors,
                    unique_pr_authors=r.unique_pr_authors,
                    users=r.users
                )
                for r in matching_repos
            ]

            found_profile = ProjectProfile(
                project_key=matching_repos[0].project_key,
                project_name=p_name,
                total_commits=p_commits,
                total_pull_requests=p_prs,
                total_repositories=len(matching_repos),
                total_active_users=len(p_users),
                lines_added=p_lines_added,
                lines_deleted=p_lines_deleted,
                timeline=[],
                repo_contributions=repo_contribs,
                repo_timeline={}
            )

        # 3. Ensure timelines are populated if empty or lacking data
        if not found_profile.timeline or (found_profile.total_commits > 0 and sum(p.commits for p in found_profile.timeline) == 0):
            timeline_dates = [p.date for p in report.timeline] if report.timeline else []
            if not timeline_dates:
                p_start = (report.metadata.period_start or "2026-09-01")[:7]
                timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

            num_days = len(timeline_dates)
            r_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

            # Distribute per repository contribution
            for contrib in found_profile.repo_contributions:
                c_rem = contrib.commits
                pr_rem = contrib.pull_requests
                for i, d in enumerate(timeline_dates):
                    days_left = num_days - i
                    c_alloc = (c_rem // days_left) if days_left > 0 else 0
                    pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                    if days_left > 0 and c_rem % days_left != 0:
                        c_alloc += 1
                    if days_left > 0 and pr_rem % days_left != 0:
                        pr_alloc += 1
                    c_alloc = min(c_rem, c_alloc)
                    pr_alloc = min(pr_rem, pr_alloc)
                    c_rem -= c_alloc
                    pr_rem -= pr_alloc
                    r_tl[contrib.repo_slug].append(
                        TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                    )

            p_tl: List[TimeseriesPoint] = []
            for d in timeline_dates:
                d_c = sum(pt.commits for repo_pts in r_tl.values() for pt in repo_pts if pt.date == d)
                d_pr = sum(pt.pull_requests for repo_pts in r_tl.values() for pt in repo_pts if pt.date == d)
                p_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

            found_profile.timeline = p_tl
            found_profile.repo_timeline = dict(r_tl)

        return found_profile

    @staticmethod
    def get_repo_profile(report: ReportData, project_key: str, repo_slug: str) -> Optional[RepoProfile]:
        """
        Retrieve or derive RepoProfile for a repository from report.
        """
        if not repo_slug:
            return None

        slug_clean = repo_slug.strip().lower()
        pkey_clean = project_key.strip().lower() if project_key else ""

        # 1. Direct lookup in report.repo_profiles
        full_key = f"{project_key}/{repo_slug}" if project_key else repo_slug
        if report.repo_profiles:
            for k, p in report.repo_profiles.items():
                if (pkey_clean and k.lower() == f"{pkey_clean}/{slug_clean}") or (not pkey_clean and k.lower().endswith(f"/{slug_clean}")):
                    return p

        # 2. Lookup in report.repositories
        found_summary: Optional[RepoSummary] = None
        for r in report.repositories:
            if (not pkey_clean or r.project_key.lower() == pkey_clean) and r.repo_slug.lower() == slug_clean:
                found_summary = r
                break

        if not found_summary:
            return None

        profile = RepoProfile(
            project_key=found_summary.project_key,
            project_name=found_summary.project_name,
            repo_slug=found_summary.repo_slug,
            repo_name=found_summary.repo_name,
            total_commits=found_summary.commits,
            total_pull_requests=found_summary.pull_requests,
            unique_commit_authors=found_summary.unique_commit_authors,
            unique_pr_authors=found_summary.unique_pr_authors,
            total_active_users=len(found_summary.users),
            lines_added=found_summary.lines_added,
            lines_deleted=found_summary.lines_deleted,
            timeline=[],
            users=found_summary.users,
            user_timeline={}
        )

        # Ensure timeline populated
        timeline_dates = [p.date for p in report.timeline] if report.timeline else []
        if not timeline_dates:
            p_start = (report.metadata.period_start or "2026-09-01")[:7]
            timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

        num_days = len(timeline_dates)
        u_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

        for u in profile.users:
            c_rem = u.commits
            pr_rem = u.pull_requests
            for i, d in enumerate(timeline_dates):
                days_left = num_days - i
                c_alloc = (c_rem // days_left) if days_left > 0 else 0
                pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                if days_left > 0 and c_rem % days_left != 0:
                    c_alloc += 1
                if days_left > 0 and pr_rem % days_left != 0:
                    pr_alloc += 1
                c_alloc = min(c_rem, c_alloc)
                pr_alloc = min(pr_rem, pr_alloc)
                c_rem -= c_alloc
                pr_rem -= pr_alloc
                u_tl[u.user_id].append(
                    TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                )

        r_tl: List[TimeseriesPoint] = []
        for d in timeline_dates:
            d_c = sum(pt.commits for user_pts in u_tl.values() for pt in user_pts if pt.date == d)
            d_pr = sum(pt.pull_requests for user_pts in u_tl.values() for pt in user_pts if pt.date == d)
            r_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

        profile.timeline = r_tl
        profile.user_timeline = dict(u_tl)

        return profile

    @staticmethod
    def slice_timeline(
        report: ReportData,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Recalculate summary metrics for an arbitrary sub-range [from_date, to_date].
        """
        filtered_points = []
        commits = 0
        prs = 0
        lines_added = 0
        lines_deleted = 0

        for pt in report.timeline:
            if from_date and pt.date < from_date:
                continue
            if to_date and pt.date > to_date:
                continue
            filtered_points.append(pt)
            commits += pt.commits
            prs += pt.pull_requests
            lines_added += pt.lines_added
            lines_deleted += pt.lines_deleted

        avg_lines_per_commit = round((lines_added + lines_deleted) / commits, 2) if commits > 0 else 0.0

        return {
            "period": {
                "from": from_date or (report.timeline[0].date if report.timeline else None),
                "to": to_date or (report.timeline[-1].date if report.timeline else None)
            },
            "commits": commits,
            "pull_requests": prs,
            "active_users": report.total_active_users,
            "repositories": report.total_repositories,
            "lines_added": lines_added,
            "lines_deleted": lines_deleted,
            "net_lines_changed": lines_added - lines_deleted,
            "avg_lines_per_commit": avg_lines_per_commit,
            "points": [p.model_dump() for p in filtered_points]
        }

    @staticmethod
    def month_to_quarter(month_str: str) -> str:
        """Convert YYYY-MM to YYYY-Q#."""
        try:
            parts = month_str.split("-")
            y = parts[0]
            m = int(parts[1])
            q = (m - 1) // 3 + 1
            return f"{y}-Q{q}"
        except Exception:
            return month_str

    @staticmethod
    def quarter_to_months(quarter_str: str) -> List[str]:
        """Convert YYYY-Q# to [YYYY-01, YYYY-02, YYYY-03], etc."""
        try:
            parts = quarter_str.split("-Q")
            y = parts[0]
            q = int(parts[1])
            start_m = (q - 1) * 3 + 1
            return [f"{y}-{start_m + i:02d}" for i in range(3)]
        except Exception:
            return []

    @staticmethod
    def format_period_label(period: str, period_type: str = "month") -> str:
        """Format '2026-09' -> 'Sep 2026' or '2026-Q3' -> 'Q3 2026'."""
        if period_type == "quarter" or "-Q" in period:
            parts = period.split("-")
            return f"{parts[1]} {parts[0]}" if len(parts) == 2 else period
        try:
            dt = datetime.strptime(period, "%Y-%m")
            return dt.strftime("%b %Y")
        except Exception:
            return period

    @staticmethod
    def compute_efficiency_metrics(
        total_commits: int,
        total_prs: int,
        total_lines_added: int,
        total_lines_deleted: int,
        num_repos: int,
        num_projects: int,
        num_users: int
    ) -> EfficiencyMetrics:
        """Compute standard 8 engineering efficiency metrics."""
        return EfficiencyMetrics(
            avg_commits_per_repo=round(total_commits / num_repos, 2) if num_repos > 0 else 0.0,
            avg_commits_per_project=round(total_commits / num_projects, 2) if num_projects > 0 else 0.0,
            avg_commits_per_user=round(total_commits / num_users, 2) if num_users > 0 else 0.0,
            avg_prs_per_repo=round(total_prs / num_repos, 2) if num_repos > 0 else 0.0,
            avg_prs_per_project=round(total_prs / num_projects, 2) if num_projects > 0 else 0.0,
            avg_prs_per_user=round(total_prs / num_users, 2) if num_users > 0 else 0.0,
            avg_lines_per_commit=round((total_lines_added + total_lines_deleted) / total_commits, 2) if total_commits > 0 else 0.0,
            total_lines_added=total_lines_added,
            total_lines_deleted=total_lines_deleted,
            net_lines_changed=total_lines_added - total_lines_deleted
        )

    @staticmethod
    def get_available_periods(file_store) -> AvailablePeriodsResponse:
        """
        Discover all available reporting months, derived quarters,
        projects, and repositories present in stored reports.
        """
        import os
        import re
        months_set = set()
        projects_dict = {}  # key -> name
        repos_dict = {}  # (project_key, slug) -> name

        # 1. Inspect directories in storage path
        base_path = file_store.base_path
        if os.path.exists(base_path):
            for root, dirs, files in os.walk(base_path):
                # Look for report.json
                if "report.json" in files:
                    normalized = root.replace("\\", "/")
                    # Extract YYYY/MM from path
                    match = re.search(r"(\d{4})/(\d{2})", normalized)
                    if match:
                        year_month = f"{match.group(1)}-{match.group(2)}"
                        months_set.add(year_month)

        # 2. Derive quarters from found months
        quarters_set = {Aggregator.month_to_quarter(m) for m in months_set if "-" in m}

        # 3. Inspect the most recent report(s) to populate known projects & repos
        for m in sorted(months_set, reverse=True):
            rep = file_store.get_latest_report_for_month(m)
            if rep:
                for r in rep.repositories:
                    projects_dict[r.project_key] = r.project_name or r.project_key
                    repos_dict[(r.project_key, r.repo_slug)] = r.repo_name or r.repo_slug

        sorted_months = sorted(months_set)
        sorted_quarters = sorted(quarters_set)
        projects_list = [{"key": k, "name": v} for k, v in sorted(projects_dict.items())]
        repos_list = [
            {"project_key": k[0], "repo_slug": k[1], "repo_name": v}
            for k, v in sorted(repos_dict.items())
        ]

        return AvailablePeriodsResponse(
            months=sorted_months,
            quarters=sorted_quarters,
            projects=projects_list,
            repositories=repos_list
        )

    @staticmethod
    def aggregate_period(
        resolver,
        period: str,
        period_type: str = "month",
        project_key: Optional[str] = None,
        repo_slug: Optional[str] = None
    ) -> Optional[TrendPeriodItem]:
        """
        Aggregate metrics for a specific month or quarter, optionally filtered by project or repository.
        """
        if not period:
            return None

        if period_type == "quarter" or "-Q" in period:
            months = Aggregator.quarter_to_months(period)
        else:
            months = [period]

        reports: List[ReportData] = []
        for m in months:
            rep = resolver.resolve_report_for_month(m)
            if rep:
                reports.append(rep)

        if not reports:
            return None

        total_commits = 0
        total_prs = 0
        total_lines_added = 0
        total_lines_deleted = 0
        all_active_users = set()
        all_projects = set()
        all_repos = set()

        # Map to aggregate repo-level summaries across reports
        repo_map: Dict[tuple, Dict[str, Any]] = defaultdict(
            lambda: {
                "project_key": "",
                "project_name": "",
                "repo_slug": "",
                "repo_name": "",
                "commits": 0,
                "pull_requests": 0,
                "lines_added": 0,
                "lines_deleted": 0,
                "users": defaultdict(lambda: {"commits": 0, "pull_requests": 0, "lines_added": 0, "lines_deleted": 0, "display_name": ""})
            }
        )

        for rep in reports:
            for r in rep.repositories:
                # Apply project and repo filters
                if project_key and r.project_key.lower() != project_key.lower():
                    continue
                if repo_slug and r.repo_slug.lower() != repo_slug.lower():
                    continue

                total_commits += r.commits
                total_prs += r.pull_requests
                total_lines_added += r.lines_added
                total_lines_deleted += r.lines_deleted
                all_projects.add(r.project_key)
                all_repos.add((r.project_key, r.repo_slug))

                key = (r.project_key, r.repo_slug)
                rm = repo_map[key]
                rm["project_key"] = r.project_key
                rm["project_name"] = r.project_name or r.project_key
                rm["repo_slug"] = r.repo_slug
                rm["repo_name"] = r.repo_name or r.repo_slug
                rm["commits"] += r.commits
                rm["pull_requests"] += r.pull_requests
                rm["lines_added"] += r.lines_added
                rm["lines_deleted"] += r.lines_deleted

                for u in r.users:
                    all_active_users.add(u.user_id)
                    u_stat = rm["users"][u.user_id]
                    u_stat["commits"] += u.commits
                    u_stat["pull_requests"] += u.pull_requests
                    u_stat["lines_added"] += u.lines_added
                    u_stat["lines_deleted"] += u.lines_deleted
                    if u.display_name:
                        u_stat["display_name"] = u.display_name

        num_repos = len(all_repos)
        num_projects = len(all_projects)
        num_users = len(all_active_users)

        efficiency = Aggregator.compute_efficiency_metrics(
            total_commits=total_commits,
            total_prs=total_prs,
            total_lines_added=total_lines_added,
            total_lines_deleted=total_lines_deleted,
            num_repos=num_repos,
            num_projects=num_projects,
            num_users=num_users
        )

        # Build RepoSummary list for this period
        aggregated_repos: List[RepoSummary] = []
        for key, r_data in sorted(repo_map.items()):
            user_list = [
                UserActivity(
                    user_id=uid,
                    display_name=u_val["display_name"] or uid,
                    commits=u_val["commits"],
                    pull_requests=u_val["pull_requests"],
                    lines_added=u_val["lines_added"],
                    lines_deleted=u_val["lines_deleted"]
                )
                for uid, u_val in r_data["users"].items()
            ]
            aggregated_repos.append(
                RepoSummary(
                    project_key=r_data["project_key"],
                    project_name=r_data["project_name"],
                    repo_slug=r_data["repo_slug"],
                    repo_name=r_data["repo_name"],
                    commits=r_data["commits"],
                    pull_requests=r_data["pull_requests"],
                    lines_added=r_data["lines_added"],
                    lines_deleted=r_data["lines_deleted"],
                    unique_commit_authors=len([u for u in user_list if u.commits > 0]),
                    unique_pr_authors=len([u for u in user_list if u.pull_requests > 0]),
                    users=user_list,
                    timeline=[]
                )
            )

        return TrendPeriodItem(
            period=period,
            period_label=Aggregator.format_period_label(period, period_type),
            total_commits=total_commits,
            total_pull_requests=total_prs,
            total_lines_added=total_lines_added,
            total_lines_deleted=total_lines_deleted,
            net_lines_changed=total_lines_added - total_lines_deleted,
            total_active_users=num_users,
            total_repositories=num_repos,
            efficiency=efficiency,
            repositories=aggregated_repos
        )

    @staticmethod
    def build_trend(
        resolver,
        interval: str = "month",
        project_key: Optional[str] = None,
        repo_slug: Optional[str] = None,
        periods: Optional[List[str]] = None
    ) -> TrendResponse:
        """
        Build a multi-period trend analysis response across months or quarters.
        """
        available = Aggregator.get_available_periods(resolver.file_store)
        target_periods = periods

        if not target_periods:
            if interval == "quarter":
                target_periods = available.quarters
            else:
                target_periods = available.months

        trend_items: List[TrendPeriodItem] = []
        tot_c = 0
        tot_pr = 0
        tot_la = 0
        tot_ld = 0
        all_users = set()
        all_projects = set()
        all_repos = set()

        for p in (target_periods or []):
            item = Aggregator.aggregate_period(
                resolver=resolver,
                period=p,
                period_type=interval,
                project_key=project_key,
                repo_slug=repo_slug
            )
            if item:
                trend_items.append(item)
                tot_c += item.total_commits
                tot_pr += item.total_pull_requests
                tot_la += item.total_lines_added
                tot_ld += item.total_lines_deleted
                for r in item.repositories:
                    all_projects.add(r.project_key)
                    all_repos.add((r.project_key, r.repo_slug))
                    for u in r.users:
                        all_users.add(u.user_id)

        summary_eff = Aggregator.compute_efficiency_metrics(
            total_commits=tot_c,
            total_prs=tot_pr,
            total_lines_added=tot_la,
            total_lines_deleted=tot_ld,
            num_repos=len(all_repos),
            num_projects=len(all_projects),
            num_users=len(all_users)
        )

        return TrendResponse(
            interval=interval,
            project=project_key,
            repo=repo_slug,
            periods=trend_items,
            summary_efficiency=summary_eff
        )

    @staticmethod
    def build_comparison(
        resolver,
        comparison_type: str = "month",
        period1: str = "",
        period2: str = "",
        project_key: Optional[str] = None,
        repo_slug: Optional[str] = None
    ) -> ComparisonResponse:
        """
        Build side-by-side comparison with deltas and repo breakdown between two periods.
        """
        p1_item = Aggregator.aggregate_period(
            resolver=resolver,
            period=period1,
            period_type=comparison_type,
            project_key=project_key,
            repo_slug=repo_slug
        )
        p2_item = Aggregator.aggregate_period(
            resolver=resolver,
            period=period2,
            period_type=comparison_type,
            project_key=project_key,
            repo_slug=repo_slug
        )

        empty_eff = EfficiencyMetrics()
        p1_eff = p1_item.efficiency if p1_item else empty_eff
        p2_eff = p2_item.efficiency if p2_item else empty_eff

        def make_delta(key: str, label: str, val1: float, val2: float, higher_is_better: bool = True) -> MetricDelta:
            diff = round(val2 - val1, 2)
            if val1 != 0:
                pct = round((diff / val1) * 100, 1)
            else:
                pct = 0.0 if diff == 0 else 100.0
            return MetricDelta(
                metric_key=key,
                label=label,
                period1_val=val1,
                period2_val=val2,
                diff=diff,
                pct_change=pct,
                higher_is_better=higher_is_better
            )

        c1 = p1_item.total_commits if p1_item else 0
        c2 = p2_item.total_commits if p2_item else 0
        pr1 = p1_item.total_pull_requests if p1_item else 0
        pr2 = p2_item.total_pull_requests if p2_item else 0
        la1 = p1_item.total_lines_added if p1_item else 0
        la2 = p2_item.total_lines_added if p2_item else 0
        ld1 = p1_item.total_lines_deleted if p1_item else 0
        ld2 = p2_item.total_lines_deleted if p2_item else 0
        u1 = p1_item.total_active_users if p1_item else 0
        u2 = p2_item.total_active_users if p2_item else 0
        r1 = p1_item.total_repositories if p1_item else 0
        r2 = p2_item.total_repositories if p2_item else 0

        deltas = [
            make_delta("total_commits", "Total Commits", c1, c2, True),
            make_delta("total_pull_requests", "Total Pull Requests", pr1, pr2, True),
            make_delta("total_lines_added", "Total Lines Added", la1, la2, True),
            make_delta("total_lines_deleted", "Lines Deleted", ld1, ld2, False),
            make_delta("total_active_users", "Active Contributors", u1, u2, True),
            make_delta("total_repositories", "Active Repositories", r1, r2, True),
            make_delta("avg_commits_per_repo", "Avg Commits / Repo", p1_eff.avg_commits_per_repo, p2_eff.avg_commits_per_repo, True),
            make_delta("avg_commits_per_project", "Avg Commits / Project", p1_eff.avg_commits_per_project, p2_eff.avg_commits_per_project, True),
            make_delta("avg_commits_per_user", "Avg Commits / User", p1_eff.avg_commits_per_user, p2_eff.avg_commits_per_user, True),
            make_delta("avg_prs_per_repo", "Avg PRs / Repo", p1_eff.avg_prs_per_repo, p2_eff.avg_prs_per_repo, True),
            make_delta("avg_prs_per_project", "Avg PRs / Project", p1_eff.avg_prs_per_project, p2_eff.avg_prs_per_project, True),
            make_delta("avg_prs_per_user", "Avg PRs / User", p1_eff.avg_prs_per_user, p2_eff.avg_prs_per_user, True),
            make_delta("avg_lines_per_commit", "Avg Lines / Commit", p1_eff.avg_lines_per_commit, p2_eff.avg_lines_per_commit, True),
        ]

        # Repository-level comparisons
        p1_repos = { (r.project_key, r.repo_slug): r for r in (p1_item.repositories if p1_item else []) }
        p2_repos = { (r.project_key, r.repo_slug): r for r in (p2_item.repositories if p2_item else []) }
        all_repo_keys = sorted(set(list(p1_repos.keys()) + list(p2_repos.keys())))

        repo_comparisons: List[RepoComparisonItem] = []
        for key in all_repo_keys:
            r1_obj = p1_repos.get(key)
            r2_obj = p2_repos.get(key)
            r_name = (r2_obj.repo_name if r2_obj else (r1_obj.repo_name if r1_obj else key[1]))
            rc1 = r1_obj.commits if r1_obj else 0
            rc2 = r2_obj.commits if r2_obj else 0
            rpr1 = r1_obj.pull_requests if r1_obj else 0
            rpr2 = r2_obj.pull_requests if r2_obj else 0
            rla1 = r1_obj.lines_added if r1_obj else 0
            rla2 = r2_obj.lines_added if r2_obj else 0
            rld1 = r1_obj.lines_deleted if r1_obj else 0
            rld2 = r2_obj.lines_deleted if r2_obj else 0
            ru1 = len(r1_obj.users) if r1_obj else 0
            ru2 = len(r2_obj.users) if r2_obj else 0

            def calc_pct(v1, v2):
                d = v2 - v1
                return round((d / v1) * 100, 1) if v1 > 0 else (0.0 if d == 0 else 100.0)

            repo_comparisons.append(
                RepoComparisonItem(
                    project_key=key[0],
                    repo_slug=key[1],
                    repo_name=r_name,
                    commits_p1=rc1,
                    commits_p2=rc2,
                    commits_diff=rc2 - rc1,
                    commits_pct=calc_pct(rc1, rc2),
                    prs_p1=rpr1,
                    prs_p2=rpr2,
                    prs_diff=rpr2 - rpr1,
                    prs_pct=calc_pct(rpr1, rpr2),
                    lines_added_p1=rla1,
                    lines_added_p2=rla2,
                    lines_added_diff=rla2 - rla1,
                    lines_added_pct=calc_pct(rla1, rla2),
                    lines_deleted_p1=rld1,
                    lines_deleted_p2=rld2,
                    lines_deleted_diff=rld2 - rld1,
                    lines_deleted_pct=calc_pct(rld1, rld2),
                    users_p1=ru1,
                    users_p2=ru2,
                    users_diff=ru2 - ru1,
                    users_pct=calc_pct(ru1, ru2)
                )
            )

        p1_dict = p1_item.model_dump() if p1_item else {}
        p2_dict = p2_item.model_dump() if p2_item else {}

        return ComparisonResponse(
            comparison_type=comparison_type,
            period1=period1,
            period2=period2,
            project=project_key,
            repo=repo_slug,
            period1_metrics=p1_dict,
            period2_metrics=p2_dict,
            deltas=deltas,
            repo_comparisons=repo_comparisons
        )

