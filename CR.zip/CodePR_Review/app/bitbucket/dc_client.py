import logging
import requests
from requests.auth import HTTPBasicAuth
from typing import List, Optional, Generator
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from app.config.schema import BitbucketConfig
from app.bitbucket.models import Project, Repository
from app.bitbucket.pagination import paginate
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress SSL certificate verification warnings for corporate internal endpoints
urllib3.disable_warnings(InsecureRequestWarning)

logger = logging.getLogger("bitbucket.dc_client")


class _RequestsProxy:
    """Proxy object ensuring backwards-compatibility and direct requests.get execution."""
    def __init__(self, client):
        self._client = client

    def get(self, url: str, params: Optional[dict] = None, timeout: int = 30, **kwargs) -> requests.Response:
        req_headers = {**self._client.headers, **kwargs.pop("headers", {})}
        auth = kwargs.pop("auth", self._client.auth)
        verify = kwargs.pop("verify", False)
        return requests.get(
            url,
            auth=auth,
            headers=req_headers,
            params=params,
            timeout=timeout,
            verify=verify,
            **kwargs
        )


class BitbucketDCClient:
    """
    Client for Bitbucket Data Center standard REST API (/rest/api/latest).
    Specialized in discovering Projects, Repositories, and permissions.
    Strictly uses requests.get with auth=HTTPBasicAuth(username, password).
    """
    def __init__(self, config: BitbucketConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.api_prefix = config.dc_api_path.strip("/")
        self.username = config.get_username()
        self.password = config.get_password()
        self.auth = HTTPBasicAuth(self.username or "", self.password or "")
        self.headers = {
            "Accept": "application/json",
            "User-Agent": "Bitbucket-Activity-Report/1.0"
        }

        if not self.username or not self.password:
            missing = []
            if not self.username: missing.append(config.username_env)
            if not self.password: missing.append(config.password_env)
            logger.warning(f"Bitbucket DC Client: HTTPBasicAuth missing credentials! Unset env vars: {missing}")
        else:
            logger.info(f"Bitbucket DC Client strictly configured with HTTPBasicAuth for user '{self.username}'")

        self.session = _RequestsProxy(self)

    def _get(self, url: str, params: Optional[dict] = None, timeout: int = 30, **kwargs) -> requests.Response:
        """Execute GET request via self.session.get using HTTPBasicAuth."""
        return self.session.get(url, params=params, timeout=timeout, **kwargs)

    def list_projects(self) -> List[Project]:
        """
        List all accessible projects using GET /rest/api/latest/projects.
        If config.projects.keys is specified, filters down to those keys.
        """
        url = f"{self.base_url}/{self.api_prefix}/projects"
        logger.info(f"Querying Bitbucket DC for projects at: {url}")

        def fetch_page(start: int, limit: int):
            resp = self._get(url, params={"start": start, "limit": limit}, timeout=30)
            if resp.status_code == 401:
                logger.error(
                    f"HTTP 401 Unauthorized accessing Bitbucket: {url}\n"
                    f"  Please verify username ({self.config.username_env}) and password ({self.config.password_env}) credentials.\n"
                    f"  Bitbucket Server response header: {resp.headers.get('X-AUSERNAME', 'N/A')}"
                )
            resp.raise_for_status()
            return resp.json()

        all_projects = []
        configured_keys = set(k.upper() for k in self.config.projects.keys) if self.config.projects.keys else None

        for item in paginate(fetch_page, page_limit=50):
            proj = Project(
                key=item.get("key"),
                name=item.get("name", item.get("key")),
                id=item.get("id"),
                description=item.get("description"),
                public=item.get("public", False)
            )
            if configured_keys is None or proj.key.upper() in configured_keys:
                all_projects.append(proj)

        logger.info(f"Discovered {len(all_projects)} projects matching configuration (Filter={self.config.projects.keys or 'ALL'})")
        return all_projects

    def get_project(self, project_key: str) -> Optional[Project]:
        """GET /rest/api/latest/projects/{projectKey}"""
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}"
        try:
            resp = self._get(url, timeout=20)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            data = resp.json()
            return Project(
                key=data.get("key"),
                name=data.get("name", data.get("key")),
                id=data.get("id"),
                description=data.get("description"),
                public=data.get("public", False)
            )
        except Exception as e:
            logger.error(f"Failed to fetch project {project_key}: {e}")
            raise

    def list_repositories(self, project_key: str, limit: Optional[int] = None) -> List[Repository]:
        """
        List repositories for a project using GET /rest/api/latest/projects/{projectKey}/repos.
        Applies limit if specified.
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos"
        logger.info(f"Discovering repositories for project '{project_key}' at: {url}")

        def fetch_page(start: int, page_limit: int):
            resp = self._get(url, params={"start": start, "limit": page_limit}, timeout=30)
            if resp.status_code == 401:
                logger.error(f"HTTP 401 Unauthorized accessing Bitbucket repos: {url}")
            resp.raise_for_status()
            return resp.json()
            resp.raise_for_status()
            return resp.json()

        repos = []
        for item in paginate(fetch_page, page_limit=50):
            repo = Repository(
                slug=item.get("slug"),
                name=item.get("name", item.get("slug")),
                id=item.get("id"),
                project_key=project_key,
                project_name=item.get("project", {}).get("name")
            )
            repos.append(repo)
            if limit and len(repos) >= limit:
                logger.info(f"Reached configured limit of {limit} repositories for project '{project_key}'")
                break

        logger.info(f"Discovered {len(repos)} repositories in project '{project_key}'")
        return repos
