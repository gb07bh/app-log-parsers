import time
import logging
import requests
from requests.auth import HTTPBasicAuth
from typing import List, Optional
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from app.config.schema import BitbucketConfig
from app.bitbucket.models import CommitEvent, PullRequestEvent
from app.bitbucket.pagination import paginate
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress SSL certificate verification warnings for corporate internal endpoints
urllib3.disable_warnings(InsecureRequestWarning)

logger = logging.getLogger("bitbucket.awesome_graphs")


class _RequestsProxy:
    """Proxy object ensuring backwards-compatibility and direct requests.get execution."""
    def __init__(self, client):
        self._client = client

    def get(self, url: str, params: Optional[dict] = None, timeout: int = 45, **kwargs) -> requests.Response:
        req_headers = {**self._client.headers, **kwargs.pop("headers", {})}
        auth = kwargs.pop("auth", self._client.auth)
        verify = kwargs.pop("verify", False)
        return requests.get(
            url,
            auth=auth,
            headers=req_headers,
            params=params,
            timeout=timeout,
            verify=verify,
            **kwargs
        )


class AwesomeGraphsClient:
    """
    Client for Stiltsoft Awesome Graphs for Bitbucket REST API
    (/rest/awesome-graphs-api/latest).
    Specialized in high-performance Commit and Pull Request activity extraction.
    Strictly uses requests.get with auth=HTTPBasicAuth(username, password).
    """
    def __init__(self, config: BitbucketConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.api_prefix = config.awesome_graphs_api_path.strip("/")
        self.username = config.get_username()
        self.password = config.get_password()
        self.auth = HTTPBasicAuth(self.username or "", self.password or "")
        self.headers = {
            "Accept": "application/json",
            "User-Agent": "Bitbucket-Awesome-Graphs-Client/1.0"
        }

        if not self.username or not self.password:
            missing = []
            if not self.username: missing.append(config.username_env)
            if not self.password: missing.append(config.password_env)
            logger.warning(f"Awesome Graphs Client: HTTPBasicAuth missing credentials! Unset env vars: {missing}")
        else:
            logger.info(f"Awesome Graphs Client strictly configured with HTTPBasicAuth for user '{self.username}'")

        self.session = _RequestsProxy(self)

    def _get(self, url: str, params: Optional[dict] = None, timeout: int = 45, **kwargs) -> requests.Response:
        """Execute GET request via self.session.get using HTTPBasicAuth."""
        return self.session.get(url, params=params, timeout=timeout, **kwargs)

    def list_repo_commits(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[CommitEvent]:
        """
        Query commits for repository via:
        GET /rest/awesome-graphs-api/latest/projects/{projectKey}/repos/{repositorySlug}/commits
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos/{repo_slug}/commits"
        params = {"merges": "include", "order": "newest"}
        if since_date:
            params["sinceDate"] = since_date
        if until_date:
            params["untilDate"] = until_date

        commits = []
        start_time = time.time()

        def fetch_page(start: int, limit: int):
            page_params = {**params, "start": start, "limit": min(limit, 500)}
            req_start = time.time()
            resp = self._get(url, params=page_params, timeout=45)
            duration_ms = int((time.time() - req_start) * 1000)

            logger.info(
                f"AwesomeGraphs Query: GET {url} | Params: {page_params} | Status: {resp.status_code} | Latency: {duration_ms}ms"
            )
            resp.raise_for_status()
            return resp.json()

        try:
            for item in paginate(fetch_page, page_limit=100):
                author = item.get("author", {})
                user_id = author.get("name") or author.get("slug") or author.get("displayName") or "unknown"
                display_name = author.get("displayName") or user_id
                email = author.get("emailAddress")
                lines_info = item.get("linesOfCode", {})

                commit_event = CommitEvent(
                    event_id=item.get("id", ""),
                    project_key=project_key,
                    repo_slug=repo_slug,
                    user_id=user_id,
                    display_name=display_name,
                    email=email,
                    timestamp=item.get("authorTimestamp", ""),
                    lines_added=lines_info.get("added", 0),
                    lines_deleted=lines_info.get("deleted", 0)
                )
                commits.append(commit_event)

            total_ms = int((time.time() - start_time) * 1000)
            logger.info(
                f"Completed commits extraction for {project_key}/{repo_slug}: {len(commits)} commits retrieved in {total_ms}ms"
            )
            return commits
        except Exception as e:
            logger.error(f"Error extracting commits for {project_key}/{repo_slug}: {e}", exc_info=True)
            raise

    def list_repo_pull_requests(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[PullRequestEvent]:
        """
        Query pull requests for repository via:
        GET /rest/awesome-graphs-api/latest/projects/{projectKey}/repos/{repositorySlug}/pull-requests
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos/{repo_slug}/pull-requests"
        params = {}
        if since_date:
            params["sinceDate"] = since_date
        if until_date:
            params["untilDate"] = until_date

        prs = []
        start_time = time.time()

        def fetch_page(start: int, limit: int):
            page_params = {**params, "start": start, "limit": min(limit, 500)}
            req_start = time.time()
            resp = self._get(url, params=page_params, timeout=45)
            duration_ms = int((time.time() - req_start) * 1000)

            logger.info(
                f"AwesomeGraphs Query: GET {url} | Params: {page_params} | Status: {resp.status_code} | Latency: {duration_ms}ms"
            )
            resp.raise_for_status()
            return resp.json()

        try:
            for item in paginate(fetch_page, page_limit=100):
                author = item.get("author", {}).get("user", {})
                user_id = author.get("name") or author.get("slug") or author.get("displayName") or "unknown"
                display_name = author.get("displayName") or user_id

                pr_event = PullRequestEvent(
                    event_id=str(item.get("id", "")),
                    project_key=project_key,
                    repo_slug=repo_slug,
                    user_id=user_id,
                    display_name=display_name,
                    title=item.get("title"),
                    state=item.get("state"),
                    created_date=item.get("createdDate", item.get("created_date", "")),
                    updated_date=item.get("updatedDate"),
                    closed_date=item.get("closedDate")
                )
                prs.append(pr_event)

            total_ms = int((time.time() - start_time) * 1000)
            logger.info(
                f"Completed PRs extraction for {project_key}/{repo_slug}: {len(prs)} PRs retrieved in {total_ms}ms"
            )
            return prs
        except Exception as e:
            logger.error(f"Error extracting PRs for {project_key}/{repo_slug}: {e}", exc_info=True)
            raise
