import logging
import requests
from typing import Dict, Any, Optional
from app.config.schema import JenkinsConfig

logger = logging.getLogger("runner.jenkins_client")


class JenkinsClient:
    """Client for triggering remote Jenkins pipeline jobs for scanning."""

    def __init__(self, config: JenkinsConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.job_name = config.job_name
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        session.verify = False
        token = self.config.get_token()
        username = self.config.get_username()
        if username and token:
            session.auth = (username, token)
        return session

    def trigger_scan_job(
        self,
        month: str,
        force_rescan: bool = False,
        worker_count: int = 5
    ) -> Dict[str, Any]:
        """
        Trigger remote Jenkins job via buildWithParameters.
        """
        if not self.config.enabled:
            return {
                "success": False,
                "message": "Jenkins integration is disabled in configuration."
            }

        url = f"{self.base_url}/job/{self.job_name}/buildWithParameters"
        params = {
            "MONTH": month,
            "FORCE_RESCAN": str(force_rescan).lower(),
            "WORKERS": str(worker_count)
        }

        logger.info(f"Triggering Jenkins build at {url} with params: {params}")
        try:
            resp = self.session.post(url, data=params, timeout=30)
            if resp.status_code in [200, 201]:
                queue_location = resp.headers.get("Location", "")
                logger.info(f"Jenkins job successfully scheduled. Queue item: {queue_location}")
                return {
                    "success": True,
                    "status": "TRIGGERED",
                    "queue_url": queue_location,
                    "message": f"Jenkins job '{self.job_name}' queued for month {month}."
                }
            else:
                logger.error(f"Failed to trigger Jenkins job (HTTP {resp.status_code}): {resp.text}")
                return {
                    "success": False,
                    "status": "FAILED",
                    "error": f"HTTP {resp.status_code}: {resp.text}"
                }
        except Exception as e:
            logger.error(f"Error calling Jenkins API: {e}", exc_info=True)
            return {
                "success": False,
                "status": "ERROR",
                "error": str(e)
            }
