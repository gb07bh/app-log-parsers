import os
import json
import logging
import requests
from typing import Optional, Dict, Any
from app.config.schema import ArtifactoryConfig
from app.reporting.models import ReportData
from app.reporting.exporter import Exporter

logger = logging.getLogger("storage.artifactory")


class ArtifactoryClient:
    """
    Client for publishing and pulling reports to/from JFrog Artifactory.
    Path layout in repository:
      {path}/YYYY/MM/{job_id}/
        ├── report.json
        ├── report.csv
        └── metadata.json
    """

    def __init__(self, config: ArtifactoryConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.repository = config.repository.strip("/")
        self.path_prefix = config.path.strip("/")
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        session.verify = False
        token = self.config.get_token()
        if token:
            session.headers.update({"Authorization": f"Bearer {token}"})
        else:
            user = self.config.get_username()
            pwd = self.config.get_password()
            if user and pwd:
                session.auth = (user, pwd)
        return session

    def _build_url(self, rel_path: str) -> str:
        return f"{self.base_url}/{self.repository}/{self.path_prefix}/{rel_path.lstrip('/')}"

    def publish_report(self, report: ReportData) -> bool:
        """Upload report.json, report.csv, and metadata.json to Artifactory."""
        if not self.config.enabled:
            logger.info("Artifactory publishing is disabled in configuration.")
            return False

        meta = report.metadata
        year_month = meta.period_start[:7]  # YYYY-MM
        parts = year_month.split("-")
        yyyy, mm = (parts[0], parts[1]) if len(parts) >= 2 else (year_month, "01")

        base_rel_path = f"{yyyy}/{mm}/{meta.job_id}"
        latest_rel_path = f"{yyyy}/{mm}/latest"

        files_to_upload = {
            "report.json": (Exporter.to_json(report), "application/json"),
            "report.csv": (Exporter.to_csv(report), "text/csv"),
            "metadata.json": (Exporter.metadata_to_json(meta), "application/json")
        }

        success = True
        for target_rel in [base_rel_path, latest_rel_path]:
            for filename, (content, content_type) in files_to_upload.items():
                url = self._build_url(f"{target_rel}/{filename}")
                try:
                    resp = self.session.put(
                        url,
                        data=content.encode("utf-8"),
                        headers={"Content-Type": content_type},
                        timeout=60
                    )
                    if resp.status_code in [200, 201]:
                        logger.info(f"Successfully published {filename} to Artifactory: {url}")
                    else:
                        logger.error(f"Failed to publish {filename} to Artifactory (HTTP {resp.status_code}): {resp.text}")
                        success = False
                except Exception as e:
                    logger.error(f"Artifactory upload failed for {url}: {e}")
                    success = False

        return success

    def download_report(self, year_month: str, job_id: Optional[str] = "latest") -> Optional[ReportData]:
        """
        Pull report.json from Artifactory for the given month/job_id.
        """
        if not self.config.enabled:
            return None

        parts = year_month.split("-")
        yyyy, mm = (parts[0], parts[1]) if len(parts) >= 2 else (year_month, "01")
        target_id = job_id or "latest"
        rel_path = f"{yyyy}/{mm}/{target_id}/report.json"
        url = self._build_url(rel_path)

        logger.info(f"Checking Artifactory for report at: {url}")
        try:
            resp = self.session.get(url, timeout=30)
            if resp.status_code == 200:
                logger.info(f"Successfully downloaded report from Artifactory ({url})")
                data = resp.json()
                return ReportData(**data)
            elif resp.status_code == 404:
                logger.info(f"Report not found in Artifactory at {url}")
                return None
            else:
                logger.warning(f"Unexpected response from Artifactory (HTTP {resp.status_code}): {resp.text}")
                return None
        except Exception as e:
            logger.error(f"Error querying Artifactory for {url}: {e}")
            return None
