# OpenSearch client with retries
