# Artifactory GET/PUT/HEAD client
