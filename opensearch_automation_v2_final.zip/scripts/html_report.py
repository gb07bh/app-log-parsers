# Chart.js dashboard generator
