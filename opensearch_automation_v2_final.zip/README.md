# OpenSearch Automation V2
Includes cleanup, metrics, dashboard, Artifactory integration, Chart.js reporting.
