import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, current_app

from app.config.schema import AppConfig
from app.runner.jenkins_client import JenkinsClient

logger = logging.getLogger("api.job_routes")
job_bp = Blueprint("jobs", __name__, url_prefix="/api/reports/jobs")


@job_bp.route("/run", methods=["POST"])
def trigger_run():
    """
    POST /api/reports/jobs/run
    Trigger a scan.
    NOTE: Flask strictly DOES NOT execute scan runners in-process.
    If Jenkins integration is enabled, this triggers the remote Jenkins job.
    Otherwise, it returns guidance to run via external CLI / CI.
    """
    cfg: AppConfig = current_app.config["APP_CONFIG"]
    data = request.get_json(silent=True) or {}
    month = data.get("month") or datetime.now(timezone.utc).strftime("%Y-%m")
    force_rescan = bool(data.get("force_rescan", False))

    if not cfg.execution.run_now_enabled:
        return jsonify({
            "status": "DISABLED",
            "message": "Run Now is disabled by configuration (run_now_enabled: false)."
        }), 403

    # If Jenkins is configured, trigger Jenkins build
    if cfg.jenkins.enabled:
        jenkins = JenkinsClient(cfg.jenkins)
        result = jenkins.trigger_scan_job(
            month=month,
            force_rescan=force_rescan,
            worker_count=cfg.workers.count
        )
        return jsonify(result), (200 if result.get("success") else 500)

    # If Jenkins is not enabled, inform that Flask does not run scans in-process
    return jsonify({
        "status": "EXTERNAL_RUNNER_REQUIRED",
        "message": (
            "Flask is strictly a presentation and report-pulling server. "
            f"Please run the scan on your external worker or Jenkins server: "
            f"`python app/main.py scan --month {month}`."
        ),
        "month": month,
        "hint": "Enable jenkins in config.yaml to allow triggering remote builds directly from this button."
    }), 200


@job_bp.route("/status", methods=["GET"])
def get_status():
    cfg: AppConfig = current_app.config["APP_CONFIG"]
    return jsonify({
        "runner_mode": "jenkins" if cfg.jenkins.enabled else "cli_external",
        "jenkins_enabled": cfg.jenkins.enabled,
        "run_now_enabled": cfg.execution.run_now_enabled
    }), 200
