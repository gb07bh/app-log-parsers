import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, current_app

from app.storage.resolver import ReportResolver
from app.reporting.search import SearchService

logger = logging.getLogger("api.search_routes")
search_bp = Blueprint("search", __name__, url_prefix="/api/search")


@search_bp.route("", methods=["GET"])
def search():
    """
    GET /api/search?q=<query>&month=YYYY-MM
    Searches across projects, repositories, and user IDs in the active report.
    """
    query = request.args.get("q", "").strip()
    month = request.args.get("month", datetime.now(timezone.utc).strftime("%Y-%m"))

    if not query:
        return jsonify({"query": "", "results": []}), 200

    resolver: ReportResolver = current_app.config["REPORT_RESOLVER"]
    report = resolver.resolve_report_for_month(month)

    if not report:
        return jsonify({
            "query": query,
            "results": [],
            "message": f"No active report loaded for month {month} to search within."
        }), 200

    results = SearchService.search(report, query)
    return jsonify({
        "query": query,
        "month": month,
        "total_results": len(results),
        "results": results
    }), 200
