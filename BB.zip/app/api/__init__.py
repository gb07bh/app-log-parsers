from app.api.routes import base_bp
from app.api.report_routes import report_bp
from app.api.search_routes import search_bp
from app.api.job_routes import job_bp

__all__ = ["base_bp", "report_bp", "search_bp", "job_bp"]
