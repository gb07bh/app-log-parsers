from flask import Blueprint, jsonify, current_app

base_bp = Blueprint("base", __name__)


@base_bp.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy", "service": "bitbucket-activity-report"}), 200


@base_bp.route("/ready", methods=["GET"])
def ready():
    return jsonify({"status": "ready"}), 200


@base_bp.route("/api/config", methods=["GET"])
def get_safe_config():
    """
    Expose safe, non-sensitive operational configuration settings.
    Credentials (passwords, tokens) are NEVER exposed.
    """
    cfg = current_app.config["APP_CONFIG"]
    return jsonify({
        "application": {
            "name": cfg.application.name,
            "environment": cfg.application.environment,
        },
        "bitbucket": {
            "base_url": cfg.bitbucket.base_url,
            "configured_projects": cfg.bitbucket.projects.keys,
            "repository_limit": cfg.bitbucket.repositories.limit,
        },
        "artifactory": {
            "enabled": cfg.artifactory.enabled,
            "base_url": cfg.artifactory.base_url if cfg.artifactory.enabled else None,
            "repository": cfg.artifactory.repository if cfg.artifactory.enabled else None,
        },
        "jenkins": {
            "enabled": cfg.jenkins.enabled,
            "job_name": cfg.jenkins.job_name if cfg.jenkins.enabled else None,
        },
        "workers": {
            "count": cfg.workers.count
        },
        "execution": {
            "run_now_enabled": cfg.execution.run_now_enabled
        }
    }), 200
