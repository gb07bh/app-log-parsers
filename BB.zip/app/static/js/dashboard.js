// Bitbucket CodePR_Review Dashboard Logic
let activeReport = null;
let activityChart = null;
let userCommitChart = null;
let projectCommitChart = null;
let repoCommitChart = null;

// Palette for multi-project charts
const PROJECT_COLORS = [
  "#38bdf8", // Sky blue
  "#a855f7", // Purple
  "#10b981", // Emerald green
  "#f59e0b", // Amber
  "#ec4899", // Pink
  "#6366f1", // Indigo
  "#14b8a6", // Teal
  "#f97316", // Orange
];

document.addEventListener("DOMContentLoaded", () => {
  initEventListeners();
  loadCurrentMonthReport();
});

function initEventListeners() {
  const monthPicker = document.getElementById("monthPicker");
  const btnLoadMonth = document.getElementById("btnLoadMonth");
  const btnPullArtifactory = document.getElementById("btnPullArtifactory");
  const btnRunNow = document.getElementById("btnRunNow");
  const btnResetRange = document.getElementById("btnResetRange");
  const btnExportCsv = document.getElementById("btnExportCsv");
  const btnExportJson = document.getElementById("btnExportJson");
  const btnSearch = document.getElementById("btnSearch");
  const searchInput = document.getElementById("globalSearchInput");
  const btnCloseSearchModal = document.getElementById("btnCloseSearchModal");
  const btnCloseRunModal = document.getElementById("btnCloseRunModal");
  const btnDismissRunModal = document.getElementById("btnDismissRunModal");
  const btnCloseUserModal = document.getElementById("btnCloseUserModal");

  btnLoadMonth.addEventListener("click", () => {
    loadReport(monthPicker.value);
  });

  monthPicker.addEventListener("change", () => {
    loadReport(monthPicker.value);
  });

  btnPullArtifactory.addEventListener("click", () => {
    loadReport(monthPicker.value, true);
  });

  btnRunNow.addEventListener("click", handleRunNow);
  btnResetRange.addEventListener("click", resetRange);

  btnExportCsv.addEventListener("click", () => {
    const month = monthPicker.value;
    window.location.href = `/api/reports/export?month=${month}&format=csv`;
  });

  btnExportJson.addEventListener("click", () => {
    const month = monthPicker.value;
    window.location.href = `/api/reports/export?month=${month}&format=json`;
  });

  // Presets
  document.querySelectorAll(".btn-chip").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      handlePreset(e.target.dataset.preset);
    });
  });

  // Search
  btnSearch.addEventListener("click", executeSearch);
  searchInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") executeSearch();
  });
  btnCloseSearchModal.addEventListener("click", () => {
    document.getElementById("searchModal").classList.add("hidden");
  });

  // Run modal
  const hideRunModal = () => document.getElementById("runModal").classList.add("hidden");
  btnCloseRunModal.addEventListener("click", hideRunModal);
  btnDismissRunModal.addEventListener("click", hideRunModal);

  // User modal
  if (btnCloseUserModal) {
    btnCloseUserModal.addEventListener("click", () => {
      document.getElementById("userModal").classList.add("hidden");
    });
  }

  // Project modal
  const btnCloseProjectModal = document.getElementById("btnCloseProjectModal");
  if (btnCloseProjectModal) {
    btnCloseProjectModal.addEventListener("click", () => {
      document.getElementById("projectModal").classList.add("hidden");
    });
  }

  // Repo modal
  const btnCloseRepoModal = document.getElementById("btnCloseRepoModal");
  if (btnCloseRepoModal) {
    btnCloseRepoModal.addEventListener("click", () => {
      document.getElementById("repoModal").classList.add("hidden");
    });
  }
}

function showNotification(message, type = "info") {
  const banner = document.getElementById("notificationBanner");
  banner.className = `alert alert-${type}`;
  banner.textContent = message;
  banner.classList.remove("hidden");
}

function hideNotification() {
  const banner = document.getElementById("notificationBanner");
  banner.classList.add("hidden");
}

function loadCurrentMonthReport() {
  const monthPicker = document.getElementById("monthPicker");
  if (!monthPicker.value) {
    const now = new Date();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    monthPicker.value = `${now.getFullYear()}-${mm}`;
  }
  loadReport(monthPicker.value);
}

async function loadReport(month, forcePull = false) {
  hideNotification();
  if (forcePull) {
    showNotification(`Querying Artifactory for ${month} report...`, "info");
  }

  try {
    const url = `/api/reports/latest?month=${month}${forcePull ? "&force_pull=true" : ""}`;
    const resp = await fetch(url);
    const data = await resp.json();

    if (resp.status === 404) {
      activeReport = null;
      renderEmptyState(data.message);
      showNotification(data.message, "warning");
      return;
    }

    if (!resp.ok) {
      throw new Error(data.message || `HTTP ${resp.status}`);
    }

    activeReport = data;
    hideNotification();
    if (forcePull) {
      showNotification(`Successfully pulled and loaded report for ${month} from Artifactory.`, "success");
    }

    renderKPIs(activeReport.total_commits, activeReport.total_pull_requests, activeReport.total_repositories, activeReport.total_active_users);
    renderChart(activeReport.timeline);
    renderTable(activeReport.repositories);
  } catch (err) {
    console.error("Error loading report:", err);
    renderEmptyState(`Failed to load report: ${err.message}`);
    showNotification(`Error: ${err.message}`, "danger");
  }
}

function renderKPIs(commits, prs, repos, users) {
  document.getElementById("kpiCommits").textContent = Number(commits).toLocaleString();
  document.getElementById("kpiPRs").textContent = Number(prs).toLocaleString();
  document.getElementById("kpiRepos").textContent = Number(repos).toLocaleString();
  document.getElementById("kpiUsers").textContent = Number(users).toLocaleString();
}

function renderEmptyState(message) {
  renderKPIs(0, 0, 0, 0);
  if (activityChart) {
    activityChart.destroy();
    activityChart = null;
  }
  const tbody = document.getElementById("reposTableBody");
  tbody.innerHTML = `<tr><td colspan="7" class="text-center" style="padding: 2rem; color: #94a3b8;">${message}</td></tr>`;
}

function renderChart(timeline) {
  const ctx = document.getElementById("activityChart").getContext("2d");
  if (activityChart) {
    activityChart.destroy();
  }

  const labels = (timeline || []).map((t) => t.date);
  const commitData = (timeline || []).map((t) => t.commits);
  const prData = (timeline || []).map((t) => t.pull_requests);

  activityChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Commits",
          data: commitData,
          backgroundColor: "#38bdf8",
          borderRadius: 3,
        },
        {
          label: "Pull Requests",
          data: prData,
          backgroundColor: "#a855f7",
          borderRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          labels: { color: "#94a3b8" },
        },
        tooltip: {
          mode: "index",
          intersect: false,
        },
      },
      scales: {
        x: {
          ticks: { color: "#94a3b8" },
          grid: { color: "rgba(51, 65, 85, 0.4)" },
        },
        y: {
          ticks: { color: "#94a3b8" },
          grid: { color: "rgba(51, 65, 85, 0.4)" },
          beginAtZero: true,
        },
      },
      onClick: async (evt, elements) => {
        if (elements && elements.length > 0) {
          const index = elements[0].index;
          const selectedDate = labels[index];
          sliceSummary(selectedDate, selectedDate);
        }
      },
    },
  });
}

async function sliceSummary(fromDate, toDate) {
  if (!activeReport) return;
  const month = document.getElementById("monthPicker").value;
  try {
    const resp = await fetch(`/api/reports/summary?month=${month}&from=${fromDate}&to=${toDate}`);
    if (resp.ok) {
      const data = await resp.json();
      renderKPIs(data.commits, data.pull_requests, data.repositories, data.active_users);
      document.getElementById("rangeBadge").textContent = `Selected: ${fromDate} to ${toDate}`;
    }
  } catch (e) {
    console.error("Slice summary failed:", e);
  }
}

function resetRange() {
  if (!activeReport) return;
  renderKPIs(
    activeReport.total_commits,
    activeReport.total_pull_requests,
    activeReport.total_repositories,
    activeReport.total_active_users
  );
  document.getElementById("rangeBadge").textContent = "Full Range";
}

function renderTable(repositories) {
  const tbody = document.getElementById("reposTableBody");
  tbody.innerHTML = "";

  if (!repositories || repositories.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center">No repository activity recorded for this period.</td></tr>`;
    return;
  }

  repositories.forEach((repo, idx) => {
    const parentRow = document.createElement("tr");
    parentRow.className = "row-expandable";
    parentRow.id = `repo-row-${idx}`;
    parentRow.innerHTML = `
      <td><span class="chevron" id="chevron-${idx}">▶</span></td>
      <td><a class="project-link" href="javascript:void(0)" onclick="openProjectProfile('${escapeHtml(repo.project_key)}')"><strong>${escapeHtml(repo.project_key)}</strong></a></td>
      <td>
        <a class="repo-link" href="javascript:void(0)" onclick="openRepoProfile('${escapeHtml(repo.project_key)}', '${escapeHtml(repo.repo_slug)}')"><strong>${escapeHtml(repo.repo_name)}</strong></a>
        <span style="color:#64748b; font-size:0.8em;">(${escapeHtml(repo.repo_slug)})</span>
      </td>
      <td class="text-right"><strong>${Number(repo.commits).toLocaleString()}</strong></td>
      <td class="text-right"><strong>${Number(repo.pull_requests).toLocaleString()}</strong></td>
      <td class="text-right">${Number(repo.unique_commit_authors).toLocaleString()}</td>
      <td class="text-right">${Number(repo.unique_pr_authors).toLocaleString()}</td>
    `;

    // Child row containing user drilldown
    const childRow = document.createElement("tr");
    childRow.className = "child-row hidden";
    childRow.id = `child-row-${idx}`;

    let userTableHtml = "";
    if (!repo.users || repo.users.length === 0) {
      userTableHtml = `<p style="padding: 0.5rem; color: #94a3b8;">No individual user events recorded.</p>`;
    } else {
      userTableHtml = `
        <table class="user-drilldown-table">
          <thead>
            <tr>
              <th>Contributor</th>
              <th>User ID</th>
              <th class="text-right">Commits</th>
              <th class="text-right">Pull Requests</th>
              <th class="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${repo.users
              .map(
                (u) => `
              <tr>
                <td><a class="user-link" href="javascript:void(0)" onclick="openUserProfile('${escapeHtml(u.user_id)}')"><strong>${escapeHtml(u.display_name)}</strong></a></td>
                <td><code>${escapeHtml(u.user_id)}</code></td>
                <td class="text-right">${Number(u.commits).toLocaleString()}</td>
                <td class="text-right">${Number(u.pull_requests).toLocaleString()}</td>
                <td class="text-right">
                  <button class="btn-view-graph" onclick="openUserProfile('${escapeHtml(u.user_id)}')">📈 View Graph</button>
                </td>
              </tr>
            `
              )
              .join("")}
          </tbody>
        </table>
      `;
    }

    childRow.innerHTML = `
      <td></td>
      <td colspan="6" style="padding: 0.5rem 1rem;">
        <h4 style="font-size:0.85rem; margin-bottom:0.25rem; color:#93c5fd;">User Activity Drill-Down for ${escapeHtml(repo.repo_name)}</h4>
        ${userTableHtml}
      </td>
    `;

    parentRow.addEventListener("click", (e) => {
      // Don't toggle row if clicking inside action buttons or user link
      if (e.target.closest("button") || e.target.closest("a")) return;
      const isExpanded = parentRow.classList.toggle("expanded");
      childRow.classList.toggle("hidden", !isExpanded);
      document.getElementById(`chevron-${idx}`).textContent = isExpanded ? "▼" : "▶";
    });

    tbody.appendChild(parentRow);
    tbody.appendChild(childRow);
  });
}

function handlePreset(preset) {
  const monthPicker = document.getElementById("monthPicker");
  const now = new Date();

  if (preset === "current-month") {
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    monthPicker.value = `${now.getFullYear()}-${mm}`;
    loadReport(monthPicker.value);
  } else if (preset === "prev-month") {
    const prev = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const mm = String(prev.getMonth() + 1).padStart(2, "0");
    monthPicker.value = `${prev.getFullYear()}-${mm}`;
    loadReport(monthPicker.value);
  } else if (preset === "last-7" || preset === "last-30") {
    const days = preset === "last-7" ? 7 : 30;
    const target = new Date();
    target.setDate(now.getDate() - days);
    const fromStr = target.toISOString().split("T")[0];
    const toStr = now.toISOString().split("T")[0];
    sliceSummary(fromStr, toStr);
  }
}

async function handleRunNow() {
  const modal = document.getElementById("runModal");
  const modalTitle = document.getElementById("runModalTitle");
  const modalMsg = document.getElementById("runModalBody");
  const month = document.getElementById("monthPicker").value;

  modalTitle.textContent = "Run Now - Scan Trigger";
  modalMsg.innerHTML = `<p>Connecting to runner service...</p>`;
  modal.classList.remove("hidden");

  try {
    const resp = await fetch("/api/reports/jobs/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ month: month }),
    });
    const result = await resp.json();

    if (result.status === "TRIGGERED") {
      modalMsg.innerHTML = `
        <div class="alert alert-success">
          <strong>Jenkins Build Triggered!</strong><br>
          ${escapeHtml(result.message)}<br>
          <small>Queue URL: ${escapeHtml(result.queue_url || "N/A")}</small>
        </div>
        <p>The Jenkins pipeline job is now executing Bitbucket Data Center and Awesome Graphs extraction. Once finished, click <strong>"Pull from Artifactory"</strong> to view the report.</p>
      `;
    } else if (result.status === "EXTERNAL_RUNNER_REQUIRED") {
      modalMsg.innerHTML = `
        <div class="alert alert-info">
          <strong>External Scan Required</strong><br>
          ${escapeHtml(result.message)}
        </div>
        <p>To run the scan for <strong>${month}</strong> on your worker or terminal:</p>
        <pre style="background:#0f172a; padding:0.75rem; border-radius:0.375rem; margin-top:0.5rem; overflow-x:auto;"><code>python app/main.py scan --month ${month}</code></pre>
        <p style="margin-top:0.75rem; font-size:0.85rem; color:#94a3b8;">${escapeHtml(result.hint || "")}</p>
      `;
    } else {
      modalMsg.innerHTML = `<div class="alert alert-warning">${escapeHtml(result.message || "Unknown response")}</div>`;
    }
  } catch (err) {
    modalMsg.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(err.message)}</div>`;
  }
}

async function executeSearch() {
  const query = document.getElementById("globalSearchInput").value.trim();
  const month = document.getElementById("monthPicker").value;
  if (!query) return;

  const modal = document.getElementById("searchModal");
  const body = document.getElementById("searchResultsBody");
  body.innerHTML = `<p>Searching for "<strong>${escapeHtml(query)}</strong>"...</p>`;
  modal.classList.remove("hidden");

  try {
    const resp = await fetch(`/api/search?q=${encodeURIComponent(query)}&month=${month}`);
    const data = await resp.json();
    const results = data.results || [];

    if (results.length === 0) {
      body.innerHTML = `<p>No matches found for "<strong>${escapeHtml(query)}</strong>" in the active ${month} report.</p>`;
      return;
    }

    let html = `<p style="margin-bottom:0.75rem; color:#94a3b8;">Found ${results.length} result(s):</p>`;
    results.forEach((item) => {
      if (item.type === "user") {
        const multiProjectBadge = item.has_multiple_projects
          ? `<span class="badge badge-multi" title="Contributed across ${item.projects_count} projects: ${item.project_keys.join(', ')}">${item.projects_count} Projects</span>`
          : `<span class="badge">1 Project</span>`;

        html += `
          <div class="card" style="margin-bottom:0.75rem; padding:0.75rem; background: #0f172a;">
            <div style="display:flex; justify-content:space-between; align-items: flex-start;">
              <div>
                <strong>👤 ${escapeHtml(item.title)}</strong>
                <div style="margin-top:0.25rem; font-size:0.85rem; color:#94a3b8;">
                  Commits: <strong style="color:#38bdf8;">${item.commits}</strong> | 
                  Pull Requests: <strong style="color:#a855f7;">${item.pull_requests}</strong> | 
                  Repositories: <strong>${item.repositories}</strong>
                </div>
                ${item.project_keys ? `<div style="margin-top:0.2rem; font-size:0.8rem; color:#64748b;">Projects: ${escapeHtml(item.project_keys.join(', '))}</div>` : ''}
              </div>
              <div style="display:flex; flex-direction:column; align-items:flex-end; gap:0.3rem;">
                ${multiProjectBadge}
                <button class="btn-view-graph" onclick="openUserProfile('${escapeHtml(item.user_id)}')">
                  📈 View Commit Graph
                </button>
              </div>
            </div>
          </div>
        `;
      } else if (item.type === "project") {
        const multiRepoBadge = item.has_multiple_repos
          ? `<span class="badge badge-multi" title="Contains ${item.repositories_count} repositories: ${item.repo_slugs.join(', ')}">${item.repositories_count} Repos</span>`
          : `<span class="badge">1 Repo</span>`;

        html += `
          <div class="card" style="margin-bottom:0.75rem; padding:0.75rem; background: #0f172a;">
            <div style="display:flex; justify-content:space-between; align-items: flex-start;">
              <div>
                <strong>${escapeHtml(item.title)}</strong>
                <div style="margin-top:0.25rem; font-size:0.85rem; color:#94a3b8;">
                  Commits: <strong style="color:#38bdf8;">${item.commits}</strong> | 
                  Pull Requests: <strong style="color:#a855f7;">${item.pull_requests}</strong> | 
                  Contributors: <strong>${item.active_users}</strong>
                </div>
                ${item.repo_slugs ? `<div style="margin-top:0.2rem; font-size:0.8rem; color:#64748b;">Repositories: ${escapeHtml(item.repo_slugs.join(', '))}</div>` : ''}
              </div>
              <div style="display:flex; flex-direction:column; align-items:flex-end; gap:0.3rem;">
                ${multiRepoBadge}
                <button class="btn-view-project-graph" onclick="openProjectProfile('${escapeHtml(item.project_key)}')">
                  📊 View Project Graph
                </button>
              </div>
            </div>
          </div>
        `;
      } else {
        // Repository match
        html += `
          <div class="card" style="margin-bottom:0.75rem; padding:0.75rem; background: #0f172a;">
            <div style="display:flex; justify-content:space-between; align-items: flex-start;">
              <div>
                <strong>${escapeHtml(item.title)}</strong>
                <div style="margin-top:0.25rem; font-size:0.85rem; color:#94a3b8;">
                  Commits: <strong style="color:#38bdf8;">${item.commits}</strong> | 
                  Pull Requests: <strong style="color:#a855f7;">${item.pull_requests}</strong> | 
                  Contributors: <strong>${item.active_users}</strong>
                </div>
              </div>
              <div>
                <button class="btn-view-repo-graph" onclick="openRepoProfile('${escapeHtml(item.project_key)}', '${escapeHtml(item.repository_slug)}')">
                  📈 View Repo Graph
                </button>
              </div>
            </div>
          </div>
        `;
      }
    });
    body.innerHTML = html;
  } catch (err) {
    body.innerHTML = `<div class="alert alert-danger">Search error: ${escapeHtml(err.message)}</div>`;
  }
}

// User Profile & Commit Graph Modal Handler
async function openUserProfile(userId) {
  const month = document.getElementById("monthPicker").value;
  const userModal = document.getElementById("userModal");
  if (!userModal) return;

  // Close search modal if open
  document.getElementById("searchModal").classList.add("hidden");

  // Reset fields to loading
  document.getElementById("userModalName").textContent = "Loading...";
  document.getElementById("userModalId").textContent = `@${userId}`;
  document.getElementById("userKpiCommits").textContent = "...";
  document.getElementById("userKpiPRs").textContent = "...";
  document.getElementById("userKpiProjects").textContent = "...";
  document.getElementById("userKpiRepos").textContent = "...";
  document.getElementById("userProjectsTableBody").innerHTML = `<tr><td colspan="5" class="text-center">Loading contributions...</td></tr>`;

  userModal.classList.remove("hidden");

  try {
    const resp = await fetch(`/api/reports/users/${encodeURIComponent(userId)}?month=${month}`);
    if (!resp.ok) {
      throw new Error(`User data not found for ${userId} (HTTP ${resp.status})`);
    }
    const data = await resp.json();
    const profile = data.profile;

    renderUserProfileData(profile);
  } catch (err) {
    console.error("Error loading user profile:", err);
    document.getElementById("userModalName").textContent = "Error";
    document.getElementById("userProjectsTableBody").innerHTML = `<tr><td colspan="5" class="text-center" style="color:#ef4444;">${escapeHtml(err.message)}</td></tr>`;
  }
}

function renderUserProfileData(profile) {
  document.getElementById("userModalName").textContent = profile.display_name || profile.user_id;
  document.getElementById("userModalId").textContent = `@${profile.user_id}${profile.email ? ' • ' + profile.email : ''}`;
  document.getElementById("userKpiCommits").textContent = Number(profile.total_commits).toLocaleString();
  document.getElementById("userKpiPRs").textContent = Number(profile.total_pull_requests).toLocaleString();

  const contribs = profile.project_contributions || [];
  const uniqueProjects = Array.from(new Set(contribs.map((c) => c.project_key)));
  const uniqueRepos = Array.from(new Set(contribs.map((c) => `${c.project_key}/${c.repo_slug}`)));

  document.getElementById("userKpiProjects").textContent = uniqueProjects.length;
  document.getElementById("userKpiRepos").textContent = uniqueRepos.length;

  const projectsBadge = document.getElementById("userProjectsBadge");
  if (uniqueProjects.length > 1) {
    projectsBadge.className = "badge badge-multi";
    projectsBadge.textContent = `${uniqueProjects.length} Projects Contributed`;
  } else {
    projectsBadge.className = "badge";
    projectsBadge.textContent = `${uniqueProjects.length} Project Contributed`;
  }

  // Render the User Commit Graph (Overall or Multi-Project)
  renderUserCommitChart(profile, uniqueProjects);

  // Render Project Contributions Table
  renderUserContributionsTable(profile);
}

function renderUserCommitChart(profile, uniqueProjects) {
  const canvas = document.getElementById("userCommitChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  if (userCommitChart) {
    userCommitChart.destroy();
    userCommitChart = null;
  }

  const controls = document.getElementById("userChartControls");
  controls.innerHTML = "";

  const isMultiProject = uniqueProjects.length > 1;
  const subtitle = document.getElementById("userChartSubtitle");

  // Determine chart dates from active report or month days
  let dateLabels = [];
  if (activeReport && activeReport.timeline && activeReport.timeline.length > 0) {
    dateLabels = activeReport.timeline.map((t) => t.date);
  } else if (profile.timeline && profile.timeline.length > 0) {
    dateLabels = profile.timeline.map((t) => t.date);
  } else {
    const monthVal = document.getElementById("monthPicker").value || "2026-09";
    dateLabels = Array.from({ length: 28 }, (_, i) => `${monthVal}-${String(i + 1).padStart(2, "0")}`);
  }

  // Helper function to build single-user dataset
  const renderGeneralTimeline = () => {
    subtitle.textContent = "Daily commits and pull requests";
    const commitMap = new Map((profile.timeline || []).map((t) => [t.date, t.commits]));
    const prMap = new Map((profile.timeline || []).map((t) => [t.date, t.pull_requests]));

    let commitData = dateLabels.map((d) => commitMap.get(d) || 0);
    let prData = dateLabels.map((d) => prMap.get(d) || 0);

    // Fallback: If all 0s but total > 0, distribute across dates
    if (profile.total_commits > 0 && commitData.reduce((a, b) => a + b, 0) === 0) {
      const perDay = Math.max(1, Math.floor(profile.total_commits / dateLabels.length));
      commitData = dateLabels.map(() => perDay);
    }
    if (profile.total_pull_requests > 0 && prData.reduce((a, b) => a + b, 0) === 0) {
      const perDay = Math.max(1, Math.floor(profile.total_pull_requests / dateLabels.length));
      prData = dateLabels.map(() => perDay);
    }

    if (userCommitChart) userCommitChart.destroy();
    userCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: [
          {
            label: "Commits",
            data: commitData,
            backgroundColor: "#38bdf8",
            borderRadius: 3,
          },
          {
            label: "Pull Requests",
            data: prData,
            backgroundColor: "#a855f7",
            borderRadius: 3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            labels: { color: "#94a3b8" },
          },
          tooltip: {
            mode: "index",
            intersect: false,
          },
        },
        scales: {
          x: {
            ticks: { color: "#94a3b8" },
            grid: { color: "rgba(51, 65, 85, 0.4)" },
          },
          y: {
            ticks: { color: "#94a3b8" },
            grid: { color: "rgba(51, 65, 85, 0.4)" },
            beginAtZero: true,
          },
        },
      },
    });
  };

  // Helper function to build multi-project dataset
  const renderMultiProjectTimeline = () => {
    subtitle.textContent = `Comparing commit activity across ${uniqueProjects.length} projects`;

    const datasets = uniqueProjects.map((projKey, idx) => {
      const color = PROJECT_COLORS[idx % PROJECT_COLORS.length];
      const projPts = (profile.project_timeline && profile.project_timeline[projKey]) || [];
      const ptMap = new Map(projPts.map((p) => [p.date, p.commits]));
      let data = dateLabels.map((d) => ptMap.get(d) || 0);

      // Fallback if data is all 0 but project has commits
      const projContrib = (profile.project_contributions || []).find((c) => c.project_key === projKey);
      const projTotalCommits = projContrib ? projContrib.commits : 0;
      if (projTotalCommits > 0 && data.reduce((a, b) => a + b, 0) === 0) {
        const perDay = Math.max(1, Math.floor(projTotalCommits / dateLabels.length));
        data = dateLabels.map(() => perDay);
      }

      return {
        label: `${projKey} Commits`,
        data: data,
        backgroundColor: color,
        borderRadius: 3,
        stack: "projects",
      };
    });

    if (userCommitChart) userCommitChart.destroy();
    userCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            labels: { color: "#94a3b8" },
          },
          tooltip: {
            mode: "index",
            intersect: false,
          },
        },
        scales: {
          x: {
            stacked: true,
            ticks: { color: "#94a3b8" },
            grid: { color: "rgba(51, 65, 85, 0.4)" },
          },
          y: {
            stacked: true,
            ticks: { color: "#94a3b8" },
            grid: { color: "rgba(51, 65, 85, 0.4)" },
            beginAtZero: true,
          },
        },
      },
    });
  };

  // Add view toggle buttons if user has multiple projects
  if (isMultiProject) {
    const btnByProject = document.createElement("button");
    btnByProject.className = "btn btn-chip active";
    btnByProject.textContent = "By Project";

    const btnAll = document.createElement("button");
    btnAll.className = "btn btn-chip";
    btnAll.textContent = "All Activity";

    btnByProject.addEventListener("click", () => {
      btnByProject.classList.add("active");
      btnAll.classList.remove("active");
      renderMultiProjectTimeline();
    });

    btnAll.addEventListener("click", () => {
      btnAll.classList.add("active");
      btnByProject.classList.remove("active");
      renderGeneralTimeline();
    });

    controls.appendChild(btnByProject);
    controls.appendChild(btnAll);

    // Initial render: multi-project comparison
    renderMultiProjectTimeline();
  } else {
    // Single project render
    renderGeneralTimeline();
  }
}

function renderUserContributionsTable(profile) {
  const tbody = document.getElementById("userProjectsTableBody");
  tbody.innerHTML = "";

  const contribs = profile.project_contributions || [];
  if (contribs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-center" style="color:#94a3b8;">No repository contributions found.</td></tr>`;
    return;
  }

  const totalCommits = profile.total_commits || 1;

  contribs.forEach((c) => {
    const share = ((c.commits / totalCommits) * 100).toFixed(1);
    const row = document.createElement("tr");
    row.innerHTML = `
      <td><strong>${escapeHtml(c.project_key)}</strong> <span style="color:#64748b; font-size:0.8em;">(${escapeHtml(c.project_name)})</span></td>
      <td>${escapeHtml(c.repo_name)} <span style="color:#64748b; font-size:0.8em;">(${escapeHtml(c.repo_slug)})</span></td>
      <td class="text-right"><strong style="color:#38bdf8;">${Number(c.commits).toLocaleString()}</strong></td>
      <td class="text-right">${share}%</td>
      <td class="text-right"><strong style="color:#a855f7;">${Number(c.pull_requests).toLocaleString()}</strong></td>
    `;
    tbody.appendChild(row);
  });
}

// Project Profile & Multi-Repository Commit Graph Handler
async function openProjectProfile(projectKey) {
  const month = document.getElementById("monthPicker").value;
  const projectModal = document.getElementById("projectModal");
  if (!projectModal) return;

  // Close search modal if open
  document.getElementById("searchModal").classList.add("hidden");

  // Reset fields
  document.getElementById("projectModalTitle").textContent = "Loading...";
  document.getElementById("projectModalKey").textContent = projectKey;
  document.getElementById("projectKpiCommits").textContent = "...";
  document.getElementById("projectKpiPRs").textContent = "...";
  document.getElementById("projectKpiRepos").textContent = "...";
  document.getElementById("projectKpiContributors").textContent = "...";
  document.getElementById("projectReposTableBody").innerHTML = `<tr><td colspan="6" class="text-center">Loading repositories...</td></tr>`;

  projectModal.classList.remove("hidden");

  try {
    const resp = await fetch(`/api/reports/projects/${encodeURIComponent(projectKey)}?month=${month}`);
    if (!resp.ok) {
      throw new Error(`Project data not found for ${projectKey} (HTTP ${resp.status})`);
    }
    const data = await resp.json();
    renderProjectProfileData(data.project);
  } catch (err) {
    console.error("Error loading project profile:", err);
    document.getElementById("projectModalTitle").textContent = "Error";
    document.getElementById("projectReposTableBody").innerHTML = `<tr><td colspan="6" class="text-center" style="color:#ef4444;">${escapeHtml(err.message)}</td></tr>`;
  }
}

function renderProjectProfileData(project) {
  document.getElementById("projectModalTitle").textContent = project.project_name || project.project_key;
  document.getElementById("projectModalKey").textContent = `📁 ${project.project_key}`;
  document.getElementById("projectKpiCommits").textContent = Number(project.total_commits).toLocaleString();
  document.getElementById("projectKpiPRs").textContent = Number(project.total_pull_requests).toLocaleString();
  document.getElementById("projectKpiRepos").textContent = Number(project.total_repositories).toLocaleString();
  document.getElementById("projectKpiContributors").textContent = Number(project.total_active_users).toLocaleString();

  const repos = project.repo_contributions || [];
  const reposBadge = document.getElementById("projectReposBadge");
  if (repos.length > 1) {
    reposBadge.className = "badge badge-multi";
    reposBadge.textContent = `${repos.length} Repositories`;
  } else {
    reposBadge.className = "badge";
    reposBadge.textContent = `${repos.length} Repository`;
  }

  // Render Project Commit Chart
  renderProjectCommitChart(project);

  // Render Project Repos Table
  renderProjectReposTable(project);
}

function renderProjectCommitChart(project) {
  const canvas = document.getElementById("projectCommitChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  if (projectCommitChart) {
    projectCommitChart.destroy();
    projectCommitChart = null;
  }

  const controls = document.getElementById("projectChartControls");
  controls.innerHTML = "";

  const repos = project.repo_contributions || [];
  const isMultiRepo = repos.length > 1;
  const subtitle = document.getElementById("projectChartSubtitle");

  // Determine chart dates
  let dateLabels = [];
  if (activeReport && activeReport.timeline && activeReport.timeline.length > 0) {
    dateLabels = activeReport.timeline.map((t) => t.date);
  } else if (project.timeline && project.timeline.length > 0) {
    dateLabels = project.timeline.map((t) => t.date);
  } else {
    const monthVal = document.getElementById("monthPicker").value || "2026-09";
    dateLabels = Array.from({ length: 28 }, (_, i) => `${monthVal}-${String(i + 1).padStart(2, "0")}`);
  }

  // General activity timeline
  const renderGeneralTimeline = () => {
    subtitle.textContent = "Daily commits and pull requests";
    const commitMap = new Map((project.timeline || []).map((t) => [t.date, t.commits]));
    const prMap = new Map((project.timeline || []).map((t) => [t.date, t.pull_requests]));

    let commitData = dateLabels.map((d) => commitMap.get(d) || 0);
    let prData = dateLabels.map((d) => prMap.get(d) || 0);

    // Fallback distribute if total > 0 but timeline is empty
    if (commitData.reduce((a, b) => a + b, 0) === 0 && project.total_commits > 0) {
      const avg = Math.max(1, Math.floor(project.total_commits / dateLabels.length));
      commitData = dateLabels.map(() => avg);
    }
    if (prData.reduce((a, b) => a + b, 0) === 0 && project.total_pull_requests > 0) {
      const avg = Math.max(1, Math.floor(project.total_pull_requests / dateLabels.length));
      prData = dateLabels.map(() => avg);
    }

    if (projectCommitChart) projectCommitChart.destroy();

    projectCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: [
          {
            label: "Commits",
            data: commitData,
            backgroundColor: "#38bdf8",
            borderRadius: 3,
          },
          {
            label: "Pull Requests",
            data: prData,
            backgroundColor: "#a855f7",
            borderRadius: 3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#94a3b8" } },
          tooltip: { mode: "index", intersect: false },
        },
        scales: {
          x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } },
          y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" }, beginAtZero: true },
        },
      },
    });
  };

  // Multi-repository stacked comparison timeline
  const renderMultiRepoTimeline = () => {
    subtitle.textContent = "Commit comparison across repositories (Stacked)";
    const repoTimeline = project.repo_timeline || {};

    const datasets = repos.map((r, idx) => {
      const color = PROJECT_COLORS[idx % PROJECT_COLORS.length];
      const rTl = repoTimeline[r.repo_slug] || [];
      const cMap = new Map(rTl.map((t) => [t.date, t.commits]));
      let cData = dateLabels.map((d) => cMap.get(d) || 0);

      if (cData.reduce((a, b) => a + b, 0) === 0 && r.commits > 0) {
        const avg = Math.max(1, Math.floor(r.commits / dateLabels.length));
        cData = dateLabels.map(() => avg);
      }

      return {
        label: `${r.repo_name} (${r.repo_slug})`,
        data: cData,
        backgroundColor: color,
        borderRadius: 3,
        stack: "repos",
      };
    });

    if (projectCommitChart) projectCommitChart.destroy();

    projectCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#94a3b8" } },
          tooltip: { mode: "index", intersect: false },
        },
        scales: {
          x: { stacked: true, ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } },
          y: { stacked: true, ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" }, beginAtZero: true },
        },
      },
    });
  };

  if (isMultiRepo) {
    const btnByRepo = document.createElement("button");
    btnByRepo.className = "btn btn-chip active";
    btnByRepo.textContent = "By Repository";

    const btnAll = document.createElement("button");
    btnAll.className = "btn btn-chip";
    btnAll.textContent = "All Activity";

    btnByRepo.addEventListener("click", () => {
      btnByRepo.classList.add("active");
      btnAll.classList.remove("active");
      renderMultiRepoTimeline();
    });

    btnAll.addEventListener("click", () => {
      btnAll.classList.add("active");
      btnByRepo.classList.remove("active");
      renderGeneralTimeline();
    });

    controls.appendChild(btnByRepo);
    controls.appendChild(btnAll);

    renderMultiRepoTimeline();
  } else {
    renderGeneralTimeline();
  }
}

function renderProjectReposTable(project) {
  const tbody = document.getElementById("projectReposTableBody");
  tbody.innerHTML = "";

  const repos = project.repo_contributions || [];
  if (repos.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center" style="color:#94a3b8;">No repositories found in project.</td></tr>`;
    return;
  }

  const totalCommits = project.total_commits || 1;

  repos.forEach((r) => {
    const share = ((r.commits / totalCommits) * 100).toFixed(1);
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>
        <a class="repo-link" href="javascript:void(0)" onclick="openRepoProfile('${escapeHtml(project.project_key)}', '${escapeHtml(r.repo_slug)}')">
          <strong>${escapeHtml(r.repo_name)}</strong>
        </a>
        <span style="color:#64748b; font-size:0.8em;">(${escapeHtml(r.repo_slug)})</span>
      </td>
      <td class="text-right"><strong style="color:#38bdf8;">${Number(r.commits).toLocaleString()}</strong></td>
      <td class="text-right">${share}%</td>
      <td class="text-right"><strong style="color:#a855f7;">${Number(r.pull_requests).toLocaleString()}</strong></td>
      <td class="text-right">${Number(r.users ? r.users.length : (r.unique_commit_authors || 0)).toLocaleString()}</td>
      <td class="text-right">
        <button class="btn-view-repo-graph" onclick="openRepoProfile('${escapeHtml(project.project_key)}', '${escapeHtml(r.repo_slug)}')">
          📈 View Repo Graph
        </button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

// Repository Profile & Commit Graph Handler
async function openRepoProfile(projectKey, repoSlug) {
  const month = document.getElementById("monthPicker").value;
  const repoModal = document.getElementById("repoModal");
  if (!repoModal) return;

  // Close search and project modals if open
  document.getElementById("searchModal").classList.add("hidden");
  document.getElementById("projectModal").classList.add("hidden");

  // Reset fields
  document.getElementById("repoModalTitle").textContent = "Loading...";
  document.getElementById("repoModalSlug").textContent = `${projectKey} / ${repoSlug}`;
  document.getElementById("repoKpiCommits").textContent = "...";
  document.getElementById("repoKpiPRs").textContent = "...";
  document.getElementById("repoKpiCommitAuthors").textContent = "...";
  document.getElementById("repoKpiContributors").textContent = "...";
  document.getElementById("repoContributorsTableBody").innerHTML = `<tr><td colspan="6" class="text-center">Loading contributors...</td></tr>`;

  repoModal.classList.remove("hidden");

  try {
    const url = projectKey
      ? `/api/reports/repositories/${encodeURIComponent(projectKey)}/${encodeURIComponent(repoSlug)}?month=${month}`
      : `/api/reports/repositories/${encodeURIComponent(repoSlug)}?month=${month}`;

    const resp = await fetch(url);
    if (!resp.ok) {
      throw new Error(`Repository data not found for ${repoSlug} (HTTP ${resp.status})`);
    }
    const data = await resp.json();
    renderRepoProfileData(data.repository);
  } catch (err) {
    console.error("Error loading repo profile:", err);
    document.getElementById("repoModalTitle").textContent = "Error";
    document.getElementById("repoContributorsTableBody").innerHTML = `<tr><td colspan="6" class="text-center" style="color:#ef4444;">${escapeHtml(err.message)}</td></tr>`;
  }
}

function renderRepoProfileData(repo) {
  document.getElementById("repoModalTitle").textContent = repo.repo_name || repo.repo_slug;
  document.getElementById("repoModalSlug").textContent = `📦 ${repo.project_key} / ${repo.repo_slug}`;
  document.getElementById("repoKpiCommits").textContent = Number(repo.total_commits).toLocaleString();
  document.getElementById("repoKpiPRs").textContent = Number(repo.total_pull_requests).toLocaleString();
  document.getElementById("repoKpiCommitAuthors").textContent = Number(repo.unique_commit_authors).toLocaleString();
  document.getElementById("repoKpiContributors").textContent = Number(repo.total_active_users).toLocaleString();

  const contributors = repo.users || [];
  const badge = document.getElementById("repoContributorsBadge");
  badge.textContent = `${contributors.length} Contributor(s)`;

  // Render Repo Commit Chart
  renderRepoCommitChart(repo);

  // Render Contributors Table
  renderRepoContributorsTable(repo);
}

function renderRepoCommitChart(repo) {
  const canvas = document.getElementById("repoCommitChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  if (repoCommitChart) {
    repoCommitChart.destroy();
    repoCommitChart = null;
  }

  const controls = document.getElementById("repoChartControls");
  controls.innerHTML = "";

  const contributors = repo.users || [];
  const isMultiContrib = contributors.length > 1;
  const subtitle = document.getElementById("repoChartSubtitle");

  let dateLabels = [];
  if (activeReport && activeReport.timeline && activeReport.timeline.length > 0) {
    dateLabels = activeReport.timeline.map((t) => t.date);
  } else if (repo.timeline && repo.timeline.length > 0) {
    dateLabels = repo.timeline.map((t) => t.date);
  } else {
    const monthVal = document.getElementById("monthPicker").value || "2026-09";
    dateLabels = Array.from({ length: 28 }, (_, i) => `${monthVal}-${String(i + 1).padStart(2, "0")}`);
  }

  // General activity timeline
  const renderGeneralTimeline = () => {
    subtitle.textContent = "Daily commits and pull requests";
    const commitMap = new Map((repo.timeline || []).map((t) => [t.date, t.commits]));
    const prMap = new Map((repo.timeline || []).map((t) => [t.date, t.pull_requests]));

    let commitData = dateLabels.map((d) => commitMap.get(d) || 0);
    let prData = dateLabels.map((d) => prMap.get(d) || 0);

    if (commitData.reduce((a, b) => a + b, 0) === 0 && repo.total_commits > 0) {
      const avg = Math.max(1, Math.floor(repo.total_commits / dateLabels.length));
      commitData = dateLabels.map(() => avg);
    }
    if (prData.reduce((a, b) => a + b, 0) === 0 && repo.total_pull_requests > 0) {
      const avg = Math.max(1, Math.floor(repo.total_pull_requests / dateLabels.length));
      prData = dateLabels.map(() => avg);
    }

    if (repoCommitChart) repoCommitChart.destroy();

    repoCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: [
          {
            label: "Commits",
            data: commitData,
            backgroundColor: "#38bdf8",
            borderRadius: 3,
          },
          {
            label: "Pull Requests",
            data: prData,
            backgroundColor: "#a855f7",
            borderRadius: 3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#94a3b8" } },
          tooltip: { mode: "index", intersect: false },
        },
        scales: {
          x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } },
          y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" }, beginAtZero: true },
        },
      },
    });
  };

  // Multi-contributor stacked timeline
  const renderMultiContribTimeline = () => {
    subtitle.textContent = "Commit comparison across contributors (Stacked)";
    const userTimeline = repo.user_timeline || {};

    const datasets = contributors.slice(0, 8).map((u, idx) => {
      const color = PROJECT_COLORS[idx % PROJECT_COLORS.length];
      const uTl = userTimeline[u.user_id] || [];
      const cMap = new Map(uTl.map((t) => [t.date, t.commits]));
      let cData = dateLabels.map((d) => cMap.get(d) || 0);

      if (cData.reduce((a, b) => a + b, 0) === 0 && u.commits > 0) {
        const avg = Math.max(1, Math.floor(u.commits / dateLabels.length));
        cData = dateLabels.map(() => avg);
      }

      return {
        label: u.display_name || u.user_id,
        data: cData,
        backgroundColor: color,
        borderRadius: 3,
        stack: "users",
      };
    });

    if (repoCommitChart) repoCommitChart.destroy();

    repoCommitChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: dateLabels,
        datasets: datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#94a3b8" } },
          tooltip: { mode: "index", intersect: false },
        },
        scales: {
          x: { stacked: true, ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" } },
          y: { stacked: true, ticks: { color: "#94a3b8" }, grid: { color: "rgba(51, 65, 85, 0.4)" }, beginAtZero: true },
        },
      },
    });
  };

  if (isMultiContrib) {
    const btnByContrib = document.createElement("button");
    btnByContrib.className = "btn btn-chip active";
    btnByContrib.textContent = "By Contributor";

    const btnAll = document.createElement("button");
    btnAll.className = "btn btn-chip";
    btnAll.textContent = "All Activity";

    btnByContrib.addEventListener("click", () => {
      btnByContrib.classList.add("active");
      btnAll.classList.remove("active");
      renderMultiContribTimeline();
    });

    btnAll.addEventListener("click", () => {
      btnAll.classList.add("active");
      btnByContrib.classList.remove("active");
      renderGeneralTimeline();
    });

    controls.appendChild(btnByContrib);
    controls.appendChild(btnAll);

    renderMultiContribTimeline();
  } else {
    renderGeneralTimeline();
  }
}

function renderRepoContributorsTable(repo) {
  const tbody = document.getElementById("repoContributorsTableBody");
  tbody.innerHTML = "";

  const contributors = repo.users || [];
  if (contributors.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center" style="color:#94a3b8;">No contributor events found.</td></tr>`;
    return;
  }

  const totalCommits = repo.total_commits || 1;

  contributors.forEach((u) => {
    const share = ((u.commits / totalCommits) * 100).toFixed(1);
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>
        <a class="user-link" href="javascript:void(0)" onclick="openUserProfile('${escapeHtml(u.user_id)}')">
          <strong>${escapeHtml(u.display_name)}</strong>
        </a>
      </td>
      <td><code>${escapeHtml(u.user_id)}</code></td>
      <td class="text-right"><strong style="color:#38bdf8;">${Number(u.commits).toLocaleString()}</strong></td>
      <td class="text-right">${share}%</td>
      <td class="text-right"><strong style="color:#a855f7;">${Number(u.pull_requests).toLocaleString()}</strong></td>
      <td class="text-right">
        <button class="btn-view-graph" onclick="openUserProfile('${escapeHtml(u.user_id)}')">
          📈 View User Graph
        </button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

