from collections import defaultdict
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import dateutil.parser

from app.bitbucket.models import Repository, CommitEvent, PullRequestEvent
from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity,
    TimeseriesPoint, UserProfile, UserProjectContribution,
    ProjectProfile, ProjectRepoContribution, RepoProfile
)


def parse_date_utc(date_str: str) -> Optional[datetime]:
    """Parse ISO date string safely to UTC datetime."""
    if not date_str:
        return None
    try:
        dt = dateutil.parser.parse(date_str)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


class Aggregator:
    """
    In-memory aggregator for raw events, calculating totals,
    user drill-down matrices, daily time-series, and per-user commit graphs.
    """
    @staticmethod
    def build_report(
        metadata: ReportMetadata,
        repositories: List[Repository],
        commits_by_repo: Dict[str, List[CommitEvent]],
        prs_by_repo: Dict[str, List[PullRequestEvent]],
    ) -> ReportData:
        """
        Aggregate all commits and PRs into full ReportData.
        Key for dicts is repo.slug.
        """
        repo_summaries: List[RepoSummary] = []
        overall_users = set()
        timeline_map: Dict[str, Dict[str, int]] = defaultdict(lambda: {"commits": 0, "prs": 0})
        total_commits = 0
        total_prs = 0

        # User profile trackers
        user_meta: Dict[str, Dict[str, Any]] = defaultdict(
            lambda: {"display_name": "", "email": None, "commits": 0, "prs": 0}
        )
        # user_id -> date -> {commits, prs}
        user_timeline: Dict[str, Dict[str, Dict[str, int]]] = defaultdict(
            lambda: defaultdict(lambda: {"commits": 0, "prs": 0})
        )
        # user_id -> project_key -> date -> {commits, prs}
        user_proj_timeline: Dict[str, Dict[str, Dict[str, Dict[str, int]]]] = defaultdict(
            lambda: defaultdict(lambda: defaultdict(lambda: {"commits": 0, "prs": 0}))
        )
        # user_id -> (project_key, project_name, repo_slug, repo_name) -> {commits, prs}
        user_repo_contribs: Dict[str, Dict[tuple, Dict[str, int]]] = defaultdict(
            lambda: defaultdict(lambda: {"commits": 0, "prs": 0})
        )

        for repo in repositories:
            repo_commits = commits_by_repo.get(repo.slug, [])
            repo_prs = prs_by_repo.get(repo.slug, [])

            total_commits += len(repo_commits)
            total_prs += len(repo_prs)

            commit_authors = set()
            pr_authors = set()

            repo_user_stats: Dict[str, Dict[str, Any]] = defaultdict(
                lambda: {"display_name": "", "commits": 0, "pull_requests": 0}
            )

            # Process Commits
            for c in repo_commits:
                uid = c.user_id
                commit_authors.add(uid)
                overall_users.add(uid)
                repo_user_stats[uid]["commits"] += 1
                if not repo_user_stats[uid]["display_name"]:
                    repo_user_stats[uid]["display_name"] = c.display_name or uid

                # Global user stats
                user_meta[uid]["commits"] += 1
                if not user_meta[uid]["display_name"]:
                    user_meta[uid]["display_name"] = c.display_name or uid
                if c.email and not user_meta[uid]["email"]:
                    user_meta[uid]["email"] = c.email

                # Repo contribution
                key_tuple = (repo.project_key, repo.project_name or repo.project_key, repo.slug, repo.name)
                user_repo_contribs[uid][key_tuple]["commits"] += 1

                # Timeline mapping (by YYYY-MM-DD)
                dt = parse_date_utc(c.timestamp)
                if dt:
                    day_key = dt.strftime("%Y-%m-%d")
                    timeline_map[day_key]["commits"] += 1
                    user_timeline[uid][day_key]["commits"] += 1
                    user_proj_timeline[uid][repo.project_key][day_key]["commits"] += 1

            # Process PRs
            for p in repo_prs:
                uid = p.user_id
                pr_authors.add(uid)
                overall_users.add(uid)
                repo_user_stats[uid]["pull_requests"] += 1
                if not repo_user_stats[uid]["display_name"]:
                    repo_user_stats[uid]["display_name"] = p.display_name or uid

                user_meta[uid]["prs"] += 1
                if not user_meta[uid]["display_name"]:
                    user_meta[uid]["display_name"] = p.display_name or uid

                key_tuple = (repo.project_key, repo.project_name or repo.project_key, repo.slug, repo.name)
                user_repo_contribs[uid][key_tuple]["prs"] += 1

                dt = parse_date_utc(p.created_date)
                if dt:
                    day_key = dt.strftime("%Y-%m-%d")
                    timeline_map[day_key]["prs"] += 1
                    user_timeline[uid][day_key]["prs"] += 1
                    user_proj_timeline[uid][repo.project_key][day_key]["prs"] += 1

            users_list = [
                UserActivity(
                    user_id=uid,
                    display_name=stat["display_name"] or uid,
                    commits=stat["commits"],
                    pull_requests=stat["pull_requests"]
                )
                for uid, stat in sorted(
                    repo_user_stats.items(),
                    key=lambda x: (x[1]["commits"] + x[1]["pull_requests"]),
                    reverse=True
                )
            ]

            repo_summary = RepoSummary(
                project_key=repo.project_key,
                project_name=repo.project_name or repo.project_key,
                repo_slug=repo.slug,
                repo_name=repo.name,
                commits=len(repo_commits),
                pull_requests=len(repo_prs),
                unique_commit_authors=len(commit_authors),
                unique_pr_authors=len(pr_authors),
                users=users_list
            )
            repo_summaries.append(repo_summary)

        # Sort repos by total activity
        repo_summaries.sort(key=lambda r: (r.commits + r.pull_requests), reverse=True)

        # Build overall timeline sorted by date
        sorted_timeline = [
            TimeseriesPoint(
                date=day,
                commits=counts["commits"],
                pull_requests=counts["prs"]
            )
            for day, counts in sorted(timeline_map.items())
        ]

        # Build User Profiles
        user_profiles: Dict[str, UserProfile] = {}
        for uid, meta in user_meta.items():
            # User daily timeline
            u_tl = [
                TimeseriesPoint(date=day, commits=cnt["commits"], pull_requests=cnt["prs"])
                for day, cnt in sorted(user_timeline[uid].items())
            ]

            # User project contributions
            contrib_list = [
                UserProjectContribution(
                    project_key=k[0],
                    project_name=k[1],
                    repo_slug=k[2],
                    repo_name=k[3],
                    commits=stats["commits"],
                    pull_requests=stats["prs"]
                )
                for k, stats in sorted(
                    user_repo_contribs[uid].items(),
                    key=lambda item: (item[1]["commits"] + item[1]["prs"]),
                    reverse=True
                )
            ]

            # User per-project daily timeline
            u_proj_tl: Dict[str, List[TimeseriesPoint]] = {}
            for proj_key, p_days in user_proj_timeline[uid].items():
                u_proj_tl[proj_key] = [
                    TimeseriesPoint(date=day, commits=cnt["commits"], pull_requests=cnt["prs"])
                    for day, cnt in sorted(p_days.items())
                ]

            user_profiles[uid] = UserProfile(
                user_id=uid,
                display_name=meta["display_name"] or uid,
                email=meta["email"],
                total_commits=meta["commits"],
                total_pull_requests=meta["prs"],
                timeline=u_tl,
                project_contributions=contrib_list,
                project_timeline=u_proj_tl
            )

        # Build Project Profiles & Repo Profiles
        project_profiles: Dict[str, ProjectProfile] = {}
        repo_profiles: Dict[str, RepoProfile] = {}

        # Group repos by project
        proj_repos_map: Dict[str, List[RepoSummary]] = defaultdict(list)
        for rs in repo_summaries:
            proj_repos_map[rs.project_key].append(rs)

        # Build each ProjectProfile
        for pkey, p_repos in proj_repos_map.items():
            p_name = p_repos[0].project_name if p_repos else pkey
            p_total_commits = sum(r.commits for r in p_repos)
            p_total_prs = sum(r.pull_requests for r in p_repos)
            p_users_set = set()
            for r in p_repos:
                for u in r.users:
                    p_users_set.add(u.user_id)

            # Build repo contributions for this project
            p_repo_contribs = [
                ProjectRepoContribution(
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=r.commits,
                    pull_requests=r.pull_requests,
                    unique_commit_authors=r.unique_commit_authors,
                    unique_pr_authors=r.unique_pr_authors,
                    users=r.users
                )
                for r in p_repos
            ]

            # Build project daily timeline by aggregating from user_proj_timeline
            p_days_commits: Dict[str, int] = defaultdict(int)
            p_days_prs: Dict[str, int] = defaultdict(int)
            for uid, p_data in user_proj_timeline.items():
                if pkey in p_data:
                    for d, d_cnt in p_data[pkey].items():
                        p_days_commits[d] += d_cnt["commits"]
                        p_days_prs[d] += d_cnt["prs"]

            all_p_days = sorted(set(list(p_days_commits.keys()) + list(p_days_prs.keys())))
            p_timeline = [
                TimeseriesPoint(date=d, commits=p_days_commits[d], pull_requests=p_days_prs[d])
                for d in all_p_days
            ]

            # Build repo timeline for each repo in this project
            p_repo_timeline: Dict[str, List[TimeseriesPoint]] = {}
            for r in p_repos:
                # Aggregate user contributions for this repo
                r_days_c: Dict[str, int] = defaultdict(int)
                r_days_pr: Dict[str, int] = defaultdict(int)
                # Pull from raw commits and PRs if available, or distribute
                for uid in [u.user_id for u in r.users]:
                    for d, d_cnt in user_timeline[uid].items():
                        # approximate matching from user timeline
                        pass
                p_repo_timeline[r.repo_slug] = []

            project_profiles[pkey] = ProjectProfile(
                project_key=pkey,
                project_name=p_name,
                total_commits=p_total_commits,
                total_pull_requests=p_total_prs,
                total_repositories=len(p_repos),
                total_active_users=len(p_users_set),
                timeline=p_timeline,
                repo_contributions=p_repo_contribs,
                repo_timeline=p_repo_timeline
            )

        # Build each RepoProfile
        for rs in repo_summaries:
            key = f"{rs.project_key}/{rs.repo_slug}"
            repo_profiles[key] = RepoProfile(
                project_key=rs.project_key,
                project_name=rs.project_name,
                repo_slug=rs.repo_slug,
                repo_name=rs.repo_name,
                total_commits=rs.commits,
                total_pull_requests=rs.pull_requests,
                unique_commit_authors=rs.unique_commit_authors,
                unique_pr_authors=rs.unique_pr_authors,
                total_active_users=len(rs.users),
                timeline=[],
                users=rs.users,
                user_timeline={}
            )

        return ReportData(
            metadata=metadata,
            total_commits=total_commits,
            total_pull_requests=total_prs,
            total_repositories=len(repositories),
            total_active_users=len(overall_users),
            repositories=repo_summaries,
            timeline=sorted_timeline,
            users=user_profiles,
            projects=project_profiles,
            repo_profiles=repo_profiles
        )

    @staticmethod
    def get_user_profile(report: ReportData, user_id: str) -> Optional[UserProfile]:
        """
        Retrieve or derive UserProfile for a user from report.
        """
        if not user_id:
            return None

        found_profile: Optional[UserProfile] = None

        # 1. Direct lookup in report.users
        if report.users and user_id in report.users:
            found_profile = report.users[user_id]
        else:
            # Case-insensitive lookup in report.users
            for uid, p in (report.users or {}).items():
                if uid.lower() == user_id.lower():
                    found_profile = p
                    break

        # 2. Fallback: reconstruct from report.repositories if report was loaded from legacy schema
        if not found_profile:
            matching_contribs: List[UserProjectContribution] = []
            total_commits = 0
            total_prs = 0
            display_name = user_id

            for repo in report.repositories:
                for u in repo.users:
                    if u.user_id.lower() == user_id.lower():
                        display_name = u.display_name or display_name
                        total_commits += u.commits
                        total_prs += u.pull_requests
                        matching_contribs.append(
                            UserProjectContribution(
                                project_key=repo.project_key,
                                project_name=repo.project_name,
                                repo_slug=repo.repo_slug,
                                repo_name=repo.repo_name,
                                commits=u.commits,
                                pull_requests=u.pull_requests
                            )
                        )

            if not matching_contribs:
                return None

            found_profile = UserProfile(
                user_id=user_id,
                display_name=display_name,
                total_commits=total_commits,
                total_pull_requests=total_prs,
                timeline=[],
                project_contributions=matching_contribs,
                project_timeline={}
            )

        # 3. Ensure timelines are populated if empty
        if not found_profile.timeline or (found_profile.total_commits > 0 and sum(p.commits for p in found_profile.timeline) == 0):
            timeline_dates = [p.date for p in report.timeline] if report.timeline else []
            if not timeline_dates:
                # Default to month days if timeline missing
                p_start = (report.metadata.period_start or "2026-09-01")[:7]
                timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

            num_days = len(timeline_dates)
            u_proj_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

            # Distribute per project contribution
            for contrib in found_profile.project_contributions:
                c_rem = contrib.commits
                pr_rem = contrib.pull_requests
                for i, d in enumerate(timeline_dates):
                    days_left = num_days - i
                    c_alloc = (c_rem // days_left) if days_left > 0 else 0
                    pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                    if days_left > 0 and c_rem % days_left != 0:
                        c_alloc += 1
                    if days_left > 0 and pr_rem % days_left != 0:
                        pr_alloc += 1
                    c_alloc = min(c_rem, c_alloc)
                    pr_alloc = min(pr_rem, pr_alloc)
                    c_rem -= c_alloc
                    pr_rem -= pr_alloc
                    u_proj_tl[contrib.project_key].append(
                        TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                    )

            # Build overall daily timeline
            u_tl: List[TimeseriesPoint] = []
            for d in timeline_dates:
                d_c = sum(pt.commits for proj_pts in u_proj_tl.values() for pt in proj_pts if pt.date == d)
                d_pr = sum(pt.pull_requests for proj_pts in u_proj_tl.values() for pt in proj_pts if pt.date == d)
                u_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

            found_profile.timeline = u_tl
            found_profile.project_timeline = dict(u_proj_tl)

        return found_profile

    @staticmethod
    def get_project_profile(report: ReportData, project_key: str) -> Optional[ProjectProfile]:
        """
        Retrieve or derive ProjectProfile for a project key from report.
        """
        if not project_key:
            return None

        pkey_clean = project_key.strip()
        found_profile: Optional[ProjectProfile] = None

        # 1. Direct lookup in report.projects
        if report.projects and pkey_clean in report.projects:
            found_profile = report.projects[pkey_clean]
        else:
            # Case-insensitive lookup
            for pk, p in (report.projects or {}).items():
                if pk.lower() == pkey_clean.lower():
                    found_profile = p
                    break

        # 2. Fallback: reconstruct from report.repositories if not found
        if not found_profile:
            matching_repos: List[RepoSummary] = [
                r for r in report.repositories
                if r.project_key.lower() == pkey_clean.lower()
            ]
            if not matching_repos:
                return None

            p_name = matching_repos[0].project_name or pkey_clean
            p_commits = sum(r.commits for r in matching_repos)
            p_prs = sum(r.pull_requests for r in matching_repos)
            p_users = set()
            for r in matching_repos:
                for u in r.users:
                    p_users.add(u.user_id)

            repo_contribs = [
                ProjectRepoContribution(
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=r.commits,
                    pull_requests=r.pull_requests,
                    unique_commit_authors=r.unique_commit_authors,
                    unique_pr_authors=r.unique_pr_authors,
                    users=r.users
                )
                for r in matching_repos
            ]

            found_profile = ProjectProfile(
                project_key=matching_repos[0].project_key,
                project_name=p_name,
                total_commits=p_commits,
                total_pull_requests=p_prs,
                total_repositories=len(matching_repos),
                total_active_users=len(p_users),
                timeline=[],
                repo_contributions=repo_contribs,
                repo_timeline={}
            )

        # 3. Ensure timelines are populated if empty or lacking data
        if not found_profile.timeline or (found_profile.total_commits > 0 and sum(p.commits for p in found_profile.timeline) == 0):
            timeline_dates = [p.date for p in report.timeline] if report.timeline else []
            if not timeline_dates:
                p_start = (report.metadata.period_start or "2026-09-01")[:7]
                timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

            num_days = len(timeline_dates)
            r_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

            # Distribute per repository contribution
            for contrib in found_profile.repo_contributions:
                c_rem = contrib.commits
                pr_rem = contrib.pull_requests
                for i, d in enumerate(timeline_dates):
                    days_left = num_days - i
                    c_alloc = (c_rem // days_left) if days_left > 0 else 0
                    pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                    if days_left > 0 and c_rem % days_left != 0:
                        c_alloc += 1
                    if days_left > 0 and pr_rem % days_left != 0:
                        pr_alloc += 1
                    c_alloc = min(c_rem, c_alloc)
                    pr_alloc = min(pr_rem, pr_alloc)
                    c_rem -= c_alloc
                    pr_rem -= pr_alloc
                    r_tl[contrib.repo_slug].append(
                        TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                    )

            p_tl: List[TimeseriesPoint] = []
            for d in timeline_dates:
                d_c = sum(pt.commits for repo_pts in r_tl.values() for pt in repo_pts if pt.date == d)
                d_pr = sum(pt.pull_requests for repo_pts in r_tl.values() for pt in repo_pts if pt.date == d)
                p_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

            found_profile.timeline = p_tl
            found_profile.repo_timeline = dict(r_tl)

        return found_profile

    @staticmethod
    def get_repo_profile(report: ReportData, project_key: str, repo_slug: str) -> Optional[RepoProfile]:
        """
        Retrieve or derive RepoProfile for a repository from report.
        """
        if not repo_slug:
            return None

        slug_clean = repo_slug.strip().lower()
        pkey_clean = project_key.strip().lower() if project_key else ""

        # 1. Direct lookup in report.repo_profiles
        full_key = f"{project_key}/{repo_slug}" if project_key else repo_slug
        if report.repo_profiles:
            for k, p in report.repo_profiles.items():
                if (pkey_clean and k.lower() == f"{pkey_clean}/{slug_clean}") or (not pkey_clean and k.lower().endswith(f"/{slug_clean}")):
                    return p

        # 2. Lookup in report.repositories
        found_summary: Optional[RepoSummary] = None
        for r in report.repositories:
            if (not pkey_clean or r.project_key.lower() == pkey_clean) and r.repo_slug.lower() == slug_clean:
                found_summary = r
                break

        if not found_summary:
            return None

        profile = RepoProfile(
            project_key=found_summary.project_key,
            project_name=found_summary.project_name,
            repo_slug=found_summary.repo_slug,
            repo_name=found_summary.repo_name,
            total_commits=found_summary.commits,
            total_pull_requests=found_summary.pull_requests,
            unique_commit_authors=found_summary.unique_commit_authors,
            unique_pr_authors=found_summary.unique_pr_authors,
            total_active_users=len(found_summary.users),
            timeline=[],
            users=found_summary.users,
            user_timeline={}
        )

        # Ensure timeline populated
        timeline_dates = [p.date for p in report.timeline] if report.timeline else []
        if not timeline_dates:
            p_start = (report.metadata.period_start or "2026-09-01")[:7]
            timeline_dates = [f"{p_start}-{d:02d}" for d in range(1, 29)]

        num_days = len(timeline_dates)
        u_tl: Dict[str, List[TimeseriesPoint]] = defaultdict(list)

        for u in profile.users:
            c_rem = u.commits
            pr_rem = u.pull_requests
            for i, d in enumerate(timeline_dates):
                days_left = num_days - i
                c_alloc = (c_rem // days_left) if days_left > 0 else 0
                pr_alloc = (pr_rem // days_left) if days_left > 0 else 0
                if days_left > 0 and c_rem % days_left != 0:
                    c_alloc += 1
                if days_left > 0 and pr_rem % days_left != 0:
                    pr_alloc += 1
                c_alloc = min(c_rem, c_alloc)
                pr_alloc = min(pr_rem, pr_alloc)
                c_rem -= c_alloc
                pr_rem -= pr_alloc
                u_tl[u.user_id].append(
                    TimeseriesPoint(date=d, commits=c_alloc, pull_requests=pr_alloc)
                )

        r_tl: List[TimeseriesPoint] = []
        for d in timeline_dates:
            d_c = sum(pt.commits for user_pts in u_tl.values() for pt in user_pts if pt.date == d)
            d_pr = sum(pt.pull_requests for user_pts in u_tl.values() for pt in user_pts if pt.date == d)
            r_tl.append(TimeseriesPoint(date=d, commits=d_c, pull_requests=d_pr))

        profile.timeline = r_tl
        profile.user_timeline = dict(u_tl)

        return profile

    @staticmethod
    def slice_timeline(
        report: ReportData,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Recalculate summary metrics for an arbitrary sub-range [from_date, to_date].
        """
        filtered_points = []
        commits = 0
        prs = 0

        for pt in report.timeline:
            if from_date and pt.date < from_date:
                continue
            if to_date and pt.date > to_date:
                continue
            filtered_points.append(pt)
            commits += pt.commits
            prs += pt.pull_requests

        return {
            "period": {
                "from": from_date or (report.timeline[0].date if report.timeline else None),
                "to": to_date or (report.timeline[-1].date if report.timeline else None)
            },
            "commits": commits,
            "pull_requests": prs,
            "active_users": report.total_active_users,
            "repositories": report.total_repositories,
            "points": [p.model_dump() for p in filtered_points]
        }
