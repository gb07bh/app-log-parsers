import csv
import io
import json
from app.reporting.models import ReportData, ReportMetadata


class Exporter:
    """Exports ReportData and ReportMetadata to JSON and CSV."""

    @staticmethod
    def to_json(report: ReportData, indent: int = 2) -> str:
        """Serialize ReportData to formatted JSON string."""
        return report.model_dump_json(indent=indent)

    @staticmethod
    def metadata_to_json(metadata: ReportMetadata, indent: int = 2) -> str:
        """Serialize ReportMetadata to formatted JSON string."""
        return metadata.model_dump_json(indent=indent)

    @staticmethod
    def to_csv(report: ReportData) -> str:
        """
        Generate CSV with repository-level and user drill-down metrics.
        """
        output = io.StringIO()
        writer = csv.writer(output)

        # Header
        writer.writerow([
            "Project Key",
            "Project Name",
            "Repository Slug",
            "Repository Name",
            "Total Repo Commits",
            "Total Repo PRs",
            "Unique Commit Authors",
            "Unique PR Authors",
            "User ID",
            "User Display Name",
            "User Commits",
            "User Pull Requests"
        ])

        for repo in report.repositories:
            if not repo.users:
                # Repo with no individual user events
                writer.writerow([
                    repo.project_key,
                    repo.project_name,
                    repo.repo_slug,
                    repo.repo_name,
                    repo.commits,
                    repo.pull_requests,
                    repo.unique_commit_authors,
                    repo.unique_pr_authors,
                    "",
                    "",
                    0,
                    0
                ])
            else:
                for user in repo.users:
                    writer.writerow([
                        repo.project_key,
                        repo.project_name,
                        repo.repo_slug,
                        repo.repo_name,
                        repo.commits,
                        repo.pull_requests,
                        repo.unique_commit_authors,
                        repo.unique_pr_authors,
                        user.user_id,
                        user.display_name,
                        user.commits,
                        user.pull_requests
                    ])

        return output.getvalue()
