from typing import List, Dict, Any
from app.reporting.models import ReportData


class SearchService:
    """
    In-memory search engine across projects, repositories, and user IDs
    within loaded ReportData.
    """

    @staticmethod
    def search(report: ReportData, query: str) -> List[Dict[str, Any]]:
        if not query or not query.strip():
            return []

        q = query.strip().lower()
        results: List[Dict[str, Any]] = []

        # 1. Search Projects
        matched_projects: Dict[str, Dict[str, Any]] = {}
        # 2. Search Repositories
        matched_repos: List[Dict[str, Any]] = []

        for repo in report.repositories:
            # Check project match
            if q in repo.project_key.lower() or q in repo.project_name.lower():
                if repo.project_key not in matched_projects:
                    matched_projects[repo.project_key] = {
                        "type": "project",
                        "title": f"📁 Project: {repo.project_key} - {repo.project_name}",
                        "project_key": repo.project_key,
                        "project_name": repo.project_name,
                        "commits": 0,
                        "pull_requests": 0,
                        "repositories": [],
                        "active_users": set(),
                    }
                matched_projects[repo.project_key]["commits"] += repo.commits
                matched_projects[repo.project_key]["pull_requests"] += repo.pull_requests
                matched_projects[repo.project_key]["repositories"].append(repo.repo_slug)
                for u in repo.users:
                    matched_projects[repo.project_key]["active_users"].add(u.user_id)

            # Check repo match
            if q in repo.repo_slug.lower() or q in repo.repo_name.lower():
                matched_repos.append({
                    "type": "repository",
                    "title": f"📦 {repo.project_key} / {repo.repo_name}",
                    "project_key": repo.project_key,
                    "repository_slug": repo.repo_slug,
                    "repository_name": repo.repo_name,
                    "commits": repo.commits,
                    "pull_requests": repo.pull_requests,
                    "active_users": len(repo.users)
                })

        # Add project results
        for p in matched_projects.values():
            results.append({
                "type": "project",
                "title": p["title"],
                "project_key": p["project_key"],
                "project_name": p["project_name"],
                "commits": p["commits"],
                "pull_requests": p["pull_requests"],
                "repositories_count": len(p["repositories"]),
                "repo_slugs": p["repositories"],
                "has_multiple_repos": len(p["repositories"]) > 1,
                "active_users": len(p["active_users"])
            })

        # Add repository results
        results.extend(matched_repos)

        # 2. Search Users
        user_matches: Dict[str, Dict[str, Any]] = {}
        for repo in report.repositories:
            for user in repo.users:
                if q in user.user_id.lower() or q in user.display_name.lower():
                    if user.user_id not in user_matches:
                        user_matches[user.user_id] = {
                            "type": "user",
                            "title": f"{user.display_name} ({user.user_id})",
                            "user_id": user.user_id,
                            "display_name": user.display_name,
                            "commits": 0,
                            "pull_requests": 0,
                            "repositories": set(),
                            "projects": set()
                        }
                    user_matches[user.user_id]["commits"] += user.commits
                    user_matches[user.user_id]["pull_requests"] += user.pull_requests
                    user_matches[user.user_id]["repositories"].add(f"{repo.project_key}/{repo.repo_slug}")
                    user_matches[user.user_id]["projects"].add(repo.project_key)

        for u in user_matches.values():
            proj_list = sorted(list(u["projects"]))
            results.append({
                "type": "user",
                "title": u["title"],
                "user_id": u["user_id"],
                "display_name": u["display_name"],
                "commits": u["commits"],
                "pull_requests": u["pull_requests"],
                "projects_count": len(proj_list),
                "project_keys": proj_list,
                "has_multiple_projects": len(proj_list) > 1,
                "repositories": len(u["repositories"]),
                "repo_list": sorted(list(u["repositories"]))
            })

        return results
