import logging
from typing import Optional
from app.config.schema import AppConfig
from app.reporting.models import ReportData
from app.storage.file_store import FileStore
from app.storage.artifactory import ArtifactoryClient

logger = logging.getLogger("storage.resolver")


class ReportResolver:
    """
    Smart resolver:
      1. Checks local cache (FileStore).
      2. If missing locally, attempts to pull from Artifactory.
      3. Never executes a runner (presentation / retrieval only).
    """

    def __init__(self, config: AppConfig):
        self.config = config
        self.file_store = FileStore(base_path=config.report.storage_path)
        self.artifactory = ArtifactoryClient(config.artifactory)

    def resolve_report_for_month(self, year_month: str, force_pull: bool = False) -> Optional[ReportData]:
        """
        Get report for year_month (e.g. '2026-09').
        If force_pull is True, checks Artifactory even if local copy exists.
        """
        logger.info(f"Resolving report for month '{year_month}' (force_pull={force_pull})")

        # 1. Check local store if not forcing pull
        if not force_pull:
            local_report = self.file_store.get_latest_report_for_month(year_month)
            if local_report:
                logger.info(f"Found report for '{year_month}' in local cache ({local_report.metadata.job_id})")
                return local_report

        # 2. Pull from Artifactory if enabled
        if self.config.artifactory.enabled:
            logger.info(f"Checking Artifactory for '{year_month}' report...")
            remote_report = self.artifactory.download_report(year_month, job_id="latest")
            if remote_report:
                logger.info(f"Downloaded report for '{year_month}' from Artifactory. Saving to local cache...")
                self.file_store.save_report(remote_report)
                return remote_report

        logger.info(f"Report for month '{year_month}' not found in local cache or Artifactory.")
        return None
