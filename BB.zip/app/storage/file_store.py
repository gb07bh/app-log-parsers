import os
import json
import logging
from typing import Optional, List, Dict, Any
from app.reporting.models import ReportData, ReportMetadata
from app.reporting.exporter import Exporter

logger = logging.getLogger("storage.file_store")


class FileStore:
    """
    Local filesystem persistence for report snapshots.
    Storage layout:
      {storage_path}/
        └── YYYY/
            └── MM/
                ├── {job_id}/
                │   ├── report.json
                │   ├── report.csv
                │   └── metadata.json
                └── latest/ (copy of latest run for that month)
    """

    def __init__(self, base_path: str = "./data/reports"):
        self.base_path = base_path
        os.makedirs(self.base_path, exist_ok=True)

    def _get_month_dir(self, year_month: str) -> str:
        # year_month e.g. "2026-09"
        parts = year_month.split("-")
        if len(parts) >= 2:
            return os.path.join(self.base_path, parts[0], parts[1])
        return os.path.join(self.base_path, year_month)

    def save_report(self, report: ReportData) -> str:
        """
        Save report.json, report.csv, and metadata.json to local filesystem.
        Returns the directory path where report was saved.
        """
        meta = report.metadata
        period_start = meta.period_start or "2026-09-01"
        year_month = period_start[:7]  # YYYY-MM
        month_dir = self._get_month_dir(year_month)
        job_dir = os.path.join(month_dir, meta.job_id)
        latest_dir = os.path.join(month_dir, "latest")

        for d in [job_dir, latest_dir]:
            os.makedirs(d, exist_ok=True)

        json_content = Exporter.to_json(report)
        csv_content = Exporter.to_csv(report)
        meta_content = Exporter.metadata_to_json(meta)

        # Write to run directory
        for folder in [job_dir, latest_dir]:
            with open(os.path.join(folder, "report.json"), "w", encoding="utf-8") as f:
                f.write(json_content)
            with open(os.path.join(folder, "report.csv"), "w", encoding="utf-8") as f:
                f.write(csv_content)
            with open(os.path.join(folder, "metadata.json"), "w", encoding="utf-8") as f:
                f.write(meta_content)

        logger.info(f"Report saved locally to {job_dir} and updated {latest_dir}")
        return job_dir

    def get_latest_report_for_month(self, year_month: str) -> Optional[ReportData]:
        """
        Load the latest ReportData for a month (e.g. '2026-09') from local disk.
        """
        month_dir = self._get_month_dir(year_month)
        latest_json = os.path.join(month_dir, "latest", "report.json")
        if not os.path.exists(latest_json):
            return None

        try:
            with open(latest_json, "r", encoding="utf-8") as f:
                data = json.load(f)
            return ReportData(**data)
        except Exception as e:
            logger.error(f"Failed reading report from {latest_json}: {e}")
            return None

    def get_report_by_job_id(self, year_month: str, job_id: str) -> Optional[ReportData]:
        """Load specific job report."""
        month_dir = self._get_month_dir(year_month)
        target_json = os.path.join(month_dir, job_id, "report.json")
        if not os.path.exists(target_json):
            return None

        try:
            with open(target_json, "r", encoding="utf-8") as f:
                data = json.load(f)
            return ReportData(**data)
        except Exception as e:
            logger.error(f"Failed reading report from {target_json}: {e}")
            return None

    def list_local_reports(self) -> List[Dict[str, Any]]:
        """List all locally available reports across months."""
        results = []
        if not os.path.exists(self.base_path):
            return results

        for root, dirs, files in os.walk(self.base_path):
            if "metadata.json" in files:
                meta_path = os.path.join(root, "metadata.json")
                try:
                    with open(meta_path, "r", encoding="utf-8") as f:
                        meta = json.load(f)
                    results.append({
                        "path": root,
                        "job_id": meta.get("job_id"),
                        "generated_at": meta.get("generated_at"),
                        "status": meta.get("status"),
                        "period_start": meta.get("period_start"),
                        "period_end": meta.get("period_end")
                    })
                except Exception:
                    continue
        return results
