import os
from datetime import datetime, timezone
from typing import Optional
from flask import Flask, render_template

from app.config.schema import AppConfig
from app.config.config_loader import load_config
from app.logging_config import configure_logging
from app.storage.resolver import ReportResolver
from app.api.routes import base_bp
from app.api.report_routes import report_bp
from app.api.search_routes import search_bp
from app.api.job_routes import job_bp


def create_app(config: Optional[AppConfig] = None) -> Flask:
    """Application factory for Flask presentation server."""
    app = Flask(
        __name__,
        template_folder=os.path.join(os.path.dirname(__file__), "templates"),
        static_folder=os.path.join(os.path.dirname(__file__), "static")
    )

    # 1. Load config
    app_config = config or load_config()
    app.config["APP_CONFIG"] = app_config

    # 2. Configure logging
    configure_logging(
        log_dir=app_config.logging.directory,
        log_level=app_config.logging.level
    )

    # 3. Instantiate report resolver (Local + Artifactory puller)
    resolver = ReportResolver(app_config)
    app.config["REPORT_RESOLVER"] = resolver

    # 4. Register API Blueprints
    app.register_blueprint(base_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(job_bp)

    # 5. UI Route
    @app.route("/", methods=["GET"])
    def index():
        current_month = datetime.now(timezone.utc).strftime("%Y-%m")
        return render_template("dashboard.html", current_month=current_month)

    return app
