import logging
import requests
from typing import List, Optional, Generator
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from app.config.schema import BitbucketConfig
from app.bitbucket.models import Project, Repository
from app.bitbucket.pagination import paginate

logger = logging.getLogger("bitbucket.dc_client")


class BitbucketDCClient:
    """
    Client for Bitbucket Data Center standard REST API (/rest/api/latest).
    Specialized in discovering Projects, Repositories, and permissions.
    """
    def __init__(self, config: BitbucketConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.api_prefix = config.dc_api_path.strip("/")
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        adapter = HTTPAdapter(max_retries=retries, pool_connections=10, pool_maxsize=10)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        if self.config.auth_type == "bearer":
            token = self.config.get_token()
            if token:
                session.headers.update({"Authorization": f"Bearer {token}"})
        else:
            username = self.config.get_username()
            password = self.config.get_password()
            if username and password:
                session.auth = (username, password)

        session.headers.update({
            "Accept": "application/json",
            "User-Agent": "Bitbucket-Activity-Report/1.0"
        })
        return session

    def list_projects(self) -> List[Project]:
        """
        List all accessible projects using GET /rest/api/latest/projects.
        If config.projects.keys is specified, filters down to those keys.
        """
        url = f"{self.base_url}/{self.api_prefix}/projects"
        logger.info(f"Querying Bitbucket DC for projects at: {url}")

        def fetch_page(start: int, limit: int):
            resp = self.session.get(url, params={"start": start, "limit": limit}, timeout=30)
            resp.raise_for_status()
            return resp.json()

        all_projects = []
        configured_keys = set(k.upper() for k in self.config.projects.keys) if self.config.projects.keys else None

        for item in paginate(fetch_page, page_limit=50):
            proj = Project(
                key=item.get("key"),
                name=item.get("name", item.get("key")),
                id=item.get("id"),
                description=item.get("description"),
                public=item.get("public", False)
            )
            if configured_keys is None or proj.key.upper() in configured_keys:
                all_projects.append(proj)

        logger.info(f"Discovered {len(all_projects)} projects matching configuration (Filter={self.config.projects.keys or 'ALL'})")
        return all_projects

    def get_project(self, project_key: str) -> Optional[Project]:
        """GET /rest/api/latest/projects/{projectKey}"""
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}"
        try:
            resp = self.session.get(url, timeout=20)
            if resp.status_code == 404:
                return None
            resp.raise_for_status()
            data = resp.json()
            return Project(
                key=data.get("key"),
                name=data.get("name", data.get("key")),
                id=data.get("id"),
                description=data.get("description"),
                public=data.get("public", False)
            )
        except Exception as e:
            logger.error(f"Failed to fetch project {project_key}: {e}")
            raise

    def list_repositories(self, project_key: str, limit: Optional[int] = None) -> List[Repository]:
        """
        List repositories for a project using GET /rest/api/latest/projects/{projectKey}/repos.
        Applies limit if specified.
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos"
        logger.info(f"Discovering repositories for project '{project_key}' at: {url}")

        def fetch_page(start: int, page_limit: int):
            resp = self.session.get(url, params={"start": start, "limit": page_limit}, timeout=30)
            resp.raise_for_status()
            return resp.json()

        repos = []
        for item in paginate(fetch_page, page_limit=50):
            repo = Repository(
                slug=item.get("slug"),
                name=item.get("name", item.get("slug")),
                id=item.get("id"),
                project_key=project_key,
                project_name=item.get("project", {}).get("name")
            )
            repos.append(repo)
            if limit and len(repos) >= limit:
                logger.info(f"Reached configured limit of {limit} repositories for project '{project_key}'")
                break

        logger.info(f"Discovered {len(repos)} repositories in project '{project_key}'")
        return repos
