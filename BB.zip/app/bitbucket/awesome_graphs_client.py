import time
import logging
import requests
from typing import List, Optional
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from app.config.schema import BitbucketConfig
from app.bitbucket.models import CommitEvent, PullRequestEvent
from app.bitbucket.pagination import paginate

logger = logging.getLogger("bitbucket.awesome_graphs")


class AwesomeGraphsClient:
    """
    Client for Stiltsoft Awesome Graphs for Bitbucket REST API
    (/rest/awesome-graphs-api/latest).
    Specialized in high-performance Commit and Pull Request activity extraction.
    """
    def __init__(self, config: BitbucketConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.api_prefix = config.awesome_graphs_api_path.strip("/")
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=1.0,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        adapter = HTTPAdapter(max_retries=retries, pool_connections=15, pool_maxsize=15)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        if self.config.auth_type == "bearer":
            token = self.config.get_token()
            if token:
                session.headers.update({"Authorization": f"Bearer {token}"})
        else:
            username = self.config.get_username()
            password = self.config.get_password()
            if username and password:
                session.auth = (username, password)

        session.headers.update({
            "Accept": "application/json",
            "User-Agent": "Bitbucket-Awesome-Graphs-Client/1.0"
        })
        return session

    def list_repo_commits(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[CommitEvent]:
        """
        Query commits for repository via:
        GET /rest/awesome-graphs-api/latest/projects/{projectKey}/repos/{repositorySlug}/commits
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos/{repo_slug}/commits"
        params = {"merges": "include", "order": "newest"}
        if since_date:
            params["sinceDate"] = since_date
        if until_date:
            params["untilDate"] = until_date

        commits = []
        start_time = time.time()

        def fetch_page(start: int, limit: int):
            page_params = {**params, "start": start, "limit": min(limit, 500)}
            req_start = time.time()
            resp = self.session.get(url, params=page_params, timeout=45)
            duration_ms = int((time.time() - req_start) * 1000)

            logger.info(
                f"AwesomeGraphs Query: GET {url} | Params: {page_params} | Status: {resp.status_code} | Latency: {duration_ms}ms"
            )
            resp.raise_for_status()
            return resp.json()

        try:
            for item in paginate(fetch_page, page_limit=100):
                author = item.get("author", {})
                user_id = author.get("name") or author.get("slug") or author.get("displayName") or "unknown"
                display_name = author.get("displayName") or user_id
                email = author.get("emailAddress")
                lines_info = item.get("linesOfCode", {})

                commit_event = CommitEvent(
                    event_id=item.get("id", ""),
                    project_key=project_key,
                    repo_slug=repo_slug,
                    user_id=user_id,
                    display_name=display_name,
                    email=email,
                    timestamp=item.get("authorTimestamp", ""),
                    lines_added=lines_info.get("added", 0),
                    lines_deleted=lines_info.get("deleted", 0)
                )
                commits.append(commit_event)

            total_ms = int((time.time() - start_time) * 1000)
            logger.info(
                f"Completed commits extraction for {project_key}/{repo_slug}: {len(commits)} commits retrieved in {total_ms}ms"
            )
            return commits
        except Exception as e:
            logger.error(f"Error extracting commits for {project_key}/{repo_slug}: {e}", exc_info=True)
            raise

    def list_repo_pull_requests(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[PullRequestEvent]:
        """
        Query pull requests for repository via:
        GET /rest/awesome-graphs-api/latest/projects/{projectKey}/repos/{repositorySlug}/pull-requests
        """
        url = f"{self.base_url}/{self.api_prefix}/projects/{project_key}/repos/{repo_slug}/pull-requests"
        params = {}
        if since_date:
            params["sinceDate"] = since_date
        if until_date:
            params["untilDate"] = until_date

        prs = []
        start_time = time.time()

        def fetch_page(start: int, limit: int):
            page_params = {**params, "start": start, "limit": min(limit, 500)}
            req_start = time.time()
            resp = self.session.get(url, params=page_params, timeout=45)
            duration_ms = int((time.time() - req_start) * 1000)

            logger.info(
                f"AwesomeGraphs Query: GET {url} | Params: {page_params} | Status: {resp.status_code} | Latency: {duration_ms}ms"
            )
            resp.raise_for_status()
            return resp.json()

        try:
            for item in paginate(fetch_page, page_limit=100):
                author = item.get("author", {}).get("user", {})
                user_id = author.get("name") or author.get("slug") or author.get("displayName") or "unknown"
                display_name = author.get("displayName") or user_id

                pr_event = PullRequestEvent(
                    event_id=str(item.get("id", "")),
                    project_key=project_key,
                    repo_slug=repo_slug,
                    user_id=user_id,
                    display_name=display_name,
                    title=item.get("title"),
                    state=item.get("state"),
                    created_date=item.get("createdDate", item.get("created_date", "")),
                    updated_date=item.get("updatedDate"),
                    closed_date=item.get("closedDate")
                )
                prs.append(pr_event)

            total_ms = int((time.time() - start_time) * 1000)
            logger.info(
                f"Completed PRs extraction for {project_key}/{repo_slug}: {len(prs)} PRs retrieved in {total_ms}ms"
            )
            return prs
        except Exception as e:
            logger.error(f"Error extracting PRs for {project_key}/{repo_slug}: {e}", exc_info=True)
            raise
