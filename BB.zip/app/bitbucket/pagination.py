import time
import logging
from typing import Callable, Generator, Dict, Any

logger = logging.getLogger(__name__)


def paginate(
    fetch_page: Callable[[int, int], Dict[str, Any]],
    page_limit: int = 100,
    max_retries: int = 3,
    backoff_factor: float = 1.5
) -> Generator[Dict[str, Any], None, None]:
    """
    Generic paginator for Bitbucket Server/DC and Awesome Graphs APIs.
    Yields individual item dicts from the 'values' array.
    """
    start = 0

    while True:
        attempts = 0
        while True:
            try:
                page = fetch_page(start, page_limit)
                break
            except Exception as exc:
                attempts += 1
                if attempts > max_retries:
                    logger.error(f"Failed to fetch page at start={start} after {max_retries} attempts: {exc}")
                    raise
                sleep_time = backoff_factor ** attempts
                logger.warning(f"Request failed ({exc}). Retrying in {sleep_time:.1f}s (attempt {attempts}/{max_retries})...")
                time.sleep(sleep_time)

        if not page or "values" not in page:
            break

        values = page.get("values", [])
        for item in values:
            yield item

        if page.get("isLastPage", True):
            break

        # Check for nextPageStart
        next_start = page.get("nextPageStart")
        if next_start is None or next_start == start:
            # Fallback if nextPageStart is missing but not last page
            start += len(values)
        else:
            start = next_start
