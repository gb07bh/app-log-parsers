import logging
from typing import List, Optional

from app.config.schema import BitbucketConfig
from app.bitbucket.models import Project, Repository, CommitEvent, PullRequestEvent
from app.bitbucket.dc_client import BitbucketDCClient
from app.bitbucket.awesome_graphs_client import AwesomeGraphsClient

logger = logging.getLogger("bitbucket.hybrid_client")


class HybridBitbucketClient:
    """
    Coordinates Bitbucket Data Center REST API and Awesome Graphs REST API.
      - Projects & Repositories discovery: Bitbucket DC REST API (/rest/api/latest)
      - Commits & Pull Requests extraction: Awesome Graphs REST API (/rest/awesome-graphs-api/latest)
    """
    def __init__(self, config: BitbucketConfig):
        self.config = config
        self.dc_client = BitbucketDCClient(config)
        self.ag_client = AwesomeGraphsClient(config)

    def discover_projects(self) -> List[Project]:
        """Discover projects via DC REST API, respecting project key filter."""
        return self.dc_client.list_projects()

    def discover_repositories(self, project_key: str) -> List[Repository]:
        """
        Discover repositories for a project via DC REST API,
        applying configured repository limit ('NA' or integer).
        """
        raw_limit = self.config.repositories.limit
        numeric_limit: Optional[int] = None
        if isinstance(raw_limit, int):
            numeric_limit = raw_limit
        elif isinstance(raw_limit, str) and raw_limit.strip().isdigit():
            numeric_limit = int(raw_limit.strip())

        return self.dc_client.list_repositories(project_key, limit=numeric_limit)

    def fetch_repo_commits(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[CommitEvent]:
        """Fetch commits for repository via Awesome Graphs REST API."""
        return self.ag_client.list_repo_commits(
            project_key=project_key,
            repo_slug=repo_slug,
            since_date=since_date,
            until_date=until_date
        )

    def fetch_repo_pull_requests(
        self,
        project_key: str,
        repo_slug: str,
        since_date: Optional[str] = None,
        until_date: Optional[str] = None
    ) -> List[PullRequestEvent]:
        """Fetch pull requests for repository via Awesome Graphs REST API."""
        return self.ag_client.list_repo_pull_requests(
            project_key=project_key,
            repo_slug=repo_slug,
            since_date=since_date,
            until_date=until_date
        )
