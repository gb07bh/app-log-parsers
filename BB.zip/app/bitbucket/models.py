from typing import Optional
from pydantic import BaseModel, Field


class Project(BaseModel):
    key: str
    name: str
    id: Optional[int] = None
    description: Optional[str] = None
    public: bool = False


class Repository(BaseModel):
    slug: str
    name: str
    id: Optional[int] = None
    project_key: str
    project_name: Optional[str] = None


class CommitEvent(BaseModel):
    event_id: str
    project_key: str
    repo_slug: str
    user_id: str
    display_name: str
    email: Optional[str] = None
    timestamp: str  # ISO-8601 UTC
    lines_added: Optional[int] = 0
    lines_deleted: Optional[int] = 0


class PullRequestEvent(BaseModel):
    event_id: str
    project_key: str
    repo_slug: str
    user_id: str
    display_name: str
    title: Optional[str] = None
    state: Optional[str] = None  # OPEN, MERGED, DECLINED
    created_date: str  # ISO-8601 UTC
    updated_date: Optional[str] = None
    closed_date: Optional[str] = None
