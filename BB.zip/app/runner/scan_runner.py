import uuid
import time
import logging
from datetime import datetime, timezone
import calendar
from typing import Optional, Callable

from app.config.schema import AppConfig
from app.logging_config import set_trace_context
from app.bitbucket.hybrid_client import HybridBitbucketClient
from app.reporting.models import ReportMetadata, ReportData
from app.reporting.aggregator import Aggregator
from app.storage.file_store import FileStore
from app.storage.artifactory import ArtifactoryClient
from app.runner.worker_pool import WorkerPool

logger = logging.getLogger("runner.scan_runner")


def compute_month_boundaries(year_month: str) -> tuple[str, str]:
    """
    Compute half-open interval [start, end) for a month string 'YYYY-MM'.
    Example: '2026-09' -> ('2026-09-01T00:00:00Z', '2026-10-01T00:00:00Z')
    """
    parts = year_month.split("-")
    year = int(parts[0])
    month = int(parts[1])

    start_dt = datetime(year, month, 1, 0, 0, 0, tzinfo=timezone.utc)
    if month == 12:
        end_dt = datetime(year + 1, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    else:
        end_dt = datetime(year, month + 1, 1, 0, 0, 0, tzinfo=timezone.utc)

    return start_dt.strftime("%Y-%m-%dT%H:%M:%SZ"), end_dt.strftime("%Y-%m-%dT%H:%M:%SZ")


class ScanRunner:
    """
    Standalone Scan Execution Engine.
    Executes outside of Flask (via CLI, Worker node, or Jenkins agent).
    """

    def __init__(self, config: AppConfig):
        self.config = config
        self.client = HybridBitbucketClient(config.bitbucket)
        self.file_store = FileStore(config.report.storage_path)
        self.artifactory = ArtifactoryClient(config.artifactory)

    def execute(
        self,
        year_month: Optional[str] = None,
        job_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> ReportData:
        """
        Execute full scan pipeline:
          1. Calculate date boundaries
          2. Discover projects (Bitbucket DC API)
          3. Discover repositories (Bitbucket DC API)
          4. 5 parallel workers fetch commits & PRs (Awesome Graphs API)
          5. Aggregate ReportData
          6. Persist locally to FileStore
          7. Publish to Artifactory
        """
        start_exec_time = time.time()
        now_dt = datetime.now(timezone.utc)

        if not year_month:
            year_month = now_dt.strftime("%Y-%m")

        since_date, until_date = compute_month_boundaries(year_month)

        # Generate automatic IDs if not supplied
        if not job_id:
            job_id = f"run-{now_dt.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
        if not trace_id:
            trace_id = f"trace-{uuid.uuid4().hex[:8]}"

        set_trace_context(trace_id, job_id)

        logger.info(f"=== Starting Scan Execution for Month: {year_month} ===")
        logger.info(f"Job ID: {job_id} | Trace ID: {trace_id}")
        logger.info(f"Time Range (half-open): {since_date} <= event_time < {until_date}")

        # Step 1: Discover Projects (DC API)
        logger.info("Discovering projects via Bitbucket DC API...")
        projects = self.client.discover_projects()
        logger.info(f"Found {len(projects)} projects.")

        # Step 2: Discover Repositories for each project (DC API)
        all_repositories = []
        for p in projects:
            repos = self.client.discover_repositories(p.key)
            all_repositories.extend(repos)

        logger.info(f"Total repositories discovered across all projects: {len(all_repositories)}")

        if not all_repositories:
            logger.warning("No repositories found to scan.")

        # Step 3: Parallel Workers (Awesome Graphs API)
        worker_pool = WorkerPool(self.client, worker_count=self.config.workers.count)
        commits_by_repo, prs_by_repo, errors = worker_pool.process_repositories(
            repositories=all_repositories,
            since_date=since_date,
            until_date=until_date,
            progress_callback=progress_callback
        )

        status = "COMPLETED"
        if errors:
            status = "PARTIAL_SUCCESS" if len(errors) < len(all_repositories) else "FAILED"

        # Step 4: Metadata and Aggregation
        metadata = ReportMetadata(
            job_id=job_id,
            trace_id=trace_id,
            generated_at=now_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
            period_start=since_date,
            period_end=until_date,
            projects_configured=self.config.bitbucket.projects.keys,
            repository_limit=self.config.bitbucket.repositories.limit,
            worker_count=self.config.workers.count,
            status=status,
            total_repositories=len(all_repositories),
            completed_repositories=len(all_repositories) - len(errors),
            failed_repositories=len(errors),
            errors=errors
        )

        report = Aggregator.build_report(
            metadata=metadata,
            repositories=all_repositories,
            commits_by_repo=commits_by_repo,
            prs_by_repo=prs_by_repo
        )

        # Step 5: Save locally (FileStore)
        local_dir = self.file_store.save_report(report)
        logger.info(f"Report saved locally to: {local_dir}")

        # Step 6: Publish to Artifactory
        if self.config.artifactory.enabled:
            logger.info("Publishing report to Artifactory...")
            self.artifactory.publish_report(report)

        duration_sec = time.time() - start_exec_time
        logger.info(
            f"=== Scan Completed in {duration_sec:.2f}s | Commits: {report.total_commits} | PRs: {report.total_pull_requests} | Users: {report.total_active_users} | Status: {status} ==="
        )
        return report
