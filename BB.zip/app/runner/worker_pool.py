import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Callable, Dict, Any, Tuple, Optional
from app.bitbucket.models import Repository, CommitEvent, PullRequestEvent
from app.bitbucket.hybrid_client import HybridBitbucketClient

logger = logging.getLogger("runner.worker_pool")


class WorkerPool:
    """
    Executes repository scans in parallel using ThreadPoolExecutor.
    Default worker count is 5.
    Units of parallelism are REPOSITORIES, not individual API calls.
    """

    def __init__(self, client: HybridBitbucketClient, worker_count: int = 5):
        self.client = client
        self.worker_count = worker_count

    def process_repositories(
        self,
        repositories: List[Repository],
        since_date: str,
        until_date: str,
        progress_callback: Optional[Callable[[int, int, str], None]] = None
    ) -> Tuple[Dict[str, List[CommitEvent]], Dict[str, List[PullRequestEvent]], List[Dict[str, Any]]]:
        """
        Process repositories in parallel with 5 worker threads.
        Returns: (commits_by_repo, prs_by_repo, errors)
        """
        commits_by_repo: Dict[str, List[CommitEvent]] = {}
        prs_by_repo: Dict[str, List[PullRequestEvent]] = {}
        errors: List[Dict[str, Any]] = []

        total_repos = len(repositories)
        completed_count = 0

        logger.info(
            f"Starting parallel processing of {total_repos} repositories across {self.worker_count} worker threads..."
        )

        def scan_single_repo(repo: Repository):
            repo_errors = []
            commits = []
            prs = []

            # 1. Fetch commits
            try:
                commits = self.client.fetch_repo_commits(
                    project_key=repo.project_key,
                    repo_slug=repo.slug,
                    since_date=since_date,
                    until_date=until_date
                )
            except Exception as e:
                logger.error(f"Commit collection failed for {repo.project_key}/{repo.slug}: {e}")
                repo_errors.append({
                    "project": repo.project_key,
                    "repository": repo.slug,
                    "operation": "commits",
                    "error": str(e)
                })

            # 2. Fetch pull requests
            try:
                prs = self.client.fetch_repo_pull_requests(
                    project_key=repo.project_key,
                    repo_slug=repo.slug,
                    since_date=since_date,
                    until_date=until_date
                )
            except Exception as e:
                logger.error(f"Pull Request collection failed for {repo.project_key}/{repo.slug}: {e}")
                repo_errors.append({
                    "project": repo.project_key,
                    "repository": repo.slug,
                    "operation": "pull_requests",
                    "error": str(e)
                })

            return repo, commits, prs, repo_errors

        with ThreadPoolExecutor(max_workers=self.worker_count) as executor:
            future_to_repo = {
                executor.submit(scan_single_repo, repo): repo for repo in repositories
            }

            for future in as_completed(future_to_repo):
                repo = future_to_repo[future]
                completed_count += 1
                try:
                    r, commits, prs, errs = future.result()
                    commits_by_repo[r.slug] = commits
                    prs_by_repo[r.slug] = prs
                    if errs:
                        errors.extend(errs)
                except Exception as exc:
                    logger.error(f"Worker crashed on repository {repo.project_key}/{repo.slug}: {exc}", exc_info=True)
                    errors.append({
                        "project": repo.project_key,
                        "repository": repo.slug,
                        "operation": "worker_execution",
                        "error": str(exc)
                    })

                if progress_callback:
                    progress_callback(completed_count, total_repos, f"{repo.project_key}/{repo.slug}")

        logger.info(
            f"Finished parallel repo processing: {completed_count}/{total_repos} finished. {len(errors)} error(s) encountered."
        )
        return commits_by_repo, prs_by_repo, errors
