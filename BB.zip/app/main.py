import sys
import os
import argparse
import logging
from datetime import datetime, timezone

# Ensure project root is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config.config_loader import load_config
from app.logging_config import configure_logging
from app.runner.scan_runner import ScanRunner
from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity, TimeseriesPoint
)
from app.storage.file_store import FileStore
from app.storage.artifactory import ArtifactoryClient


def run_mock_scan(config, month: str):
    """Generates a realistic mock report to verify pipeline and UI without live Bitbucket."""
    logger = logging.getLogger("runner.mock_scan")
    logger.info(f"Generating mock report for {month}...")

    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    since_date = f"{month}-01T00:00:00Z"
    parts = month.split("-")
    y, m = int(parts[0]), int(parts[1])
    until_date = f"{y if m < 12 else y+1}-{(m+1 if m < 12 else 1):02d}-01T00:00:00Z"

    metadata = ReportMetadata(
        job_id=f"mock-{month}-run01",
        trace_id="trace-mock-test01",
        generated_at=now_iso,
        period_start=since_date,
        period_end=until_date,
        projects_configured=["PAY", "CORE", "AUTH"],
        repository_limit=10,
        worker_count=5,
        status="COMPLETED",
        total_repositories=3,
        completed_repositories=3,
        failed_repositories=0,
        errors=[]
    )

    repos = [
        RepoSummary(
            project_key="PAY",
            project_name="Payments Platform",
            repo_slug="payment-gateway",
            repo_name="payment-gateway",
            commits=142,
            pull_requests=38,
            unique_commit_authors=4,
            unique_pr_authors=3,
            users=[
                UserActivity(user_id="john.doe", display_name="John Doe", commits=75, pull_requests=18),
                UserActivity(user_id="jane.smith", display_name="Jane Smith", commits=45, pull_requests=12),
                UserActivity(user_id="alice.wang", display_name="Alice Wang", commits=15, pull_requests=5),
                UserActivity(user_id="bob.jones", display_name="Bob Jones", commits=7, pull_requests=3),
            ]
        ),
        RepoSummary(
            project_key="CORE",
            project_name="Core Services",
            repo_slug="ledger-service",
            repo_name="ledger-service",
            commits=89,
            pull_requests=24,
            unique_commit_authors=3,
            unique_pr_authors=2,
            users=[
                UserActivity(user_id="john.doe", display_name="John Doe", commits=40, pull_requests=10),
                UserActivity(user_id="jane.smith", display_name="Jane Smith", commits=35, pull_requests=11),
                UserActivity(user_id="charlie.brown", display_name="Charlie Brown", commits=14, pull_requests=3),
            ]
        ),
        RepoSummary(
            project_key="AUTH",
            project_name="Identity & Access",
            repo_slug="oauth-server",
            repo_name="oauth-server",
            commits=64,
            pull_requests=19,
            unique_commit_authors=2,
            unique_pr_authors=2,
            users=[
                UserActivity(user_id="alice.wang", display_name="Alice Wang", commits=38, pull_requests=11),
                UserActivity(user_id="bob.jones", display_name="Bob Jones", commits=26, pull_requests=8),
            ]
        )
    ]

    # Generate daily points for overall timeline
    timeline = []
    for day in range(1, 29):
        day_str = f"{month}-{day:02d}"
        timeline.append(TimeseriesPoint(
            date=day_str,
            commits=8 + (day % 7) * 3,
            pull_requests=2 + (day % 4)
        ))

    # Build UserProfiles for mock data
    user_profiles = {}
    from collections import defaultdict
    user_data = defaultdict(lambda: {"commits": 0, "prs": 0, "display_name": "", "contribs": []})

    for r in repos:
        for u in r.users:
            user_data[u.user_id]["commits"] += u.commits
            user_data[u.user_id]["prs"] += u.pull_requests
            user_data[u.user_id]["display_name"] = u.display_name
            user_data[u.user_id]["contribs"].append(
                UserProjectContribution(
                    project_key=r.project_key,
                    project_name=r.project_name,
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=u.commits,
                    pull_requests=u.pull_requests
                )
            )

    from app.reporting.models import (
        UserProfile, UserProjectContribution, ProjectProfile,
        ProjectRepoContribution, RepoProfile
    )
    for uid, d in user_data.items():
        # User daily timeline points
        u_tl = []
        u_proj_tl = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            # distribute user commits roughly across days
            c_day = (d["commits"] // 28) + (1 if day <= (d["commits"] % 28) else 0)
            pr_day = (d["prs"] // 28) + (1 if day <= (d["prs"] % 28) else 0)
            u_tl.append(TimeseriesPoint(date=day_str, commits=c_day, pull_requests=pr_day))

            # Distribute per project
            for contrib in d["contribs"]:
                proj_c = (contrib.commits // 28) + (1 if day <= (contrib.commits % 28) else 0)
                proj_pr = (contrib.pull_requests // 28) + (1 if day <= (contrib.pull_requests % 28) else 0)
                u_proj_tl[contrib.project_key].append(TimeseriesPoint(date=day_str, commits=proj_c, pull_requests=proj_pr))

        user_profiles[uid] = UserProfile(
            user_id=uid,
            display_name=d["display_name"],
            email=f"{uid}@example.com",
            total_commits=d["commits"],
            total_pull_requests=d["prs"],
            timeline=u_tl,
            project_contributions=d["contribs"],
            project_timeline=dict(u_proj_tl)
        )

    # Build Project Profiles & Repo Profiles
    project_profiles = {}
    repo_profiles = {}
    proj_repos = defaultdict(list)
    for r in repos:
        proj_repos[r.project_key].append(r)

    for pkey, p_list in proj_repos.items():
        p_name = p_list[0].project_name
        p_commits = sum(r.commits for r in p_list)
        p_prs = sum(r.pull_requests for r in p_list)
        p_users = set()
        for r in p_list:
            for u in r.users:
                p_users.add(u.user_id)

        p_repo_contribs = [
            ProjectRepoContribution(
                repo_slug=r.repo_slug,
                repo_name=r.repo_name,
                commits=r.commits,
                pull_requests=r.pull_requests,
                unique_commit_authors=r.unique_commit_authors,
                unique_pr_authors=r.unique_pr_authors,
                users=r.users
            )
            for r in p_list
        ]

        # Project timeline
        p_tl = []
        p_repo_tl = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            c_tot = sum((r.commits // 28) + (1 if day <= (r.commits % 28) else 0) for r in p_list)
            pr_tot = sum((r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0) for r in p_list)
            p_tl.append(TimeseriesPoint(date=day_str, commits=c_tot, pull_requests=pr_tot))

            for r in p_list:
                r_c = (r.commits // 28) + (1 if day <= (r.commits % 28) else 0)
                r_pr = (r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0)
                p_repo_tl[r.repo_slug].append(TimeseriesPoint(date=day_str, commits=r_c, pull_requests=r_pr))

        project_profiles[pkey] = ProjectProfile(
            project_key=pkey,
            project_name=p_name,
            total_commits=p_commits,
            total_pull_requests=p_prs,
            total_repositories=len(p_list),
            total_active_users=len(p_users),
            timeline=p_tl,
            repo_contributions=p_repo_contribs,
            repo_timeline=dict(p_repo_tl)
        )

    for r in repos:
        r_tl = []
        u_tl_map = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            r_c = (r.commits // 28) + (1 if day <= (r.commits % 28) else 0)
            r_pr = (r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0)
            r_tl.append(TimeseriesPoint(date=day_str, commits=r_c, pull_requests=r_pr))

            for u in r.users:
                u_c = (u.commits // 28) + (1 if day <= (u.commits % 28) else 0)
                u_pr = (u.pull_requests // 28) + (1 if day <= (u.pull_requests % 28) else 0)
                u_tl_map[u.user_id].append(TimeseriesPoint(date=day_str, commits=u_c, pull_requests=u_pr))

        full_k = f"{r.project_key}/{r.repo_slug}"
        repo_profiles[full_k] = RepoProfile(
            project_key=r.project_key,
            project_name=r.project_name,
            repo_slug=r.repo_slug,
            repo_name=r.repo_name,
            total_commits=r.commits,
            total_pull_requests=r.pull_requests,
            unique_commit_authors=r.unique_commit_authors,
            unique_pr_authors=r.unique_pr_authors,
            total_active_users=len(r.users),
            timeline=r_tl,
            users=r.users,
            user_timeline=dict(u_tl_map)
        )

    report = ReportData(
        metadata=metadata,
        total_commits=sum(r.commits for r in repos),
        total_pull_requests=sum(r.pull_requests for r in repos),
        total_repositories=len(repos),
        total_active_users=len(user_profiles),
        repositories=repos,
        timeline=timeline,
        users=user_profiles,
        projects=project_profiles,
        repo_profiles=repo_profiles
    )

    file_store = FileStore(config.report.storage_path)
    job_dir = file_store.save_report(report)
    logger.info(f"Mock report saved locally to: {job_dir}")

    if config.artifactory.enabled:
        artifactory = ArtifactoryClient(config.artifactory)
        artifactory.publish_report(report)

    print(f"\n Mock report generated successfully for {month}!")
    print(f"   Directory: {job_dir}")
    print(f"   Total Commits: {report.total_commits} | Total PRs: {report.total_pull_requests} | Repos: {report.total_repositories}\n")
    return report


def main():
    parser = argparse.ArgumentParser(description="Bitbucket Repository Activity Reporting System")
    subparsers = parser.add_subparsers(dest="command", help="Sub-commands: serve, scan")

    # Serve command (Flask UI server)
    serve_parser = subparsers.add_parser("serve", help="Start the Flask reporting UI server")
    serve_parser.add_argument("--host", type=str, default=None, help="Host to bind (default from config)")
    serve_parser.add_argument("--port", type=int, default=None, help="Port to bind (default from config)")
    serve_parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")

    # Scan command (External/standalone scan runner)
    scan_parser = subparsers.add_parser("scan", help="Run the repository scan (Bitbucket DC + Awesome Graphs)")
    scan_parser.add_argument("--month", type=str, default=None, help="Reporting month in YYYY-MM format (e.g. 2026-09)")
    scan_parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")
    scan_parser.add_argument("--mock", action="store_true", help="Generate mock report data for testing")

    args = parser.parse_args()

    # Default to 'serve' if no command given
    cmd = args.command or "serve"
    config_path = getattr(args, "config", None)
    config = load_config(config_path)

    configure_logging(log_dir=config.logging.directory, log_level=config.logging.level)

    if cmd == "serve":
        from app import create_app
        app = create_app(config)
        host = args.host or config.application.host
        port = args.port or config.application.port
        print(f"\n=======================================================")
        print(f" Starting Bitbucket Activity Report Server")
        print(f" Dashboard URL: http://{host}:{port}")
        print(f" Environment:   {config.application.environment}")
        print(f" Reports Path:  {config.report.storage_path}")
        print(f" Logs Path:     {config.logging.directory}")
        print(f"=======================================================\n")
        app.run(host=host, port=port, debug=(config.application.environment == "development"))

    elif cmd == "scan":
        month = args.month or datetime.now(timezone.utc).strftime("%Y-%m")
        if args.mock:
            run_mock_scan(config, month)
        else:
            runner = ScanRunner(config)
            report = runner.execute(year_month=month)
            print(f"\n Scan completed successfully for {month}!")
            print(f"   Status: {report.metadata.status}")
            print(f"   Job ID: {report.metadata.job_id}")
            print(f"   Trace ID: {report.metadata.trace_id}")
            print(f"   Commits: {report.total_commits} | Pull Requests: {report.total_pull_requests}\n")


if __name__ == "__main__":
    main()
