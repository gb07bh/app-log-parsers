import os
import sys
import logging
from logging.handlers import RotatingFileHandler
from contextvars import ContextVar
from typing import Optional

# Context variables for trace correlation across async/threads
current_trace_id: ContextVar[str] = ContextVar("current_trace_id", default="none")
current_job_id: ContextVar[str] = ContextVar("current_job_id", default="none")


def set_trace_context(trace_id: str, job_id: Optional[str] = None):
    """Set the trace ID and optional job ID in context variables."""
    current_trace_id.set(trace_id)
    if job_id:
        current_job_id.set(job_id)


def get_trace_id() -> str:
    return current_trace_id.get()


def get_job_id() -> str:
    return current_job_id.get()


class TraceContextFilter(logging.Filter):
    """Log filter that enriches LogRecord with trace_id and job_id."""
    def filter(self, record):
        record.trace_id = current_trace_id.get()
        record.job_id = current_job_id.get()
        return True


class ComponentNameFilter(logging.Filter):
    """Filter that matches specific logger name prefixes."""
    def __init__(self, prefixes):
        super().__init__()
        self.prefixes = prefixes if isinstance(prefixes, (list, tuple)) else [prefixes]

    def filter(self, record):
        return any(record.name.startswith(p) for p in self.prefixes)


def configure_logging(log_dir: str = "./logs", log_level: str = "INFO"):
    """
    Configure enterprise logging with 4 distinct destinations:
      1. logs/projects.log      - Project & repo discovery and scan tracking
      2. logs/awesome_graphs.log - Awesome Graphs REST queries and telemetry
      3. logs/console.log       - Centralized consolidated logs
      4. sys.stdout             - Standard terminal output
    """
    os.makedirs(log_dir, exist_ok=True)
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)

    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    root_logger.handlers = []  # reset handlers

    trace_filter = TraceContextFilter()

    # Standard formatter with trace_id and job_id
    file_formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)-7s] [trace_id=%(trace_id)s] [job_id=%(job_id)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    console_formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)-7s] [trace=%(trace_id)s] [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )

    # 1. Console Output Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(console_formatter)
    console_handler.addFilter(trace_filter)
    root_logger.addHandler(console_handler)

    # 2. Master logs/console.log (All logs)
    all_file_path = os.path.join(log_dir, "console.log")
    all_handler = RotatingFileHandler(all_file_path, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    all_handler.setLevel(numeric_level)
    all_handler.setFormatter(file_formatter)
    all_handler.addFilter(trace_filter)
    root_logger.addHandler(all_handler)

    # 3. logs/projects.log (Dedicated to project discovery and repository listing)
    projects_file_path = os.path.join(log_dir, "projects.log")
    projects_handler = RotatingFileHandler(projects_file_path, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    projects_handler.setLevel(logging.INFO)
    projects_handler.setFormatter(file_formatter)
    projects_handler.addFilter(trace_filter)
    projects_handler.addFilter(ComponentNameFilter(["bitbucket.dc_client", "runner.projects", "jobs.projects"]))
    root_logger.addHandler(projects_handler)

    # 4. logs/awesome_graphs.log (Dedicated to Awesome Graphs queries and performance metrics)
    ag_file_path = os.path.join(log_dir, "awesome_graphs.log")
    ag_handler = RotatingFileHandler(ag_file_path, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    ag_handler.setLevel(logging.INFO)
    ag_handler.setFormatter(file_formatter)
    ag_handler.addFilter(trace_filter)
    ag_handler.addFilter(ComponentNameFilter(["bitbucket.awesome_graphs", "runner.awesome_graphs"]))
    root_logger.addHandler(ag_handler)

    logging.info("Logging configured successfully. Output directory: %s", log_dir)
