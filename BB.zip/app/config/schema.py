import os
from typing import List, Union, Optional
from pydantic import BaseModel, Field


class ApplicationConfig(BaseModel):
    name: str = "bitbucket-activity-report"
    environment: str = "production"
    host: str = "0.0.0.0"
    port: int = 5000


class ProjectsFilterConfig(BaseModel):
    keys: List[str] = Field(default_factory=list)


class RepositoriesFilterConfig(BaseModel):
    limit: Union[int, str] = "NA"


class BitbucketConfig(BaseModel):
    base_url: str = "https://bitbucket.example.com"
    dc_api_path: str = "/rest/api/latest"
    awesome_graphs_api_path: str = "/rest/awesome-graphs-api/latest"
    auth_type: str = "basic"  # "basic" or "bearer"
    username_env: str = "BITBUCKET_USERNAME"
    password_env: str = "BITBUCKET_PASSWORD"
    token_env: str = "BITBUCKET_TOKEN"
    projects: ProjectsFilterConfig = Field(default_factory=ProjectsFilterConfig)
    repositories: RepositoriesFilterConfig = Field(default_factory=RepositoriesFilterConfig)

    def get_username(self) -> Optional[str]:
        return os.environ.get(self.username_env)

    def get_password(self) -> Optional[str]:
        return os.environ.get(self.password_env)

    def get_token(self) -> Optional[str]:
        return os.environ.get(self.token_env)


class ReportConfig(BaseModel):
    storage_path: str = "./data/reports"
    timezone: str = "UTC"
    formats: List[str] = Field(default_factory=lambda: ["json", "csv"])


class ArtifactoryConfig(BaseModel):
    enabled: bool = False
    base_url: str = "https://artifactory.example.com/artifactory"
    repository: str = "generic-reports"
    path: str = "bitbucket-reports/monthly"
    username_env: str = "ARTIFACTORY_USERNAME"
    password_env: str = "ARTIFACTORY_PASSWORD"
    token_env: str = "ARTIFACTORY_TOKEN"

    def get_username(self) -> Optional[str]:
        return os.environ.get(self.username_env)

    def get_password(self) -> Optional[str]:
        return os.environ.get(self.password_env)

    def get_token(self) -> Optional[str]:
        return os.environ.get(self.token_env)


class JenkinsConfig(BaseModel):
    enabled: bool = False
    base_url: str = "https://jenkins.example.com"
    job_name: str = "Bitbucket-Activity-Report-Scan"
    username_env: str = "JENKINS_USERNAME"
    token_env: str = "JENKINS_TOKEN"

    def get_username(self) -> Optional[str]:
        return os.environ.get(self.username_env)

    def get_token(self) -> Optional[str]:
        return os.environ.get(self.token_env)


class WorkersConfig(BaseModel):
    count: int = 5


class ExecutionConfig(BaseModel):
    timeout_seconds: int = 3600
    retry_count: int = 3
    backoff_factor: float = 1.5
    run_now_enabled: bool = True


class LoggingConfig(BaseModel):
    level: str = "INFO"
    directory: str = "./logs"


class AppConfig(BaseModel):
    application: ApplicationConfig = Field(default_factory=ApplicationConfig)
    bitbucket: BitbucketConfig = Field(default_factory=BitbucketConfig)
    report: ReportConfig = Field(default_factory=ReportConfig)
    artifactory: ArtifactoryConfig = Field(default_factory=ArtifactoryConfig)
    jenkins: JenkinsConfig = Field(default_factory=JenkinsConfig)
    workers: WorkersConfig = Field(default_factory=WorkersConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
