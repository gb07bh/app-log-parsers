import os
import yaml
import logging
from typing import Optional
from app.config.schema import AppConfig

logger = logging.getLogger(__name__)


def load_config(config_path: Optional[str] = None) -> AppConfig:
    """
    Load YAML configuration file and return validated AppConfig instance.
    If path is omitted, checks CONFIG_PATH env var, then default 'config/config.yaml'.
    """
    if not config_path:
        config_path = os.environ.get("CONFIG_PATH", "config/config.yaml")

    if not os.path.exists(config_path):
        logger.warning(f"Config file not found at {config_path}. Using default configuration.")
        return AppConfig()

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return AppConfig(**data)
    except Exception as e:
        logger.error(f"Error loading config from {config_path}: {e}", exc_info=True)
        raise
