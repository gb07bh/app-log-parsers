# Gateway Architecture

## System Boundary

```text
ALB
 |
SSO
 |
Apache HTTPD
 |
Gateway Linux Server
 |
PostgreSQL
```

Future scale-out:

```text
             ALB
           /     \
 Gateway-01     Gateway-02
          \       /
           \     /
          PostgreSQL
```

ALB, SSO and Apache are existing infrastructure. Gateway owns everything from the Linux application server downward.

## Gateway Node
Contains:
- Flask application/UI/API
- Gunicorn
- YAML configuration
- identity/authorization
- adapters
- audit
- logging
- PostgreSQL client
- health checks
- lifecycle scripts
- housekeeping
- documentation

## Stack
- Python 3.9 or 3.10
- Flask
- Gunicorn
- Jinja2
- HTML/CSS + minimal vanilla JavaScript
- SQLAlchemy
- Alembic
- PostgreSQL + psycopg
- PyYAML
- Pydantic
- httpx
- pytest

No frontend framework without explicit approval.

## Application Structure

```text
Gateway
├── UI/API
├── Identity
├── Authorization
├── Release Service
├── Adapters
├── Audit
├── Database
├── Configuration
├── Logging
├── Health
└── Housekeeping
```

Logical modules in one deployable application; not separate services.

## Identity

```text
SSO -> Apache -> Flask -> normalized Gateway identity
```

LDAP/SSO groups provide project/role information, e.g.:
- `DAI_ProjectA_DEV`
- `DAI_ProjectA_APS`
- `DAI_ProjectA_AUDIT`
- `DAI_ProjectA_DESIGNER`

Users may have multiple projects and roles. Gateway execution authorization evaluates DEV/APS only.

## Execution

```text
Human
 -> SSO
 -> Gateway identity
 -> Project/DEV/APS authorization
 -> Release classification
 -> Service-account resolution
 -> Downstream adapter
 -> Execution
 -> Audit
```

Human identity is determined by the Gateway. Downstream systems cannot establish or override it.

## Adapters
All downstream integrations implement a common adapter contract.

Initial:
- Mock/custom API

Future:
- Jenkins
- Digital.ai
- Other approved APIs

Gateway business logic must not contain vendor-specific API calls. Core tests must work without Digital.ai.

## Release Classification
Classification uses a provider abstraction.

V1 candidate: Digital.ai tags.

Future providers may use metadata or another mechanism.

Unknown/unclassified releases fail closed.

## Database
PostgreSQL is the shared persistent store for audit, execution records, project configuration/state, service-account mappings and other shared Gateway state.

SQLite is not permitted for production.

## Configuration
All environment-specific configuration is YAML-driven.

YAML may define server, database, logging, identity mappings, adapters, classification, timeouts and housekeeping.

Secrets are never stored in YAML. Use a Python `CredentialResolver` calling `getCred`.

## Logging

```text
logs/
├── audit.log
├── console.log
└── service.log
```

`audit.log`: human UID/name, project, role, action, release, service account, request ID, downstream execution ID, result/reason.

`console.log`: timestamp, request ID, HTTP method, path, user, status, duration, safe error information.

`service.log`: startup/shutdown, configuration, authentication/LDAP, authorization, classification, credential lookup events (never secret values), downstream activity, timeouts/errors, DB/dependency state, health events.

Use structured JSON. Never log secrets.

## Correlation
Every request receives a unique request/correlation ID. Propagate it through logs, audit, execution records, adapters and downstream correlation where supported.

## Process Management
Supported lifecycle:

```text
startup.sh start|stop|restart|status|health|validate-config
```

Use `flock`. Use Gunicorn in production. Never use Flask's development server in production.

## Scaling
Initial deployment is one node. The application must be stateless so identical nodes can later be added behind the ALB.

Shared business state belongs in PostgreSQL. Do not depend on process memory or local session files.

Local logs are node-specific and include a node identifier.

## Health
Provide health/readiness endpoints. Distinguish application, database and critical dependency health. Never expose secrets.

## Linux Layout

```text
/opt/release-gateway/
├── app/
├── config/gateway.yaml
├── logs/
│   ├── audit.log
│   ├── console.log
│   └── service.log
├── migrations/
├── scripts/startup.sh
├── tests/
├── docs/
└── run/
```

Run as a dedicated non-root user.

## Development Sequence
1. Host Flask UI and display authenticated user/details captured from SSO/Apache.
2. Implement adapter framework and mock/custom endpoint.
3. Validate identity, authorization, audit and logging independently of Digital.ai.
4. Produce detailed documentation.
5. Add monitoring, utilization tracking and housekeeping.
6. Add the real Digital.ai adapter.
