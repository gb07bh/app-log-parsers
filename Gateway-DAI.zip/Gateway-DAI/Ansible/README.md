# Gateway-DAI Ansible Deployment Suite

This directory contains production-ready Ansible playbooks and modular task definitions for deploying, validating, and cleaning up the **Digital.ai Release Gateway (Gateway-DAI)** middleware.

---

## 📁 Directory Layout

```
Ansible/
├── site.yml                 # Master playbook orchestrating Install, Validate, & Cleanup
├── group_vars/
│   └── all.yml              # Default variables (paths, ports, user/group, retries, etc.)
├── tasks/
│   ├── install.yml          # Installation tasks (dependencies, venv, config rendering, systemd service)
│   ├── validate.yml         # Validation tasks (config check, /health, /ready, phase3 suite)
│   └── cleanup_tmp.yml      # Cleanup tasks (tmp directories, build caches, stale lock files)
├── roles/
│   ├── installation/        # Role wrapper for installation
│   │   └── tasks/main.yml
│   ├── validation/          # Role wrapper for validation
│   │   └── tasks/main.yml
│   └── cleanup/             # Role wrapper for cleanup
│       └── tasks/main.yml
└── templates/
    ├── gateway.yaml.j2      # Jinja template for config/gateway.yaml
    └── gateway.service.j2   # Jinja systemd service unit template
```

---

## 🛠️ Tasks Summary

### 1. Installation (`tasks/install.yml`)
- Ensures required system packages (`python3`, `python3-venv`, `curl`, `git`, `rsync`) are installed.
- Manages application group (`gatewayusr`) and user account.
- Creates target directory structure (`/opt/release-gateway`, `config`, `logs`, `run`, `tmp`).
- Synchronizes repository code to the destination path.
- Configures Python virtual environment and installs `requirements.txt`.
- Renders Jinja configuration `config/gateway.yaml` from `templates/gateway.yaml.j2`.
- Installs and restarts the `gateway.service` systemd daemon.

### 2. Validation (`tasks/validate.yml`)
- Runs configuration verification (`startup.sh validate-config` / `load_config`).
- Verifies Gateway HTTP endpoints (`/health` and `/ready`) with retries.
- Executes `scripts/validate_phase3.py` core test runner inside the virtual environment.

### 3. Cleanup of tmp directory (`tasks/cleanup_tmp.yml`)
- Purges and recreates temporary deployment directories (`/tmp/gateway_deploy`).
- Removes temporary deployment artifacts and stale build files from `/tmp`.
- Cleans compiled Python bytecode caches (`__pycache__`).
- Runs `scripts/housekeeping.py --clean-locks` to remove stale lock files.

---

## 🚀 Execution Instructions

### Running Full Pipeline (Install + Validate + Cleanup)

```bash
ansible-playbook -i <path-to-inventory> Ansible/site.yml
```

### Running Specific Tasks by Tag

```bash
# Perform Installation only
ansible-playbook -i <path-to-inventory> Ansible/site.yml --tags "install"

# Perform Validation only
ansible-playbook -i <path-to-inventory> Ansible/site.yml --tags "validate"

# Perform Cleanup of tmp directory only
ansible-playbook -i <path-to-inventory> Ansible/site.yml --tags "cleanup"
```

---

## ⚙️ Jenkinsfile Integration Guidelines

In your `Jenkinsfile`, you can invoke the playbook using `ansiblePlaybook` step or standard shell execution:

```groovy
stage('Deploy & Validate Gateway') {
    steps {
        ansiblePlaybook(
            playbook: 'Ansible/site.yml',
            inventory: 'hosts.ini',
            credentialsId: 'ssh-cert-key',
            extraVars: [
                db_password: "${DB_PASSWORD}",
                gateway_bind_host: '0.0.0.0',
                gateway_port: 8080
            ]
        )
    }
}
```
