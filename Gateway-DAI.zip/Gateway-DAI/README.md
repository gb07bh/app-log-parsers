# Digital.ai Release Gateway (Gateway-DAI)

The **Digital.ai Release Gateway** is a secure, controlled release execution middleware. It sits between corporate users (via SSO/Apache HTTPD) and downstream release systems (Digital.ai, Jenkins, or Mock providers). 

It enforces human identity propagation, project-scoped service account authorization, fail-closed release classification, and structured audit logging.

---

## Documentation Index (Phase 4 Deliverables)
- 📘 [Operational & Technical Guide](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/docs/OPERATIONAL_GUIDE.md) - Setup, startup.sh, ports, directory layout, database pooling & `gateway.yaml` reference.
- 📡 [REST API Specification](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/docs/API_REFERENCE.md) - Endpoint documentation, headers, schemas, error codes, and curl examples.
- 🔌 [Adapter Development Guide](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/docs/ADAPTER_DEVELOPMENT_GUIDE.md) - How to extend and build custom downstream adapters (`BaseAdapter`).
- 🚀 [Deployment & Jinja Templating Guide](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/docs/DEPLOYMENT_AND_JINJA_TEMPLATING.md) - Automated Jinja configuration rendering & Ansible/Terraform setup.
- 📐 [Architecture Specifications](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/architecture.md)
- 📜 [Code Rules & Implementation Constraints](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/code-rules.md)
- 📋 [Gateway Requirements](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/requirements.md)

---

## Key Capabilities & Design Highlights
- **SSO Identity Normalization**: Extracts corporate identity (`X-Remote-User`, `X-Remote-Groups`) into an immutable internal model. Downstream systems cannot override human identity.
- **Server-Side Authorization**: Evaluates `DEV` and `APS` execution permissions per project. Non-execution roles (`AUDIT`, `DESIGNER`) are denied execution rights.
- **Fail-Closed Release Classification**: Validates release tags (e.g. `dev`, `aps`, `prod`). Unknown or unauthorized tags fail closed.
- **Vendor-Neutral Adapters**: Loosely-coupled adapter interface (`BaseAdapter`) with a built-in `MockAdapter` for standalone testing without external dependencies.
- **Structured JSON Logging & Audit**: Outputs `audit.log` (business audit), `console.log` (HTTP metrics), and `service.log` (technical logs) with correlation ID propagation and recursive secret redaction.
- **Secrets Security**: No secrets stored in YAML. Credentials are resolved dynamically via `CredentialResolver` invoking `getCred`.

---

## Quick Setup & Running

```bash
# 1. Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Validate configuration
python scripts/validate_phase3.py

# 4. Run test suite
python -m pytest tests/ -v

# 5. Start application (Local development mode)
python -c "from app import create_app; app = create_app(); app.run(host='0.0.0.0', port=8080)"
```
