import pytest
from app.adapters.factory import AdapterFactory
from app.adapters.mock_adapter import MockAdapter
from app.adapters.base import AdapterError
from app.models import ReleaseExecutionRequest, UserIdentity
from app.config import AdaptersConfig, MockAdapterConfig


def test_mock_adapter_trigger_and_status():
    config = AdaptersConfig(active="mock", mock=MockAdapterConfig(simulate_delay_seconds=0.0))
    adapter = AdapterFactory.create_adapter(config)

    user = UserIdentity(
        username="user1", display_name="User 1", raw_groups=[], projects={"ProjectA": ["DEV"]}
    )
    req = ReleaseExecutionRequest(
        project_name="ProjectA",
        release_name="Release-100",
        execution_role="DEV",
        classification_tag="dev",
    )

    result = adapter.trigger_release(
        request=req,
        service_account_cred="secret123",
        user=user,
        request_id="REQ-001",
    )

    assert result.execution_id.startswith("MOCK-EXEC-")
    assert result.status == "IN_PROGRESS"
    assert result.service_account == "projecta_dev_sa"

    # Fetch status
    status_result = adapter.get_execution_status(result.execution_id)
    assert status_result.status == "COMPLETED"


def test_mock_adapter_health():
    adapter = MockAdapter()
    health = adapter.check_health()
    assert health["status"] == "HEALTHY"
    assert health["adapter"] == "MockAdapter"
