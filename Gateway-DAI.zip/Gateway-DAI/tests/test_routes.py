import json
import pytest
from app import create_app


@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_health_and_readiness_endpoints(client):
    res = client.get("/health")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "UP"

    res_ready = client.get("/ready")
    assert res_ready.status_code == 200
    data_ready = res_ready.get_json()
    assert data_ready["status"] == "READY"


def test_dashboard_ui_renders(client):
    res = client.get("/dashboard", headers={"X-Remote-User": "test_user"})
    assert res.status_code == 200
    assert b"User Authenticated Details" in res.data


def test_user_api_endpoint(client):
    res = client.get(
        "/api/v1/user",
        headers={
            "X-Remote-User": "test_dev",
            "X-Remote-Groups": "DAI_ProjectA_DEV",
        },
    )
    assert res.status_code == 200
    data = res.get_json()
    assert data["username"] == "test_dev"
    assert "ProjectA" in data["projects"]


def test_api_trigger_execution_authorized(client):
    payload = {
        "project_name": "ProjectA",
        "release_name": "Release-V1",
        "execution_role": "DEV",
        "classification_tag": "dev",
    }
    res = client.post(
        "/api/v1/execute",
        data=json.dumps(payload),
        content_type="application/json",
        headers={
            "X-Remote-User": "dev_user",
            "X-Remote-Groups": "DAI_ProjectA_DEV",
        },
    )
    assert res.status_code == 202
    data = res.get_json()
    assert "execution_id" in data
    assert data["service_account"] == "projecta_dev_sa"
    assert data["status"] == "IN_PROGRESS"


def test_api_trigger_execution_unauthorized_role(client):
    payload = {
        "project_name": "ProjectA",
        "release_name": "Release-V1",
        "execution_role": "APS",  # User only has DEV
        "classification_tag": "prod",
    }
    res = client.post(
        "/api/v1/execute",
        data=json.dumps(payload),
        content_type="application/json",
        headers={
            "X-Remote-User": "dev_user",
            "X-Remote-Groups": "DAI_ProjectA_DEV",
        },
    )
    assert res.status_code == 403
    data = res.get_json()
    assert "error" in data
