import pytest
import httpx
from app.adapters.digitalai_adapter import DigitalAIAdapter
from app.adapters.base import AdapterTimeoutError, AdapterConnectionError, AdapterError
from app.adapters.factory import AdapterFactory
from app.config import DigitalAIAdapterConfig, AdaptersConfig
from app.models import ReleaseExecutionRequest, UserIdentity


def test_digitalai_adapter_trigger_release_payload(monkeypatch):
    captured_request = {}

    def mock_post(self, url, json=None, headers=None, **kwargs):
        captured_request["url"] = url
        captured_request["json"] = json
        captured_request["headers"] = headers

        class MockResponse:
            status_code = 200
            def raise_for_status(self): pass
            def json(self):
                return {"id": "DAI-RELEASE-999", "status": "IN_PROGRESS"}

        return MockResponse()

    monkeypatch.setattr(httpx.Client, "post", mock_post)

    adapter_config = DigitalAIAdapterConfig(url="https://digitalai.test.com", trigger_path="/api/v1/trigger")
    adapter = DigitalAIAdapter(config=adapter_config)

    user = UserIdentity(username="sarah_connor", display_name="Sarah Connor", raw_groups=[], projects={"ProjectX": ["DEV"]})
    req = ReleaseExecutionRequest(project_name="ProjectX", release_name="Release-v2.5", execution_role="DEV", classification_tag="dev")

    result = adapter.trigger_release(req, service_account_cred="token_access_xyz123", user=user, request_id="REQ-999")

    # Assert Bearer AccessToken header formatting
    assert captured_request["headers"]["Authorization"] == "Bearer token_access_xyz123"
    assert captured_request["headers"]["X-Correlation-ID"] == "REQ-999"

    # Assert SSO user comment inclusion
    assert captured_request["json"]["comment"] == "Triggered by user sarah_connor"
    assert captured_request["json"]["releaseTitle"] == "Release-v2.5"

    # Assert result model fields
    assert result.execution_id == "DAI-RELEASE-999"
    assert result.triggered_by_user == "sarah_connor"
    assert result.status == "IN_PROGRESS"


def test_digitalai_adapter_timeout_handling(monkeypatch):
    def mock_post_timeout(self, *args, **kwargs):
        raise httpx.TimeoutException("Connection timed out")

    monkeypatch.setattr(httpx.Client, "post", mock_post_timeout)

    adapter = DigitalAIAdapter()
    user = UserIdentity(username="user1", display_name="User 1", raw_groups=[], projects={})
    req = ReleaseExecutionRequest(project_name="Proj", release_name="Rel", execution_role="DEV", classification_tag="dev")

    with pytest.raises(AdapterTimeoutError):
        adapter.trigger_release(req, "cred", user, "REQ-01")


def test_digitalai_adapter_factory_instantiation():
    config = AdaptersConfig(active="digitalai", digitalai=DigitalAIAdapterConfig(url="https://dai.company.com"))
    adapter = AdapterFactory.create_adapter(config)
    assert isinstance(adapter, DigitalAIAdapter)
    assert adapter.config.url == "https://dai.company.com"
