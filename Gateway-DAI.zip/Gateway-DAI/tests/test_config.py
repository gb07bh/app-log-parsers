import pytest
import os
import tempfile
from app.config import load_config, ConfigValidationError, CredentialResolver


def test_load_valid_config():
    config = load_config()
    assert config.server.port == 8080
    assert config.identity.group_prefix == "DAI_"
    assert config.adapters.active == "mock"


def test_load_missing_config():
    with pytest.raises(ConfigValidationError):
        load_config("/path/to/nonexistent/config.yaml")


def test_credential_resolver_fallback(monkeypatch):
    monkeypatch.setenv("CRED_TEST_SA", "secret_pass_123")
    resolver = CredentialResolver()
    val = resolver.resolve("test_sa")
    assert val == "secret_pass_123"
