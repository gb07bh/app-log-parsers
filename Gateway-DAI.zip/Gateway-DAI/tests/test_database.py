import pytest
from app.config import DatabaseConfig
from app.database import DatabaseManager, DatabaseConnectionError, AuditLogRecord, ExecutionRecord


def test_database_config_defaults():
    config = DatabaseConfig()
    assert config.host == "localhost"
    assert config.port == 5432
    assert config.name == "gateway_db"
    assert config.user == "gateway_user"
    assert config.password == "gateway_password"
    assert config.pool_size == 10
    assert config.max_overflow == 20
    assert config.pool_timeout == 30
    assert config.pool_recycle == 1800


def test_database_manager_postgresql_only():
    config = DatabaseConfig(host="localhost", port=5432)
    manager = DatabaseManager(config, lazy_connect=True)
    assert manager.engine.name == "postgresql"


def test_database_manager_eager_connect_failure():
    config = DatabaseConfig(host="non_existent_pg_host_999", port=9999)
    with pytest.raises(DatabaseConnectionError):
        DatabaseManager(config, lazy_connect=False)
