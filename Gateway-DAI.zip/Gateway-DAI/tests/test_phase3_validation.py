import json
import pytest
from flask import Flask
from app import create_app
from app.config import IdentityConfig, AuthConfig, ClassificationConfig, GatewayConfig, AdaptersConfig, MockAdapterConfig
from app.identity import IdentityNormalizer
from app.auth import AuthorizationEvaluator, AuthorizationError, ReleaseClassificationError
from app.models import UserIdentity, ReleaseExecutionRequest
from app.logging import JsonFormatter, GatewayLoggers, sanitize_value
from app.adapters.mock_adapter import MockAdapter
from app.adapters.base import AdapterError


class MockRecord:
    def __init__(self, msg, context=None):
        self.levelname = "INFO"
        self.name = "test.logger"
        self.msg = msg
        self.context = context or {}
        self.exc_info = None

    def getMessage(self):
        return self.msg


# --- 1. IDENTITY EXTRACTION & EDGE CASES ---

def test_identity_case_insensitivity_and_malformed_groups():
    config = IdentityConfig(header_user="X-Remote-User", header_groups="X-Remote-Groups", group_prefix="DAI_")
    normalizer = IdentityNormalizer(config)

    app = Flask(__name__)
    with app.test_request_context(
        headers={
            "X-Remote-User": "  alice_smith  ",
            "X-Remote-Groups": "dai_ProjectAlpha_dev; DAI_ProjectAlpha_aps, INVALID_GROUP, DAI_ProjectBeta_designer; DAI__BAD",
        }
    ):
        from flask import request
        identity = normalizer.extract_identity(request)
        assert identity.username == "alice_smith"
        assert identity.display_name == "Alice Smith"
        assert "ProjectAlpha" in identity.projects
        assert "DEV" in identity.projects["ProjectAlpha"]
        assert "APS" in identity.projects["ProjectAlpha"]
        assert "ProjectBeta" in identity.projects
        assert "DESIGNER" in identity.projects["ProjectBeta"]


def test_identity_empty_headers_fallback():
    config = IdentityConfig(header_user="X-Remote-User", header_groups="X-Remote-Groups", group_prefix="DAI_")
    normalizer = IdentityNormalizer(config)

    app = Flask(__name__)
    with app.test_request_context(headers={}):
        from flask import request
        identity = normalizer.extract_identity(request)
        assert identity.username == "dev_user"
        assert len(identity.projects) > 0


# --- 2. AUTHORIZATION & ROLE BOUNDARIES ---

def test_authorization_designer_audit_roles_fail_closed():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev"], "APS": ["prod"]}),
    )

    user = UserIdentity(
        username="auditor",
        display_name="Auditor User",
        raw_groups=["DAI_ProjectA_AUDIT", "DAI_ProjectA_DESIGNER"],
        projects={"ProjectA": ["AUDIT", "DESIGNER"]},
    )

    # AUDIT role attempt
    req_audit = ReleaseExecutionRequest(
        project_name="ProjectA", release_name="Rel-1", execution_role="AUDIT", classification_tag="dev"
    )
    with pytest.raises(AuthorizationError):
        auth_eval.evaluate_execution_request(user, req_audit)

    # DEV role attempt when user only holds AUDIT/DESIGNER
    req_dev = ReleaseExecutionRequest(
        project_name="ProjectA", release_name="Rel-1", execution_role="DEV", classification_tag="dev"
    )
    with pytest.raises(AuthorizationError):
        auth_eval.evaluate_execution_request(user, req_dev)


def test_authorization_cross_project_isolation():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev"], "APS": ["prod"]}),
    )

    user = UserIdentity(
        username="charlie",
        display_name="Charlie",
        raw_groups=["DAI_ProjectA_DEV"],
        projects={"ProjectA": ["DEV"]},
    )

    # User attempts DEV execution on ProjectB where they have no membership
    req = ReleaseExecutionRequest(
        project_name="ProjectB", release_name="Rel-1", execution_role="DEV", classification_tag="dev"
    )
    with pytest.raises(AuthorizationError):
        auth_eval.evaluate_execution_request(user, req)


# --- 3. RELEASE CLASSIFICATION FAIL-CLOSED ---

def test_classification_tag_mismatch_fails_closed():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev", "sandbox"], "APS": ["prod", "release"]}),
    )

    user = UserIdentity(
        username="dev_user",
        display_name="Dev User",
        raw_groups=["DAI_ProjectA_DEV"],
        projects={"ProjectA": ["DEV"]},
    )

    # DEV user attempts tag 'prod' (which belongs to APS)
    req = ReleaseExecutionRequest(
        project_name="ProjectA", release_name="Rel-1", execution_role="DEV", classification_tag="prod"
    )
    with pytest.raises(ReleaseClassificationError):
        auth_eval.evaluate_execution_request(user, req)


# --- 4. SECRET REDACTION & LOG INTEGRITY ---

def test_recursive_secret_redaction():
    context = {
        "user": "test_user",
        "api_key": "secret_key_12345",
        "db_password": "SuperSecretPassword!",
        "auth_token": "Bearer abc123xyz",
        "nested": {
            "user_credential": "my_secret_cred",
            "safe_value": "hello_world",
        },
        "list_data": [
            {"token": "token_val_1"},
            {"safe_item": "ok"},
        ],
    }

    sanitized = {k: sanitize_value(k, v) for k, v in context.items()}
    assert sanitized["user"] == "test_user"
    assert sanitized["api_key"] == "***REDACTED***"
    assert sanitized["db_password"] == "***REDACTED***"
    assert sanitized["auth_token"] == "***REDACTED***"
    assert sanitized["nested"]["user_credential"] == "***REDACTED***"
    assert sanitized["nested"]["safe_value"] == "hello_world"
    assert sanitized["list_data"][0]["token"] == "***REDACTED***"
    assert sanitized["list_data"][1]["safe_item"] == "ok"


def test_json_formatter_valid_structure():
    formatter = JsonFormatter(log_type="audit", node_id="test-node")
    record = MockRecord("Test audit message", context={"human_uid": "user1", "secret_token": "hidden"})
    output = formatter.format(record)

    parsed = json.loads(output)
    assert parsed["log_type"] == "audit"
    assert parsed["node_id"] == "test-node"
    assert parsed["human_uid"] == "user1"
    assert parsed["secret_token"] == "***REDACTED***"


# --- 5. ADAPTER & RESILIENCE TESTS ---

def test_mock_adapter_non_existent_execution_lookup():
    adapter = MockAdapter()
    with pytest.raises(AdapterError):
        adapter.get_execution_status("NON_EXISTENT_EXEC_999")


# --- 6. END-TO-END INTEGRATION FLOW ---

def test_full_authorized_flow_with_audit(tmp_path):
    app = create_app()
    app.config["TESTING"] = True
    client = app.test_client()

    payload = {
        "project_name": "ProjectA",
        "release_name": "Phase3-Test-Release",
        "execution_role": "DEV",
        "classification_tag": "dev",
    }

    res = client.post(
        "/api/v1/execute",
        data=json.dumps(payload),
        content_type="application/json",
        headers={
            "X-Remote-User": "test_phase3_user",
            "X-Remote-Groups": "DAI_ProjectA_DEV",
        },
    )

    assert res.status_code == 202
    data = res.get_json()
    exec_id = data["execution_id"]

    # Verify status transition
    res_status = client.get(f"/api/v1/execution/{exec_id}")
    assert res_status.status_code == 200
    assert res_status.get_json()["status"] == "COMPLETED"
