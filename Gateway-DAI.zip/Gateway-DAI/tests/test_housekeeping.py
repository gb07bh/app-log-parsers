import json
import pytest
from pathlib import Path
from app import create_app
from app.config import HousekeepingConfig, LoggingConfig
from app.housekeeping import HousekeepingManager


def test_housekeeping_status_and_disk_health(tmp_path):
    log_dir = tmp_path / "logs"
    log_dir.mkdir()
    (log_dir / "audit.log").write_text("sample log line\n")

    hk_config = HousekeepingConfig(enabled=True, retention_days=30, max_log_size_mb=50)
    log_config = LoggingConfig(dir="logs", audit_file="audit.log")

    manager = HousekeepingManager(hk_config, log_config, base_dir=tmp_path)
    status = manager.get_status()

    assert status["enabled"] is True
    assert status["retention_days"] == 30
    assert "disk_health" in status
    assert len(status["log_files"]) == 1


def test_housekeeping_log_rotation(tmp_path):
    log_dir = tmp_path / "logs"
    log_dir.mkdir()
    audit_file = log_dir / "audit.log"
    
    # Write 100KB dummy data
    audit_file.write_bytes(b"A" * (100 * 1024))

    # Set threshold to 0.05MB (~51KB) so rotation is triggered
    hk_config = HousekeepingConfig(enabled=True, retention_days=30, max_log_size_mb=0.05)
    log_config = LoggingConfig(dir="logs", audit_file="audit.log")

    manager = HousekeepingManager(hk_config, log_config, base_dir=tmp_path)
    res = manager.rotate_and_clean_logs(dry_run=False)

    assert len(res["rotated"]) == 1
    assert res["rotated"][0].startswith("audit_")
    # Verify original log file was truncated
    assert audit_file.stat().st_size == 0


def test_housekeeping_api_endpoints():
    app = create_app()
    app.config["TESTING"] = True
    client = app.test_client()

    res_status = client.get("/api/v1/housekeeping/status")
    assert res_status.status_code == 200
    data = res_status.get_json()
    assert data["enabled"] is True

    res_run = client.post("/api/v1/housekeeping/run?dry_run=true")
    assert res_run.status_code == 200
    data_run = res_run.get_json()
    assert data_run["dry_run"] is True
