import pytest
from flask import Flask
from app.config import IdentityConfig, AuthConfig, ClassificationConfig
from app.identity import IdentityNormalizer
from app.auth import AuthorizationEvaluator, AuthorizationError, ReleaseClassificationError
from app.models import UserIdentity, ReleaseExecutionRequest


def test_identity_extraction_from_headers():
    config = IdentityConfig(header_user="X-Remote-User", header_groups="X-Remote-Groups", group_prefix="DAI_")
    normalizer = IdentityNormalizer(config)

    app = Flask(__name__)
    with app.test_request_context(
        headers={
            "X-Remote-User": "john_doe",
            "X-Remote-Groups": "DAI_ProjectA_DEV,DAI_ProjectA_APS,DAI_ProjectB_AUDIT",
        }
    ):
        from flask import request
        identity = normalizer.extract_identity(request)
        assert identity.username == "john_doe"
        assert identity.projects == {
            "ProjectA": ["DEV", "APS"],
            "ProjectB": ["AUDIT"],
        }
        assert identity.has_role("ProjectA", "DEV") is True
        assert identity.has_role("ProjectA", "APS") is True
        assert identity.has_role("ProjectB", "DEV") is False


def test_authorization_evaluator_success():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev"], "APS": ["prod"]}),
    )

    user = UserIdentity(
        username="alice",
        display_name="Alice",
        raw_groups=["DAI_ProjectA_DEV"],
        projects={"ProjectA": ["DEV"]},
    )

    req = ReleaseExecutionRequest(
        project_name="ProjectA",
        release_name="Rel-1",
        execution_role="DEV",
        classification_tag="dev",
    )

    is_auth, sa, reason = auth_eval.evaluate_execution_request(user, req)
    assert is_auth is True
    assert sa == "projecta_dev_sa"


def test_authorization_evaluator_lacks_role():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev"], "APS": ["prod"]}),
    )

    user = UserIdentity(
        username="bob",
        display_name="Bob",
        raw_groups=["DAI_ProjectA_DEV"],
        projects={"ProjectA": ["DEV"]},
    )

    # Bob requests APS role execution, but only holds DEV role
    req = ReleaseExecutionRequest(
        project_name="ProjectA",
        release_name="Rel-1",
        execution_role="APS",
        classification_tag="prod",
    )

    with pytest.raises(AuthorizationError):
        auth_eval.evaluate_execution_request(user, req)


def test_authorization_evaluator_unclassified_fails_closed():
    auth_eval = AuthorizationEvaluator(
        auth_config=AuthConfig(eval_roles=["DEV", "APS"]),
        class_config=ClassificationConfig(allowed_tags={"DEV": ["dev"], "APS": ["prod"]}),
    )

    user = UserIdentity(
        username="alice",
        display_name="Alice",
        raw_groups=["DAI_ProjectA_DEV"],
        projects={"ProjectA": ["DEV"]},
    )

    # Missing / unauthorized classification tag
    req = ReleaseExecutionRequest(
        project_name="ProjectA",
        release_name="Rel-1",
        execution_role="DEV",
        classification_tag="unauthorized_tag",
    )

    with pytest.raises(ReleaseClassificationError):
        auth_eval.evaluate_execution_request(user, req)
