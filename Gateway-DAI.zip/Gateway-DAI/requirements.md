# Gateway Requirements

## Purpose
Controlled release gateway for Digital.ai and other downstream APIs with human auditability and project-scoped service accounts.

## Access
- Gateway URL: DEV/APS release execution.
- Direct Digital.ai URL: Designer/Audit activities.
- Human authentication: corporate SSO.
- ALB, SSO and Apache HTTPD are existing infrastructure and outside Gateway implementation scope.
- LDAP/SSO groups determine project and role membership.

## Project Model
- Each project is an application boundary.
- Each project has DEV, APS and AUDIT service accounts plus two Designer licenses.
- A human may belong to multiple projects and multiple roles within a project.
- Gateway execution authorization evaluates DEV and APS.
- Designer/Audit permissions are primarily handled by Digital.ai.

## Execution
- DEV users may trigger DEV-classified releases/pipelines.
- APS users may trigger APS/release-classified releases/pipelines.
- Service account is selected from project + execution role.
- Jira/ServiceNow validation is handled by Digital.ai workflows, not the Gateway.
- Release classification is abstracted; Digital.ai tags are the initial candidate.
- Unknown/unclassified releases fail closed.
- Downstream integrations use replaceable adapters.
- Mock/custom endpoint is used to validate Gateway behavior before Digital.ai connectivity.

## Audit
- Capture human UID/name, project, role, action, release, service account, timestamp, request/correlation ID, downstream execution ID and result.
- Add human-trigger context to Digital.ai execution comments.
- Human identity originates from the Gateway and cannot be supplied/overridden downstream.

## Logging
- Mandatory local logging, independent of external aggregation.
- `audit.log`: security/business audit.
- `console.log`: HTTP/API activity.
- `service.log`: internal technical/service activity.
- Structured JSON with common request/correlation ID.
- Never log passwords, tokens, cookies, credentials or other secrets.
- Paths, filenames and levels are YAML-configurable.

## Configuration
- YAML-driven configuration.
- No environment-specific values hard-coded in Python.
- Secrets are not stored in YAML.
- `getCred` is the credential provider.
- Infrastructure credentials may resolve at startup.
- Project/service-account credentials resolve on demand.

## Operations
- Initial deployment: one Linux Gateway server.
- Must support adding identical Gateway nodes behind the existing ALB without application redesign.
- PostgreSQL is the shared production database.
- One `startup.sh` controls local lifecycle.
- Lifecycle operations use `flock`.
- Run as a non-root Linux user.
- Local logs remain available without external aggregation.

## Technology
- Python 3.9 or 3.10 only.
- Flask, Gunicorn, Jinja2.
- HTML/CSS with minimal vanilla JavaScript.
- SQLAlchemy, Alembic, PostgreSQL, psycopg.
- PyYAML, Pydantic, httpx, pytest.

## V1 Exclusions
- Team-to-team template sharing.
- Gateway-side Jira/ServiceNow validation.
- Generic Digital.ai API proxying.
- React, Angular, Vue or other frontend frameworks.
- Microservices unless explicitly approved.
