# Deployment & Jinja Templating Guide

This guide details how to deploy the Gateway across environments (DEV, STAGING, PROD) using Jinja runtime configuration templates via deployment automation tools (Ansible, Terraform, Helm, or custom scripts).

---

## 1. Overview of Configuration Management

The Gateway reads `config/gateway.yaml` at startup. During deployment, automation pipelines render `gateway.yaml.j2` into `gateway.yaml` with environment-specific values.

---

## 2. Jinja Configuration Template (`config/gateway.yaml.j2`)

```yaml
server:
  host: "{{ gateway_bind_host | default('0.0.0.0') }}"
  port: {{ gateway_port | default(8080) }}
  node_id: "{{ gateway_node_id }}"

logging:
  dir: "{{ gateway_log_dir | default('logs') }}"
  audit_file: "audit.log"
  console_file: "console.log"
  service_file: "service.log"
  level: "{{ gateway_log_level | default('INFO') }}"

identity:
  header_user: "{{ sso_header_user | default('X-Remote-User') }}"
  header_groups: "{{ sso_header_groups | default('X-Remote-Groups') }}"
  group_prefix: "{{ sso_group_prefix | default('DAI_') }}"

auth:
  eval_roles:
    - "DEV"
    - "APS"

classification:
  default_provider: "tags"
  allowed_tags:
    DEV:
      - "dev"
      - "development"
      - "sandbox"
    APS:
      - "aps"
      - "prod"
      - "production"
      - "release"

adapters:
  active: "{{ gateway_active_adapter | default('mock') }}"
  timeout_seconds: {{ adapter_timeout | default(30) }}

database:
  host: "{{ db_host }}"
  port: {{ db_port | default(5432) }}
  name: "{{ db_name }}"
  user: "{{ db_user }}"
  password: "{{ db_password }}"
  pool_size: {{ db_pool_size | default(10) }}
  max_overflow: {{ db_max_overflow | default(20) }}
  pool_timeout: {{ db_pool_timeout | default(30) }}
  pool_recycle: {{ db_pool_recycle | default(1800) }}
```

---

## 3. Example Ansible Deployment Task

```yaml
- name: Render gateway.yaml from Jinja template
  ansible.builtin.template:
    src: gateway.yaml.j2
    dest: /opt/release-gateway/config/gateway.yaml
    owner: gatewayusr
    group: gatewayusr
    mode: '0640'

- name: Validate rendered configuration
  ansible.builtin.command:
    cmd: /opt/release-gateway/scripts/startup.sh validate-config
  become: true
  become_user: gatewayusr

- name: Restart Gateway Service
  ansible.builtin.command:
    cmd: /opt/release-gateway/scripts/startup.sh restart
  become: true
  become_user: gatewayusr
```

---

## 4. Post-Deployment Verification

After rendering `gateway.yaml` and starting the service, execute readiness validation:
```bash
# 1. Check HTTP health
curl -s http://localhost:8080/health

# 2. Check Database & Adapter readiness
curl -s http://localhost:8080/ready

# 3. Execute Phase 3 core validation CLI runner
python /opt/release-gateway/scripts/validate_phase3.py
```
