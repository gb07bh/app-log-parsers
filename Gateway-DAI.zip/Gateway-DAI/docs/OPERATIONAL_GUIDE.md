# Gateway Technical & Operational Guide

This document provides a comprehensive operational, configuration, testing, and architectural reference for the **Digital.ai Release Gateway**.

---

## Table of Contents
1. [Installation Guide & Environment Requirements](#1-installation-guide--environment-requirements)
2. [Application Startup & Process Control](#2-application-startup--process-control)
3. [Network Ports Used](#3-network-ports-used)
4. [File & Directory Structure & Importance](#4-file--directory-structure--importance)
5. [Testing Standalone Items (APIs, Adapters, Integration, DB Pooling)](#5-testing-standalone-items-apis-adapters-integration-db-pooling)
6. [Database Connection & Pooling Setup](#6-database-connection--pooling-setup)
7. [`gateway.yaml` Complete Reference & Jinja Template Support](#7-gatewayyaml-complete-reference--jinja-template-support)
8. [Secrets & Credential Resolver Mechanism](#8-secrets--credential-resolver-mechanism)
9. [Logging & Audit Trail Architecture](#9-logging--audit-trail-architecture)
10. [Troubleshooting & Common Failure Modes](#10-troubleshooting--common-failure-modes)
11. [Housekeeping & Maintenance Operations](#11-housekeeping--maintenance-operations)

---

## 1. Installation Guide & Environment Requirements

### Operating System Requirements
- Supported Deployment Target: Linux (RHEL 8+, Ubuntu 20.04+, Enterprise Linux) running as a dedicated non-root user.
- Development / Testing Target: Linux, macOS, or Windows (WSL2 / PowerShell).

### Python Version Constraints
- **Python 3.9 or 3.10 ONLY**.
- Code must not rely on Python >3.10 standard library features or syntax.

### Core Dependencies ([requirements.txt](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/requirements.txt))
- `Flask` (>=2.0.0, <3.0.0): Core web framework for UI blueprints and REST APIs.
- `PyYAML` (>=6.0): YAML configuration parser.
- `pydantic` (>=2.0.0): Configuration schema validation and data models.
- `httpx` (>=0.23.0): Async/sync HTTP client for external adapter requests.
- `pytest` (>=7.0.0): Unit, integration, and security test framework.
- `SQLAlchemy` (>=1.4.0): Database ORM and connection pool manager.
- `psycopg2-binary` or `psycopg`: PostgreSQL database adapter driver.
- `alembic`: Database schema migration tool.

### Environment Setup Procedure
```bash
# 1. Clone repository to installation directory (e.g. /opt/release-gateway)
cd /opt/release-gateway

# 2. Create isolated Python virtual environment
python3.10 -m venv venv

# 3. Activate virtual environment
source venv/bin/activate

# 4. Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 2. Application Startup & Process Control

The application lifecycle is strictly managed via [scripts/startup.sh](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/scripts/startup.sh). 

### Command Usage
```bash
./scripts/startup.sh {start|stop|restart|status|health|validate-config|housekeeping}
```

| Action | Description |
| :--- | :--- |
| `start` | Validates YAML config, acquires lock (`run/gateway.lock`), launches Gunicorn daemon with 4 workers on port 8080, writes PID to `run/gateway.pid`. |
| `stop` | Sends SIGTERM (15) to PID recorded in `run/gateway.pid` and cleans up PID file. |
| `restart` | Stops existing daemon, waits 2 seconds, and executes `start`. |
| `status` | Checks if process recorded in `gateway.pid` is actively running. Returns exit code `0` if active, `1` if stopped. |
| `health` | Executes HTTP request to local readiness endpoint (`http://localhost:8080/health`). |
| `validate-config` | Parses `config/gateway.yaml` against Pydantic schema and exits `0` on valid, `1` on error. |
| `housekeeping` | Runs the automated log rotation, expired database record purge, and lock cleanup routine. |

---

## 3. Network Ports Used

| Port | Protocol | Usage | Direction | Config Location |
| :--- | :--- | :--- | :--- | :--- |
| **8080** | TCP (HTTP) | Gateway Application Server (Gunicorn / Flask) receiving traffic from Apache HTTPD. | Inbound | `gateway.yaml` $\rightarrow$ `server.port` |
| **5432** | TCP (PostgreSQL) | Outbound connection to shared PostgreSQL database cluster. | Outbound | `gateway.yaml` $\rightarrow$ `database.port` |
| **443** | TCP (HTTPS) | Outbound calls to downstream Digital.ai or Jenkins APIs (via Adapters). | Outbound | Adapter config |

---

## 4. File & Directory Structure & Importance

```text
/opt/release-gateway/
├── app/
│   ├── __init__.py           # Flask app factory, correlation middleware, error handlers
│   ├── config.py             # YAML loader, Pydantic schema validation, CredentialResolver
│   ├── database.py           # SQLAlchemy engine setup, pooling, models, health check
│   ├── housekeeping.py       # HousekeepingManager for log rotation, DB purging, disk checks
│   ├── identity.py           # SSO header extraction & user normalization
│   ├── auth.py               # Server-side authorization & fail-closed classification
│   ├── audit.py              # Structured business & security audit logger
│   ├── logging.py            # Structured JSON formatter, loggers, secret redactor
│   ├── models.py             # UserIdentity, Project, ReleaseExecution dataclasses
│   ├── adapters/
│   │   ├── base.py           # Abstract BaseAdapter contract & vendor exceptions
│   │   ├── mock_adapter.py   # Mock adapter simulating pipeline executions
│   │   └── factory.py        # Adapter factory registry
│   ├── routes/
│   │   ├── ui.py             # Flask UI routes (dashboard, execution views)
│   │   └── api.py            # REST API blueprints (/api/v1/execute, /health, /ready, /housekeeping)
│   └── templates/
│       ├── base.html         # Base Jinja2 layout template
│       ├── dashboard.html    # Dashboard displaying SSO user details & trigger UI
│       └── execution.html    # Execution status polling view
├── config/
│   └── gateway.yaml          # Master environment configuration (templateable via Jinja)
├── docs/
│   ├── OPERATIONAL_GUIDE.md  # Detailed operational, configuration & testing documentation
│   ├── API_REFERENCE.md      # REST API endpoints & schema documentation
│   ├── ADAPTER_DEVELOPMENT_GUIDE.md # Custom downstream adapter guide
│   └── DEPLOYMENT_AND_JINJA_TEMPLATING.md # Jinja deployment templating guide
├── logs/
│   ├── audit.log             # Human UID, action, project, role, service account audit log
│   ├── console.log           # HTTP request/response metrics log
│   └── service.log           # Internal service lifecycle & technical event log
├── run/
│   ├── gateway.lock          # Flock lockfile preventing duplicate startup
│   └── gateway.pid           # Active Gunicorn daemon process ID file
├── scripts/
│   ├── startup.sh            # Production process lifecycle management script
│   ├── housekeeping.py       # Standalone maintenance CLI utility
│   └── validate_phase3.py    # Independent CLI validation runner
├── tests/
│   ├── test_adapters.py      # Unit tests for MockAdapter & factory
│   ├── test_config.py        # Unit tests for YAML loading & CredentialResolver
│   ├── test_database.py      # Unit tests for DatabaseConfig & DatabaseManager
│   ├── test_housekeeping.py  # Unit tests for HousekeepingManager & maintenance
│   ├── test_identity_auth.py # Unit tests for SSO extraction & authorization checks
│   ├── test_phase3_validation.py # Core Phase 3 security & validation test matrix
│   └── test_routes.py        # Integration tests for UI rendering & REST APIs
├── architecture.md           # System boundary & architectural specifications
├── code-rules.md             # Mandatory implementation rules & constraints
├── requirements.md           # Business & technical requirements specification
└── requirements.txt          # Python package dependency manifests
```

---

## 5. Testing Standalone Items (APIs, Adapters, Integration, DB Pooling)

### A. Standalone Automated Test Execution
Run the complete test suite:
```bash
python -m pytest tests/ -v
```

Run the standalone CLI validation runner:
```bash
python scripts/validate_phase3.py
```

### B. Standalone REST API Testing
Once the application is running locally (`python -c "from app import create_app; app = create_app(); app.run(port=8080)"`), test the endpoints standalone via `curl`:

1. **Health Check Endpoint**:
   ```bash
   curl -s http://localhost:8080/health
   # Response: {"status":"UP","service":"Gateway-DAI","node_id":"gateway-node-01"}
   ```

2. **Readiness Check Endpoint**:
   ```bash
   curl -s http://localhost:8080/ready
   # Response: {"status":"READY","adapter_health":{"status":"HEALTHY"},"database_health":{"status":"HEALTHY"}}
   ```

3. **Housekeeping Status API**:
   ```bash
   curl -s http://localhost:8080/api/v1/housekeeping/status
   ```

4. **Trigger On-Demand Housekeeping API**:
   ```bash
   curl -s -X POST http://localhost:8080/api/v1/housekeeping/run?dry_run=true
   ```

---

## 6. Database Connection & Pooling Setup

PostgreSQL is the mandatory persistent storage engine for production shared Gateway state (audit logs, execution records, node coordination).

### Connection Pooling Parameters in `gateway.yaml`
```yaml
database:
  host: "localhost"
  port: 5432
  name: "gateway_db"
  user: "gateway_user"
  password: "gateway_password"
  pool_size: 10
  max_overflow: 20
  pool_timeout: 30
  pool_recycle: 1800
```

---

## 7. `gateway.yaml` Complete Reference & Jinja Template Support

`gateway.yaml` is designed to be rendered from a Jinja template during deployment automation (Ansible/Terraform/Helm), populating environment-specific values at runtime.

```yaml
server:
  host: "0.0.0.0"
  port: 8080
  node_id: "gateway-node-01"

logging:
  dir: "logs"
  audit_file: "audit.log"
  console_file: "console.log"
  service_file: "service.log"
  level: "INFO"

identity:
  header_user: "X-Remote-User"
  header_groups: "X-Remote-Groups"
  group_prefix: "DAI_"

auth:
  eval_roles:
    - "DEV"
    - "APS"

classification:
  default_provider: "tags"
  allowed_tags:
    DEV:
      - "dev"
      - "development"
      - "sandbox"
    APS:
      - "aps"
      - "prod"
      - "production"
      - "release"

adapters:
  active: "mock"
  timeout_seconds: 30
  mock:
    simulate_delay_seconds: 0.1

database:
  host: "localhost"
  port: 5432
  name: "gateway_db"
  user: "gateway_user"
  password: "gateway_password"
  pool_size: 10
  max_overflow: 20
  pool_timeout: 30
  pool_recycle: 1800

housekeeping:
  enabled: true
  retention_days: 30
  max_log_size_mb: 50
  max_disk_usage_percent: 85
  auto_rotate_logs: true
```

---

## 8. Secrets & Credential Resolver Mechanism

Secrets are resolved dynamically at runtime using `CredentialResolver` calling `getCred`. Credentials must never be written into `gateway.yaml`.

---

## 9. Logging & Audit Trail Architecture

The Gateway maintains 3 dedicated JSON log files: `audit.log`, `console.log`, and `service.log`. Sensitive context fields are automatically redacted.

---

## 10. Troubleshooting & Common Failure Modes

| Symptom / Error | Root Cause | Solution |
| :--- | :--- | :--- |
| **HTTP 403 Forbidden**: `User lacks required role` | Missing SSO group membership. | Verify user LDAP group or choose authorized role. |
| **HTTP 502 Bad Gateway**: `Adapter error` | Downstream endpoint unreachable or timeout (>30s). | Check downstream network connectivity. |
| **Disk Warning in Health**: `percent_used > 85%` | Log partition disk space exceeding 85% capacity. | Run `./scripts/startup.sh housekeeping` or check retention settings. |

---

## 11. Housekeeping & Maintenance Operations

Automated maintenance ensures log files are rotated, database tables do not grow unbounded, unheld process locks are cleared, and disk capacity is monitored.

### Key Maintenance Functions
1. **Log File Rotation & Archiving**: Active log files exceeding `max_log_size_mb` (default 50MB) are automatically compressed into `.zip` archives. Archives older than `retention_days` (default 30 days) are purged.
2. **Database Record Purge**: Audit entries in `gateway_audit_logs` and execution entries in `gateway_execution_records` older than `retention_days` are purged.
3. **Stale Lock Cleanup**: Unheld `.lock` files in `run/` are removed.
4. **Disk Utilization Monitoring**: Monitors log partition usage and flags warnings when usage exceeds `max_disk_usage_percent` (default 85%).

### Housekeeping CLI Commands
```bash
# 1. Preview housekeeping operations (Dry-Run mode)
python scripts/housekeeping.py --dry-run

# 2. Execute full housekeeping cleanup
python scripts/housekeeping.py

# 3. View housekeeping status report
python scripts/housekeeping.py --status

# 4. Trigger via startup lifecycle script
./scripts/startup.sh housekeeping
```

### Recommended Crontab Setup
To schedule daily housekeeping cleanup at 02:00 AM:
```cron
0 2 * * * /opt/release-gateway/scripts/startup.sh housekeeping >> /opt/release-gateway/logs/service.log 2>&1
```
