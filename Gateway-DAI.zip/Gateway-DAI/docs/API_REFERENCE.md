# Gateway REST API Reference

This document provides a detailed API specification for all REST endpoints exposed by the Digital.ai Release Gateway.

---

## Global Request Headers

| Header Name | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| `X-Remote-User` | String | User UID passed by Apache SSO. | `john_doe` |
| `X-Remote-Groups` | String | Comma or semicolon-separated LDAP groups list. | `DAI_ProjectA_DEV,DAI_ProjectA_APS` |
| `X-Correlation-ID` | String | (Optional) Incoming correlation ID. Auto-generated if omitted. | `c4a8f1e2-9b3d-4e5f-8a0c-1b2c3d4e5f6a` |
| `Content-Type` | String | Required for POST requests (`application/json`). | `application/json` |

---

## Global Response Headers

| Header Name | Description | Example |
| :--- | :--- | :--- |
| `X-Request-ID` | Request correlation ID propagated across all log streams. | `c4a8f1e2-9b3d-4e5f-8a0c-1b2c3d4e5f6a` |

---

## Endpoints Summary

1. `GET /health` - Application Liveness Health
2. `GET /ready` - Service & Dependency Readiness Check
3. `GET /api/v1/user` - Authenticated User Identity Profile
4. `POST /api/v1/execute` - Trigger Release Execution
5. `GET /api/v1/execution/{execution_id}` - Retrieve Release Execution Status

---

## 1. Application Liveness Health

Checks whether the Flask/Gunicorn gateway process is alive.

- **URL**: `/health`
- **Method**: `GET`
- **Authentication**: None required.

### Response (200 OK)
```json
{
  "node_id": "gateway-node-01",
  "service": "Gateway-DAI",
  "status": "UP"
}
```

---

## 2. Dependency Readiness Check

Evaluates the health of the database pool and downstream adapter connectivity.

- **URL**: `/ready`
- **Method**: `GET`
- **Authentication**: None required.

### Response (200 OK)
```json
{
  "status": "READY",
  "adapter_health": {
    "active_mock_executions": 2,
    "adapter": "MockAdapter",
    "status": "HEALTHY"
  },
  "database_health": {
    "database": "gateway_db",
    "engine": "sqlite",
    "host": "localhost",
    "pool_size": 10,
    "port": 5432,
    "status": "HEALTHY"
  }
}
```

---

## 3. Authenticated User Identity Profile

Returns normalized identity details and project roles parsed from SSO headers.

- **URL**: `/api/v1/user`
- **Method**: `GET`
- **Headers Required**: `X-Remote-User`, `X-Remote-Groups`

### Response (200 OK)
```json
{
  "display_name": "John Doe",
  "projects": {
    "ProjectA": ["DEV", "APS"],
    "ProjectB": ["AUDIT"]
  },
  "raw_groups": [
    "DAI_ProjectA_DEV",
    "DAI_ProjectA_APS",
    "DAI_ProjectB_AUDIT"
  ],
  "username": "john_doe"
}
```

---

## 4. Trigger Release Execution

Triggers a downstream release execution after evaluating server-side authorization and release classification.

- **URL**: `/api/v1/execute`
- **Method**: `POST`
- **Headers Required**: `X-Remote-User`, `X-Remote-Groups`, `Content-Type: application/json`

### Request Body Schema
```json
{
  "project_name": "ProjectA",
  "release_name": "Release-v1.0.0",
  "execution_role": "DEV",
  "classification_tag": "dev"
}
```

| Parameter | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `project_name` | String | Yes | Target project boundary (e.g. `ProjectA`). |
| `release_name` | String | Yes | Pipeline or release identifier. |
| `execution_role` | String | Yes | Execution role requested (`DEV` or `APS`). |
| `classification_tag` | String | Yes | Release tag for environment classification (`dev`, `aps`, `prod`). |

### Response Success (202 Accepted)
```json
{
  "details": {
    "classification_tag": "dev",
    "downstream_provider": "MockEngine",
    "execution_comment": "Triggered by Gateway user 'john_doe' (ReqID: c4a8f1e2-9b3d-4e5f-8a0c-1b2c3d4e5f6a)"
  },
  "execution_id": "MOCK-EXEC-A1B2C3D4",
  "message": "Mock release execution successfully triggered. Triggered by Gateway user 'john_doe' (ReqID: c4a8f1e2-9b3d-4e5f-8a0c-1b2c3d4e5f6a)",
  "project_name": "ProjectA",
  "release_name": "Release-v1.0.0",
  "request_id": "c4a8f1e2-9b3d-4e5f-8a0c-1b2c3d4e5f6a",
  "service_account": "projecta_dev_sa",
  "status": "IN_PROGRESS"
}
```

### Response Error: Unauthorized Role (403 Forbidden)
```json
{
  "error": "User 'john_doe' lacks required role 'APS' for project 'ProjectA'"
}
```

### Response Error: Classification Fail-Closed (403 Forbidden)
```json
{
  "error": "Release classification tag 'unauthorized' is not authorized for role 'DEV'. Allowed tags: ['dev', 'development', 'sandbox']"
}
```

---

## 5. Retrieve Release Execution Status

Polls status for an existing release execution.

- **URL**: `/api/v1/execution/{execution_id}`
- **Method**: `GET`

### Response (200 OK)
```json
{
  "created_at": "2026-08-27T00:00:00+00:00",
  "execution_id": "MOCK-EXEC-A1B2C3D4",
  "message": "Mock release execution completed successfully",
  "project_name": "ProjectA",
  "release_name": "Release-v1.0.0",
  "service_account": "projecta_dev_sa",
  "status": "COMPLETED"
}
```

### Response Error (404 Not Found)
```json
{
  "error": "Mock execution ID 'INVALID_ID' not found"
}
```
