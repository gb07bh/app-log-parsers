# Adapter Development & Digital.ai Guide

This guide details the downstream release adapter framework and the production **DigitalAIAdapter** implementation.

---

## 1. Adapter Architectural Principles

1. **Vendor Neutrality**: Core Gateway business logic contains zero vendor-specific API calls. All integrations subclass `BaseAdapter`.
2. **No Auth/Identity Logic**: Adapters contain no Gateway authorization checks and do not determine human identity. Authorization and identity extraction are completed server-side prior to calling the adapter.
3. **AccessToken Authentication**: Digital.ai requests authenticate via `AccessToken` format (`Authorization: Bearer <token>`), dynamically resolved via `CredentialResolver` using project/role service account identifiers.
4. **Mandatory Human Context**: Every trigger payload automatically propagates the mandatory execution comment `Triggered by user {user_name}` (where `{user_name}` is the normalized SSO identity).
5. **Error Normalization**: Translates downstream HTTP status errors and connection failures into Gateway exception types (`AdapterError`, `AdapterConnectionError`, `AdapterTimeoutError`).

---

## 2. DigitalAIAdapter Implementation Details ([app/adapters/digitalai_adapter.py](file:///d:/BNP_Code/DigitalAI-Release/Gateway-DAI/app/adapters/digitalai_adapter.py))

```python
from app.adapters.digitalai_adapter import DigitalAIAdapter
from app.adapters.factory import AdapterFactory
from app.models import ReleaseExecutionRequest, UserIdentity

# Configured in gateway.yaml:
# adapters:
#   active: "digitalai"
#   digitalai:
#     url: "https://digitalai.company.internal"
#     trigger_path: "/api/v1/releases/trigger"
#     status_path: "/api/v1/releases/executions"

adapter = AdapterFactory.create_adapter(config.adapters)
```

### Outgoing HTTP POST Request Schema
- **Target URL**: `{digitalai_url}/api/v1/releases/trigger`
- **Headers**:
  ```http
  Authorization: Bearer <service_account_cred>
  X-Correlation-ID: <request_correlation_id>
  Content-Type: application/json
  Accept: application/json
  ```
- **Payload Schema**:
  ```json
  {
    "releaseTitle": "Release-v2.5",
    "project": "ProjectX",
    "executionRole": "DEV",
    "tags": ["dev"],
    "comment": "Triggered by user sarah_connor",
    "parameters": {}
  }
  ```

---

## 3. Registering Custom Adapters

To register additional custom adapters (e.g., Jenkins or ServiceNow):

```python
from app.adapters.factory import AdapterFactory
from app.adapters.base import BaseAdapter

class CustomJenkinsAdapter(BaseAdapter):
    # Implement trigger_release, get_execution_status, check_health
    pass

AdapterFactory.register_adapter("jenkins", CustomJenkinsAdapter)
```
