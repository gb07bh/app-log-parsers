# Gateway Code Rules

## Architecture
- One modular Flask application; no microservices without explicit approval.
- Keep modules loosely coupled.
- Use interfaces/contracts for replaceable integrations.
- Business logic must not directly call vendor APIs.

## Python
- Support Python 3.9 and 3.10 only.
- Do not use syntax, standard-library APIs or dependencies requiring Python >3.10.
- Prefer type hints and small focused modules.
- Avoid global mutable state.

## UI
- Flask + Jinja2.
- HTML/CSS + minimal vanilla JavaScript.
- No React, Angular, Vue, Node.js or frontend build pipeline without explicit approval.

## Configuration
- YAML for environment-specific configuration.
- Validate configuration at startup.
- Fail startup on invalid required configuration.
- No environment-specific values hard-coded in Python.
- No secrets in YAML.

## Secrets
- Use a `CredentialResolver` abstraction.
- `CredentialResolver` calls `getCred`.
- Never hard-code or log credentials.
- Never return credentials through APIs.
- Infrastructure credentials may resolve at startup.
- Project/service-account credentials resolve on demand.

## Database
- PostgreSQL only for production.
- SQLAlchemy for DB access.
- Alembic for migrations.
- Keep DB access in the database layer.
- Use transactions for related audit/execution state changes.
- Use DB constraints for shared-state integrity.
- No SQLite for production.

## Authentication
- Trust only the approved SSO/Apache identity mechanism.
- Normalize external identity into an internal model.
- Never accept user identity from request bodies for authorization.
- Downstream systems cannot override Gateway identity.

## Authorization
- Always enforce authorization server-side.
- UI visibility is not authorization.
- Check project scope.
- Evaluate DEV and APS independently.
- Unknown permissions fail closed.
- Unknown release classification fails closed.

## Adapters
- Every downstream system uses an adapter.
- Adapter interfaces are vendor-neutral.
- Adapters contain no Gateway authorization logic.
- Adapters do not determine human identity.
- Map downstream errors into Gateway-defined error types.
- Mock adapters must work without Digital.ai.

## Logging
- Structured JSON.
- Every request gets a request ID.
- `audit.log` = business/security audit.
- `console.log` = HTTP/API activity.
- `service.log` = technical/service activity.
- Never log secrets, tokens, cookies or credentials.
- Do not log full request bodies by default.
- Logging failures must not crash the Gateway.

## Audit
- Record explicit business/security events.
- Record Gateway-derived human identity.
- Include project, role, action and request ID where applicable.
- Record downstream execution IDs when available.
- Do not depend on downstream systems for identity.

## Error Handling
- Never silently swallow exceptions.
- Use typed/application-specific exceptions where practical.
- Return safe user-facing errors.
- Log technical details server-side.
- Never expose stack traces.
- External calls require explicit timeouts.
- Downstream failures must not crash the application.

## Concurrency
- Code must be safe with multiple Gunicorn workers.
- Do not use process-local state for shared business data.
- Do not use in-memory locks for cross-node coordination.
- Use PostgreSQL constraints/transactions for shared state.

## Startup
- `startup.sh` is the only supported lifecycle entry point.
- Use `flock`.
- Validate configuration and required dependencies.
- Do not put business logic in `startup.sh`.
- Run Gunicorn, not Flask's development server.

## Testing
- Test modules independently.
- Mock downstream systems.
- Digital.ai must not be required for core tests.
- Test identity normalization, authorization, audit, adapters, configuration and logging.
- Test timeout, error and duplicate/concurrent paths.

## Maintainability
- Prefer simple solutions.
- Avoid unnecessary abstractions/dependencies.
- Avoid circular dependencies.
- Document non-obvious security decisions.
- Keep interfaces clear and typed where practical.

## Production
- No debug mode.
- No Flask development server.
- Run as non-root.
- Use least-privilege filesystem permissions.
- Health endpoints must not expose secrets.
- Design for single-node operation and future multi-node deployment.

## Documentation
- `requirements.md` defines requirements.
- `architecture.md` defines architecture.
- `code-rules.md` defines implementation constraints.
- Architectural changes require updating the relevant documents before implementation.
