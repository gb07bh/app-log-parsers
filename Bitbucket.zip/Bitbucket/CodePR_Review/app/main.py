import sys
import os
import argparse
import logging
from datetime import datetime, timezone

# Ensure project root is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.config.config_loader import load_config
from app.logging_config import configure_logging
from app.runner.scan_runner import ScanRunner
from app.reporting.models import (
    ReportData, ReportMetadata, RepoSummary, UserActivity, TimeseriesPoint
)
from app.storage.file_store import FileStore
from app.storage.artifactory import ArtifactoryClient


def run_mock_scan(config, month: str):
    """Generates a realistic mock report to verify pipeline and UI without live Bitbucket."""
    logger = logging.getLogger("runner.mock_scan")
    logger.info(f"Generating mock report for {month}...")

    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    since_date = f"{month}-01T00:00:00Z"
    parts = month.split("-")
    y, m = int(parts[0]), int(parts[1])
    until_date = f"{y if m < 12 else y+1}-{(m+1 if m < 12 else 1):02d}-01T00:00:00Z"

    metadata = ReportMetadata(
        job_id=f"mock-{month}-run01",
        trace_id="trace-mock-test01",
        generated_at=now_iso,
        period_start=since_date,
        period_end=until_date,
        projects_configured=["PAY", "CORE", "AUTH"],
        repository_limit=10,
        worker_count=5,
        status="COMPLETED",
        total_repositories=3,
        completed_repositories=3,
        failed_repositories=0,
        errors=[]
    )

    repos = [
        RepoSummary(
            project_key="PAY",
            project_name="Payments Platform",
            repo_slug="payment-gateway",
            repo_name="payment-gateway",
            commits=142,
            pull_requests=38,
            lines_added=12850,
            lines_deleted=3420,
            unique_commit_authors=4,
            unique_pr_authors=3,
            users=[
                UserActivity(user_id="john.doe", display_name="John Doe", commits=75, pull_requests=18, lines_added=6800, lines_deleted=1900),
                UserActivity(user_id="jane.smith", display_name="Jane Smith", commits=45, pull_requests=12, lines_added=3900, lines_deleted=1100),
                UserActivity(user_id="alice.wang", display_name="Alice Wang", commits=15, pull_requests=5, lines_added=1450, lines_deleted=310),
                UserActivity(user_id="bob.jones", display_name="Bob Jones", commits=7, pull_requests=3, lines_added=700, lines_deleted=110),
            ]
        ),
        RepoSummary(
            project_key="CORE",
            project_name="Core Services",
            repo_slug="ledger-service",
            repo_name="ledger-service",
            commits=89,
            pull_requests=24,
            lines_added=8450,
            lines_deleted=2100,
            unique_commit_authors=3,
            unique_pr_authors=2,
            users=[
                UserActivity(user_id="john.doe", display_name="John Doe", commits=40, pull_requests=10, lines_added=3800, lines_deleted=950),
                UserActivity(user_id="jane.smith", display_name="Jane Smith", commits=35, pull_requests=11, lines_added=3250, lines_deleted=850),
                UserActivity(user_id="charlie.brown", display_name="Charlie Brown", commits=14, pull_requests=3, lines_added=1400, lines_deleted=300),
            ]
        ),
        RepoSummary(
            project_key="AUTH",
            project_name="Identity & Access",
            repo_slug="oauth-server",
            repo_name="oauth-server",
            commits=64,
            pull_requests=19,
            lines_added=5600,
            lines_deleted=1450,
            unique_commit_authors=2,
            unique_pr_authors=2,
            users=[
                UserActivity(user_id="alice.wang", display_name="Alice Wang", commits=38, pull_requests=11, lines_added=3400, lines_deleted=900),
                UserActivity(user_id="bob.jones", display_name="Bob Jones", commits=26, pull_requests=8, lines_added=2200, lines_deleted=550),
            ]
        )
    ]

    # Generate daily points for overall timeline
    timeline = []
    for day in range(1, 29):
        day_str = f"{month}-{day:02d}"
        c_val = 8 + (day % 7) * 3
        pr_val = 2 + (day % 4)
        timeline.append(TimeseriesPoint(
            date=day_str,
            commits=c_val,
            pull_requests=pr_val,
            lines_added=c_val * 90,
            lines_deleted=c_val * 25
        ))

    # Build UserProfiles for mock data
    user_profiles = {}
    from collections import defaultdict
    user_data = defaultdict(lambda: {"commits": 0, "prs": 0, "lines_added": 0, "lines_deleted": 0, "display_name": "", "contribs": []})

    for r in repos:
        for u in r.users:
            user_data[u.user_id]["commits"] += u.commits
            user_data[u.user_id]["prs"] += u.pull_requests
            user_data[u.user_id]["lines_added"] += u.lines_added
            user_data[u.user_id]["lines_deleted"] += u.lines_deleted
            user_data[u.user_id]["display_name"] = u.display_name
            user_data[u.user_id]["contribs"].append(
                UserProjectContribution(
                    project_key=r.project_key,
                    project_name=r.project_name,
                    repo_slug=r.repo_slug,
                    repo_name=r.repo_name,
                    commits=u.commits,
                    pull_requests=u.pull_requests,
                    lines_added=u.lines_added,
                    lines_deleted=u.lines_deleted
                )
            )

    from app.reporting.models import (
        UserProfile, UserProjectContribution, ProjectProfile,
        ProjectRepoContribution, RepoProfile, EfficiencyMetrics
    )
    for uid, d in user_data.items():
        # User daily timeline points
        u_tl = []
        u_proj_tl = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            # distribute user commits roughly across days
            c_day = (d["commits"] // 28) + (1 if day <= (d["commits"] % 28) else 0)
            pr_day = (d["prs"] // 28) + (1 if day <= (d["prs"] % 28) else 0)
            la_day = (d["lines_added"] // 28) + (1 if day <= (d["lines_added"] % 28) else 0)
            ld_day = (d["lines_deleted"] // 28) + (1 if day <= (d["lines_deleted"] % 28) else 0)
            u_tl.append(TimeseriesPoint(date=day_str, commits=c_day, pull_requests=pr_day, lines_added=la_day, lines_deleted=ld_day))

            # Distribute per project
            for contrib in d["contribs"]:
                proj_c = (contrib.commits // 28) + (1 if day <= (contrib.commits % 28) else 0)
                proj_pr = (contrib.pull_requests // 28) + (1 if day <= (contrib.pull_requests % 28) else 0)
                proj_la = (contrib.lines_added // 28) + (1 if day <= (contrib.lines_added % 28) else 0)
                proj_ld = (contrib.lines_deleted // 28) + (1 if day <= (contrib.lines_deleted % 28) else 0)
                u_proj_tl[contrib.project_key].append(
                    TimeseriesPoint(date=day_str, commits=proj_c, pull_requests=proj_pr, lines_added=proj_la, lines_deleted=proj_ld)
                )

        user_profiles[uid] = UserProfile(
            user_id=uid,
            display_name=d["display_name"],
            email=f"{uid}@example.com",
            total_commits=d["commits"],
            total_pull_requests=d["prs"],
            lines_added=d["lines_added"],
            lines_deleted=d["lines_deleted"],
            timeline=u_tl,
            project_contributions=d["contribs"],
            project_timeline=dict(u_proj_tl)
        )

    # Build Project Profiles & Repo Profiles
    project_profiles = {}
    repo_profiles = {}
    proj_repos = defaultdict(list)
    for r in repos:
        proj_repos[r.project_key].append(r)

    for pkey, p_list in proj_repos.items():
        p_name = p_list[0].project_name
        p_commits = sum(r.commits for r in p_list)
        p_prs = sum(r.pull_requests for r in p_list)
        p_lines_added = sum(r.lines_added for r in p_list)
        p_lines_deleted = sum(r.lines_deleted for r in p_list)
        p_users = set()
        for r in p_list:
            for u in r.users:
                p_users.add(u.user_id)

        p_repo_contribs = [
            ProjectRepoContribution(
                repo_slug=r.repo_slug,
                repo_name=r.repo_name,
                commits=r.commits,
                pull_requests=r.pull_requests,
                lines_added=r.lines_added,
                lines_deleted=r.lines_deleted,
                unique_commit_authors=r.unique_commit_authors,
                unique_pr_authors=r.unique_pr_authors,
                users=r.users
            )
            for r in p_list
        ]

        # Project timeline
        p_tl = []
        p_repo_tl = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            c_tot = sum((r.commits // 28) + (1 if day <= (r.commits % 28) else 0) for r in p_list)
            pr_tot = sum((r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0) for r in p_list)
            la_tot = sum((r.lines_added // 28) + (1 if day <= (r.lines_added % 28) else 0) for r in p_list)
            ld_tot = sum((r.lines_deleted // 28) + (1 if day <= (r.lines_deleted % 28) else 0) for r in p_list)
            p_tl.append(TimeseriesPoint(date=day_str, commits=c_tot, pull_requests=pr_tot, lines_added=la_tot, lines_deleted=ld_tot))

            for r in p_list:
                r_c = (r.commits // 28) + (1 if day <= (r.commits % 28) else 0)
                r_pr = (r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0)
                r_la = (r.lines_added // 28) + (1 if day <= (r.lines_added % 28) else 0)
                r_ld = (r.lines_deleted // 28) + (1 if day <= (r.lines_deleted % 28) else 0)
                p_repo_tl[r.repo_slug].append(TimeseriesPoint(date=day_str, commits=r_c, pull_requests=r_pr, lines_added=r_la, lines_deleted=r_ld))

        project_profiles[pkey] = ProjectProfile(
            project_key=pkey,
            project_name=p_name,
            total_commits=p_commits,
            total_pull_requests=p_prs,
            total_repositories=len(p_list),
            total_active_users=len(p_users),
            lines_added=p_lines_added,
            lines_deleted=p_lines_deleted,
            timeline=p_tl,
            repo_contributions=p_repo_contribs,
            repo_timeline=dict(p_repo_tl)
        )

    for r in repos:
        r_tl = []
        u_tl_map = defaultdict(list)
        for day in range(1, 29):
            day_str = f"{month}-{day:02d}"
            r_c = (r.commits // 28) + (1 if day <= (r.commits % 28) else 0)
            r_pr = (r.pull_requests // 28) + (1 if day <= (r.pull_requests % 28) else 0)
            r_la = (r.lines_added // 28) + (1 if day <= (r.lines_added % 28) else 0)
            r_ld = (r.lines_deleted // 28) + (1 if day <= (r.lines_deleted % 28) else 0)
            r_tl.append(TimeseriesPoint(date=day_str, commits=r_c, pull_requests=r_pr, lines_added=r_la, lines_deleted=r_ld))

            for u in r.users:
                u_c = (u.commits // 28) + (1 if day <= (u.commits % 28) else 0)
                u_pr = (u.pull_requests // 28) + (1 if day <= (u.pull_requests % 28) else 0)
                u_la = (u.lines_added // 28) + (1 if day <= (u.lines_added % 28) else 0)
                u_ld = (u.lines_deleted // 28) + (1 if day <= (u.lines_deleted % 28) else 0)
                u_tl_map[u.user_id].append(TimeseriesPoint(date=day_str, commits=u_c, pull_requests=u_pr, lines_added=u_la, lines_deleted=u_ld))

        full_k = f"{r.project_key}/{r.repo_slug}"
        repo_profiles[full_k] = RepoProfile(
            project_key=r.project_key,
            project_name=r.project_name,
            repo_slug=r.repo_slug,
            repo_name=r.repo_name,
            total_commits=r.commits,
            total_pull_requests=r.pull_requests,
            lines_added=r.lines_added,
            lines_deleted=r.lines_deleted,
            unique_commit_authors=r.unique_commit_authors,
            unique_pr_authors=r.unique_pr_authors,
            total_active_users=len(r.users),
            timeline=r_tl,
            users=r.users,
            user_timeline=dict(u_tl_map)
        )

    tot_commits = sum(r.commits for r in repos)
    tot_prs = sum(r.pull_requests for r in repos)
    tot_la = sum(r.lines_added for r in repos)
    tot_ld = sum(r.lines_deleted for r in repos)
    num_repos = len(repos)
    num_proj = len(project_profiles)
    num_users = len(user_profiles)

    efficiency = EfficiencyMetrics(
        avg_commits_per_repo=round(tot_commits / num_repos, 2) if num_repos > 0 else 0.0,
        avg_commits_per_project=round(tot_commits / num_proj, 2) if num_proj > 0 else 0.0,
        avg_commits_per_user=round(tot_commits / num_users, 2) if num_users > 0 else 0.0,
        avg_prs_per_repo=round(tot_prs / num_repos, 2) if num_repos > 0 else 0.0,
        avg_prs_per_project=round(tot_prs / num_proj, 2) if num_proj > 0 else 0.0,
        avg_prs_per_user=round(tot_prs / num_users, 2) if num_users > 0 else 0.0,
        avg_lines_per_commit=round((tot_la + tot_ld) / tot_commits, 2) if tot_commits > 0 else 0.0,
        total_lines_added=tot_la,
        total_lines_deleted=tot_ld,
        net_lines_changed=tot_la - tot_ld
    )

    report = ReportData(
        metadata=metadata,
        total_commits=tot_commits,
        total_pull_requests=tot_prs,
        total_repositories=num_repos,
        total_active_users=num_users,
        total_lines_added=tot_la,
        total_lines_deleted=tot_ld,
        efficiency=efficiency,
        repositories=repos,
        timeline=timeline,
        users=user_profiles,
        projects=project_profiles,
        repo_profiles=repo_profiles
    )

    file_store = FileStore(config.report.storage_path)
    job_dir = file_store.save_report(report)
    logger.info(f"Mock report saved locally to: {job_dir}")

    if config.artifactory.enabled:
        artifactory = ArtifactoryClient(config.artifactory)
        artifactory.publish_report(report)

    print(f"\n Mock report generated successfully for {month}!")
    print(f"   Directory: {job_dir}")
    print(f"   Total Commits: {report.total_commits} | Total PRs: {report.total_pull_requests} | Repos: {report.total_repositories}\n")
    return report


def main():
    parser = argparse.ArgumentParser(description="Bitbucket Repository Activity Reporting System")
    subparsers = parser.add_subparsers(dest="command", help="Sub-commands: serve, scan")

    # Serve command (Flask UI server)
    serve_parser = subparsers.add_parser("serve", help="Start the Flask reporting UI server")
    serve_parser.add_argument("--host", type=str, default=None, help="Host to bind (default from config)")
    serve_parser.add_argument("--port", type=int, default=None, help="Port to bind (default from config)")
    serve_parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")

    # Scan command (External/standalone scan runner)
    scan_parser = subparsers.add_parser("scan", help="Run the repository scan (Bitbucket DC + Awesome Graphs)")
    scan_parser.add_argument("--month", type=str, default=None, help="Reporting month in YYYY-MM format (e.g. 2026-09)")
    scan_parser.add_argument("--config", type=str, default=None, help="Path to config.yaml")
    scan_parser.add_argument("--mock", action="store_true", help="Generate mock report data for testing")

    args = parser.parse_args()

    # Default to 'serve' if no command given
    cmd = args.command or "serve"
    config_path = getattr(args, "config", None)
    config = load_config(config_path)

    configure_logging(log_dir=config.logging.directory, log_level=config.logging.level)

    if cmd == "serve":
        from app import create_app
        app = create_app(config)
        host = args.host or config.application.host
        port = args.port or config.application.port
        print(f"\n=======================================================")
        print(f" Starting Bitbucket Activity Report Server")
        print(f" Dashboard URL: http://{host}:{port}")
        print(f" Environment:   {config.application.environment}")
        print(f" Reports Path:  {config.report.storage_path}")
        print(f" Logs Path:     {config.logging.directory}")
        print(f"=======================================================\n")
        app.run(host=host, port=port, debug=(config.application.environment == "development"))

    elif cmd == "scan":
        month = args.month or datetime.now(timezone.utc).strftime("%Y-%m")
        if args.mock:
            run_mock_scan(config, month)
        else:
            runner = ScanRunner(config)
            report = runner.execute(year_month=month)
            print(f"\n Scan completed successfully for {month}!")
            print(f"   Status: {report.metadata.status}")
            print(f"   Job ID: {report.metadata.job_id}")
            print(f"   Trace ID: {report.metadata.trace_id}")
            print(f"   Commits: {report.total_commits} | Pull Requests: {report.total_pull_requests}\n")


if __name__ == "__main__":
    main()
