from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class UserActivity(BaseModel):
    user_id: str
    display_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class UserProjectContribution(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class TimeseriesPoint(BaseModel):
    date: str  # YYYY-MM-DD
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0


class UserProfile(BaseModel):
    user_id: str
    display_name: str
    email: Optional[str] = None
    total_commits: int = 0
    total_pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    project_contributions: List[UserProjectContribution] = Field(default_factory=list)
    project_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class ProjectRepoContribution(BaseModel):
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    users: List[UserActivity] = Field(default_factory=list)


class ProjectProfile(BaseModel):
    project_key: str
    project_name: str
    total_commits: int = 0
    total_pull_requests: int = 0
    total_repositories: int = 0
    total_active_users: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    repo_contributions: List[ProjectRepoContribution] = Field(default_factory=list)
    repo_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class RepoSummary(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    commits: int = 0
    pull_requests: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    users: List[UserActivity] = Field(default_factory=list)
    timeline: List[TimeseriesPoint] = Field(default_factory=list)


class RepoProfile(BaseModel):
    project_key: str
    project_name: str
    repo_slug: str
    repo_name: str
    total_commits: int = 0
    total_pull_requests: int = 0
    unique_commit_authors: int = 0
    unique_pr_authors: int = 0
    total_active_users: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    users: List[UserActivity] = Field(default_factory=list)
    user_timeline: Dict[str, List[TimeseriesPoint]] = Field(default_factory=dict)


class ReportMetadata(BaseModel):
    job_id: str
    trace_id: str
    generated_at: str  # ISO-8601 UTC
    period_start: str  # ISO-8601 UTC
    period_end: str    # ISO-8601 UTC
    projects_configured: List[str] = Field(default_factory=list)
    repository_limit: Any = "NA"
    worker_count: int = 5
    status: str = "COMPLETED"  # COMPLETED, PARTIAL_SUCCESS, FAILED
    total_repositories: int = 0
    completed_repositories: int = 0
    failed_repositories: int = 0
    errors: List[Dict[str, Any]] = Field(default_factory=list)


class EfficiencyMetrics(BaseModel):
    avg_commits_per_repo: float = 0.0
    avg_commits_per_project: float = 0.0
    avg_commits_per_user: float = 0.0
    avg_prs_per_repo: float = 0.0
    avg_prs_per_project: float = 0.0
    avg_prs_per_user: float = 0.0
    avg_lines_per_commit: float = 0.0
    total_lines_added: int = 0
    total_lines_deleted: int = 0
    net_lines_changed: int = 0


class ReportData(BaseModel):
    metadata: ReportMetadata
    total_commits: int = 0
    total_pull_requests: int = 0
    total_repositories: int = 0
    total_active_users: int = 0
    total_lines_added: int = 0
    total_lines_deleted: int = 0
    efficiency: Optional[EfficiencyMetrics] = None
    repositories: List[RepoSummary] = Field(default_factory=list)
    timeline: List[TimeseriesPoint] = Field(default_factory=list)
    users: Dict[str, UserProfile] = Field(default_factory=dict)
    projects: Dict[str, ProjectProfile] = Field(default_factory=dict)
    repo_profiles: Dict[str, RepoProfile] = Field(default_factory=dict)

